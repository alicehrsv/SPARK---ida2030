<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- ida base components live in src/components/ida (core.tsx, extras.tsx) on top of the design tokens in src/styles.css; screens reuse them so the look stays consistent.
- All mock data lives in src/data with shared types in src/types.ts; facts the assistant shows come only from src/data/knowledge.ts so nothing is invented.
- App state lives in one reducer in src/context/AppContext.tsx (saved to localStorage after the page loads); which pages are public and which hide the bottom bar is decided in src/lib/routes-meta.ts so the login check stays in one place.
- Register queries always go through useConsent() from src/components/ida/ConsentSheet.tsx, which writes the consent and the log entry; critical actions go through useCriticalAction, and AppShell expires the approval when the user leaves that screen, keeping it single-use.
- The mock AI (src/services/ai.ts) stores an answer spec per chat message and renders the text at display time, so the last answer can be re-rendered in a new language.
- Procedures are JSON templates in src/data/workflows/ run by one generic workflow runner; a new procedure = a new template, never new screen code.
- Entitlement hints come only from the rules engine in src/services/entitlements.ts over register data, so every hint is traceable to a register source.
- Acting for someone swaps the whole app state (ACT_FOR / STOP_ACTING in AppContext) and the LOG reducer stamps the proxy as actor; area visibility goes through areaAllowed() in src/lib/acting.ts.
