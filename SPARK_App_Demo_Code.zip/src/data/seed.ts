import type { ActivityEntry } from "@/types";
import type { AppState } from "@/context/AppContext";
import { DEMO_TODAY } from "./config";

/** ISO date offset in days (and optional hour) from DEMO_TODAY. */
export const at = (days: number, hour = 9, min = 0) => {
  const d = new Date(DEMO_TODAY);
  d.setDate(d.getDate() + days);
  d.setHours(hour, min, 0, 0);
  return d.toISOString();
};

type Seed = Pick<AppState, "applications" | "powersOfAttorney" | "reminders" | "appointments" | "entitlements" | "notifications" | "activityLog" | "settings">;

const log = (id: string, days: number, e: Omit<ActivityEntry, "id" | "timestamp" | "actor" | "channel"> & Partial<Pick<ActivityEntry, "actor" | "channel">>): ActivityEntry =>
  ({ id, timestamp: at(days, 10), actor: "self", channel: "app", ...e });

export function seedFor(userId: string): Seed {
  switch (userId) {
    case "marcus":
      return {
        settings: { entitlementChecks: true, notifications: true },
        applications: [
          { id: "app-birth", procedureId: "birth-registration", title: "Register Noah's birth", status: "draft", stepsLeft: 2, stepIndex: 2, createdAt: at(-10) },
          { id: "app-tax", procedureId: "tax-assessment", title: "Employee tax assessment 2029", status: "approved", createdAt: at(-30), submittedAt: at(-28), receivedAt: at(-28), reviewAt: at(-20), decidedAt: at(-2), reference: "FA-2030-118204", authority: "Finanzamt Österreich", decisionText: "Assessment notice 2029: your refund is € 412. It will be paid to your account ending 4471 within 3 weeks." },
        ],
        reminders: [
          { id: "r-tax-docs", title: "Send receipts to the tax office", due: at(21), done: false, relatedId: "l-tax", link: "/letter/l-tax", kind: "deadline", source: "Letter from Finanzamt Österreich", enabled: true, procedureId: "tax-assessment" },
          { id: "r-passport", title: "Passport expires", due: at(18), done: false, relatedId: "l-passport", link: "/letter/l-passport", kind: "document", source: "ID Documents Register", enabled: true, procedureId: "passport-renewal" },
          { id: "r-ap-1", title: "Appointment tomorrow: Passport renewal", due: at(4, 9), done: false, link: "/appointments", kind: "appointment", source: "Your appointment", enabled: true },
        ],
        appointments: [
          { id: "ap-1", officeId: "mba10", slot: at(5, 9, 30), purpose: "Passport renewal", checklist: ["Old passport", "Passport photo (35×45 mm, not older than 6 months)", "Fee approx. € 112"] },
          { id: "ap-0", officeId: "finanzamt", slot: at(-40, 10), purpose: "Questions about tax assessment", checklist: ["Payslips 2029"] },
        ],
        powersOfAttorney: [
          { id: "poa-martha", name: "Martha Gruber", relationship: "Neighbour / family friend", areas: [{ area: "documents", right: "prepare" }, { area: "health", right: "submit" }, { area: "applications", right: "prepare" }, { area: "money", right: "view" }], validUntil: "2031-03-31", status: "active", direction: "received", personUserId: "martha" },
          { id: "poa-lena", name: "Lena Huber", relationship: "Spouse", areas: [{ area: "family", right: "submit" }, { area: "documents", right: "prepare" }], validUntil: "2032-12-31", status: "active", direction: "granted" },
        ],
        entitlements: [
          { id: "family-allowance", title: "Family allowance for Noah", status: "new", reason: "New child in household" },
          { id: "childcare-benefit", title: "Childcare benefit", status: "new", reason: "Birth on 2 March 2030" },
        ],
        notifications: [
          { id: "n-m1", kind: "security", title: "New login", body: "Login from Browser · Vienna", date: at(0, 8, 12), read: false, link: "/profile/devices" },
          { id: "n-m2", kind: "entitlement", title: "2 possible entitlements", body: "Family allowance and childcare benefit for Noah", date: at(0, 7, 40), read: false, link: "/entitlements" },
          { id: "n-m3", kind: "request", title: "Tax office requests documents", body: "Receipts for 2029 – due 5 April", date: at(-7, 11), read: false, link: "/letter/l-tax" },
          { id: "n-m4", kind: "appointment", title: "Appointment confirmed", body: "Bezirksamt 10 · 20 March, 9:30", date: at(-3, 15), read: true, link: "/appointments" },
          { id: "n-m5", kind: "status", title: "Tax assessment in review", body: "Finanzamt Österreich is checking your return", date: at(-28, 9), read: true, link: "/applications/app-tax" },
        ],
        activityLog: [
          log("a-m1", -3, { type: "appointment_booked", title: "Booked an appointment at Bezirksamt 10", purpose: "Passport renewal", level: "basic", authority: "Magistratisches Bezirksamt 10" }),
          log("a-m2", -10, { type: "register_query", title: "Fetched birth data of Noah", purpose: "Register a birth", register: "Central Civil Status Register", dataFields: ["Name", "Birth date"], level: "basic" }),
          log("a-m3", -28, { type: "submission", title: "Submitted tax assessment 2029", purpose: "Tax refund", authority: "Finanzamt Österreich", level: "critical" }),
        ],
      };
    case "amira":
      return {
        settings: { entitlementChecks: false, notifications: true },
        applications: [
          { id: "app-rp-old", procedureId: "residence-purpose-change", title: "Change purpose of residence (employer change)", status: "request", createdAt: at(-20), submittedAt: at(-19), receivedAt: at(-18), reviewAt: at(-10), reference: "MA35-2030-04417", authority: "MA 35 – Immigration and Citizenship", request: { text: "MA 35 needs a current payslip by 2 April", document: "Current payslip (March 2030)", due: "2030-04-02", fetchRegister: "tax" } },
        ],
        powersOfAttorney: [],
        reminders: [{ id: "r-rp", title: "Residence permit expires", due: at(46), done: false, relatedId: "l-ma35", link: "/letter/l-ma35", kind: "document", source: "Foreigners Register", enabled: true, procedureId: "residence-permit-renewal" },
          { id: "r-payslip", title: "Send payslip to MA 35", due: at(18), done: false, link: "/applications/app-rp-old", kind: "deadline", source: "Request from MA 35", enabled: true }],
        appointments: [],
        entitlements: [],
        notifications: [
          { id: "n-a1", kind: "deadline", title: "Residence permit expires in 46 days", body: "Apply at MA 35 before 30 April", date: at(0, 8), read: false, link: "/letter/l-ma35" },
          { id: "n-a2", kind: "request", title: "New letter from MA 35", body: "Your residence title expires", date: at(-14, 10), read: true, link: "/letter/l-ma35" },
        ],
        activityLog: [log("a-a1", -14, { type: "letter_scanned", title: "Scanned a letter from MA 35", purpose: "Understand letter", authority: "MA 35", level: "basic" })],
      };
    case "martha":
      return {
        settings: { entitlementChecks: true, notifications: true },
        applications: [],
        powersOfAttorney: [
          { id: "poa-martha-g", name: "Marcus Huber", relationship: "Neighbour / family friend", areas: [{ area: "documents", right: "prepare" }, { area: "health", right: "submit" }, { area: "applications", right: "prepare" }, { area: "money", right: "view" }], validUntil: "2031-03-31", status: "active", direction: "granted" },
        ],
        reminders: [{ id: "r-pp", title: "Passport expires", due: at(184), done: false, kind: "document", source: "ID Documents Register", enabled: true, procedureId: "passport-renewal" },
          { id: "r-ap-m", title: "Appointment tomorrow: Passport renewal", due: at(11, 9), done: false, link: "/appointments", kind: "appointment", source: "Your appointment", enabled: true }],
        appointments: [{ id: "ap-m", officeId: "bhzwettl", slot: at(12, 10), purpose: "Passport renewal", checklist: ["Old passport", "Passport photo", "Fee approx. € 112"] }],
        entitlements: [{ id: "heating-allowance", title: "Heating allowance", status: "new", reason: "Pension below threshold (hint only)" }, { id: "gis-exemption", title: "Broadcasting fee exemption", status: "new", reason: "Low income pensioner (hint only)" }],
        notifications: [{ id: "n-g1", kind: "deadline", title: "Your passport expires in 6 months", body: "Renew it in time", date: at(-2, 9), read: false, link: "/reminders" }],
        activityLog: [log("a-g1", -2, { type: "call", title: "Called ida about the pension statement", purpose: "General question", level: "public", channel: "phone agent" })],
      };
    default:
      return {
        settings: { entitlementChecks: true, notifications: true },
        applications: [{ id: "app-sg", procedureId: "study-grant", title: "Study grant – summer semester", status: "draft", stepsLeft: 3, stepIndex: 1, createdAt: at(-4) }],
        powersOfAttorney: [],
        reminders: [{ id: "r-sg", title: "Study grant deadline", due: at(61), done: false, link: "/applications/new/study-grant", kind: "deadline", source: "Study grant authority", enabled: true, procedureId: "study-grant" }],
        appointments: [],
        entitlements: [{ id: "study-grant", title: "Study grant", status: "new", reason: "Student at TU Graz" }, { id: "tax-refund", title: "Tax refund 2029", status: "new", reason: "Summer job income" }],
        notifications: [{ id: "n-p1", kind: "entitlement", title: "Possible tax refund", body: "About € 180 – check it with ida", date: at(-1, 18), read: false, link: "/entitlements" }],
        activityLog: [],
      };
  }
}
