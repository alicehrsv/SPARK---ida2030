/** The app's "today" for the demo. */
export const DEMO_TODAY = new Date("2030-03-15T09:00:00+01:00");
export const SIMULATED_LABEL = "Prototype – simulated data";
