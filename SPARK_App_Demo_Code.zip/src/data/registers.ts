import type { RegisterRecord } from "@/types";

type Def = Omit<RegisterRecord, "fields" | "simulated" | "lastUpdated">;
const R = {
  zmr: { id: "zmr", name: { en: "Central Residence Register", de: "Zentrales Melderegister (ZMR)" }, authority: "Federal Ministry of the Interior", icon: "Home", sensitivity: "normal" },
  zpr: { id: "zpr", name: { en: "Central Civil Status Register", de: "Zentrales Personenstandsregister (ZPR)" }, authority: "Federal Ministry of the Interior", icon: "Users", sensitivity: "normal" },
  citizenship: { id: "citizenship", name: { en: "Citizenship Register", de: "Staatsbürgerschaftsregister" }, authority: "Federal Ministry of the Interior", icon: "Flag", sensitivity: "normal" },
  iddocs: { id: "iddocs", name: { en: "ID Documents Register", de: "Identitätsdokumentenregister" }, authority: "Federal Ministry of the Interior", icon: "IdCard", sensitivity: "normal" },
  driving: { id: "driving", name: { en: "Driving Licence Register", de: "Führerscheinregister" }, authority: "Federal Ministry for Climate Action", icon: "Car", sensitivity: "normal" },
  foreigners: { id: "foreigners", name: { en: "Foreigners Register (residence titles)", de: "Fremdenregister" }, authority: "MA 35 – Immigration and Citizenship, Vienna", icon: "Globe", sensitivity: "normal" },
  vehicle: { id: "vehicle", name: { en: "Vehicle Register", de: "Zulassungsregister" }, authority: "Federal Ministry for Climate Action", icon: "CarFront", sensitivity: "normal" },
  criminal: { id: "criminal", name: { en: "Criminal Record Register", de: "Strafregister" }, authority: "Federal Police Directorate Vienna", icon: "ShieldAlert", sensitivity: "critical" },
  tax: { id: "tax", name: { en: "Tax Office (FinanzOnline)", de: "Finanzamt Österreich (FinanzOnline)" }, authority: "Finanzamt Österreich", icon: "Receipt", sensitivity: "normal" },
  social: { id: "social", name: { en: "Social Insurance", de: "Sozialversicherung" }, authority: "Dachverband der Sozialversicherungsträger", icon: "HeartPulse", sensitivity: "normal" },
  transparency: { id: "transparency", name: { en: "Transparency Database", de: "Transparenzdatenbank" }, authority: "Federal Ministry of Finance", icon: "Database", sensitivity: "normal" },
  pension: { id: "pension", name: { en: "Pension Insurance", de: "Pensionsversicherung" }, authority: "PVA – Pensionsversicherungsanstalt", icon: "PiggyBank", sensitivity: "normal" },
  education: { id: "education", name: { en: "Education Register", de: "Bildungsregister / Studierendenevidenz" }, authority: "Federal Ministry of Education, Science and Research", icon: "GraduationCap", sensitivity: "normal" },
} satisfies Record<string, Def>;

const rec = (def: Def, lastUpdated: string, fields: [string, string][]): RegisterRecord => ({
  ...def, lastUpdated, simulated: true, fields: fields.map(([label, value]) => ({ label, value })),
});
const noCrime = (d: string) => rec(R.criminal, d, [["Entries", "No entries"]]);

export const registersByUser: Record<string, RegisterRecord[]> = {
  marcus: [
    rec(R.zmr, "2030-03-04", [["Main residence", "Favoritenstraße 112/14, 1100 Wien"], ["Secondary residence", "None"], ["Registered since", "1 Aug 2021"], ["Household members", "Lena Huber, Emma Huber, Noah Huber"]]),
    rec(R.zpr, "2030-03-04", [["Birth", "12 Jun 1995, Linz"], ["Marital status", "Married (since 14 May 2022)"], ["Spouse", "Lena Huber"], ["Children", "Emma Huber (20 Nov 2025), Noah Huber (2 Mar 2030)"], ["Names", "Marcus Johann Huber"]]),
    rec(R.citizenship, "2019-01-10", [["Citizenship", "Austria"], ["Since", "Birth"]]),
    rec(R.iddocs, "2025-06-01", [["Passport", "P••••4821, issued 3 Apr 2020, expires 2 Apr 2030"], ["ID card", "Expires 18 Sep 2031"]]),
    rec(R.driving, "2021-02-11", [["Classes", "AM, B, C1"], ["Issued", "11 Feb 2021"], ["Expiry", "10 Feb 2036"]]),
    rec(R.vehicle, "2027-05-20", [["Plate", "W-482 HB"], ["Model", "Škoda Octavia Combi (2024)"], ["Registered at", "Favoritenstraße 112/14, 1100 Wien"]]),
    noCrime("2030-03-01"),
    rec(R.tax, "2029-07-15", [["Last annual income", "€ 31,400 (2028)"], ["Last assessment year", "2028"], ["Expected refund", "€ 412 (estimate 2029)"]]),
    rec(R.social, "2030-03-05", [["Insurer", "ÖGK"], ["Employer", "Fast Wien Logistik GmbH"], ["Insured since", "1 Sep 2015"], ["Family co-insured", "Emma Huber, Noah Huber"]]),
    rec(R.transparency, "2030-02-28", [["Benefits received", "Family allowance (Emma), childcare benefit 2026–2027"]]),
  ],
  amira: [
    rec(R.zmr, "2029-11-02", [["Main residence", "Thaliastraße 45/7, 1160 Wien"], ["Secondary residence", "None"], ["Registered since", "15 Jan 2024"], ["Household members", "None"]]),
    rec(R.zpr, "2024-01-15", [["Birth", "21 Aug 2000, Sarajevo"], ["Marital status", "Single"], ["Spouse", "–"], ["Children", "None"], ["Names", "Amira Hadžić"]]),
    rec(R.citizenship, "2024-01-15", [["Citizenship", "Bosnia and Herzegovina"], ["Since", "Birth"]]),
    rec(R.iddocs, "2024-01-15", [["Passport (BiH)", "B••••7735, issued 9 Mar 2022, expires 8 Mar 2032"], ["ID card", "Not applicable"]]),
    rec(R.driving, "2025-03-10", [["Classes", "B"], ["Issued", "10 Mar 2025 (converted)"], ["Expiry", "9 Mar 2040"]]),
    rec(R.foreigners, "2027-05-02", [["Title type", "Rot-Weiß-Rot – Karte plus"], ["Number", "RWR+ ••••2290"], ["Issued", "1 May 2027"], ["Expiry", "30 Apr 2030"], ["Authority", "MA 35"]]),
    noCrime("2030-03-01"),
    rec(R.tax, "2029-08-02", [["Last annual income", "€ 38,900 (2028)"], ["Last assessment year", "2028"], ["Expected refund", "€ 236 (estimate 2029)"]]),
    rec(R.social, "2030-03-01", [["Insurer", "ÖGK"], ["Employer", "Klinik Ottakring (Wiener Gesundheitsverbund)"], ["Insured since", "1 Feb 2024"], ["Family co-insured", "None"]]),
    rec(R.transparency, "2030-02-28", [["Benefits received", "None"]]),
  ],
  martha: [
    rec(R.zmr, "2018-04-10", [["Main residence", "Landstraße 18, 3910 Zwettl"], ["Secondary residence", "None"], ["Registered since", "3 Jun 1981"], ["Household members", "None"]]),
    rec(R.zpr, "2023-09-20", [["Birth", "2 Apr 1957, Zwettl"], ["Marital status", "Widowed (since 12 Sep 2023)"], ["Spouse", "Johann Gruber (deceased)"], ["Children", "Karin Leitner (1982)"], ["Names", "Martha Gruber, née Pichler"]]),
    rec(R.citizenship, "2010-01-01", [["Citizenship", "Austria"], ["Since", "Birth"]]),
    rec(R.iddocs, "2021-05-12", [["Passport", "P••••1056, issued 15 Sep 2020, expires 15 Sep 2030"], ["ID card", "None"]]),
    rec(R.driving, "1976-06-01", [["Classes", "B"], ["Issued", "1 Jun 1976"], ["Expiry", "Unlimited (old licence – exchange due by 19 Jan 2033)"]]),
    noCrime("2030-03-01"),
    rec(R.tax, "2029-06-10", [["Last annual income", "€ 21,800 pension (2028)"], ["Last assessment year", "2028"], ["Expected refund", "€ 0"]]),
    rec(R.social, "2030-01-02", [["Insurer", "ÖGK"], ["Employer", "Retired"], ["Insured since", "1 Sep 1973"], ["Family co-insured", "None"]]),
    rec(R.transparency, "2030-02-28", [["Benefits received", "Old-age pension, survivor's pension"]]),
    rec(R.pension, "2030-01-02", [["Pension amount", "€ 1,412 gross / month (14×)"], ["Start date", "1 May 2017"], ["Survivor's pension", "€ 386 / month"]]),
  ],
  patrick: [
    rec(R.zmr, "2011-10-12", [["Main residence", "Elisabethstraße 30, 8010 Graz"], ["Secondary residence", "None"], ["Registered since", "12 Oct 2011"], ["Household members", "Thomas Steiner, Sabine Steiner"]]),
    rec(R.zpr, "2011-10-12", [["Birth", "5 Oct 2011, Graz"], ["Marital status", "Single"], ["Spouse", "–"], ["Children", "None"], ["Names", "Patrick Steiner"]]),
    rec(R.citizenship, "2011-10-12", [["Citizenship", "Austria"], ["Since", "Birth"]]),
    rec(R.iddocs, "2026-08-01", [["Passport", "P••••9902, issued 1 Aug 2026, expires 31 Jul 2032"], ["ID card", "Expires 4 Oct 2035"]]),
    rec(R.driving, "2029-11-15", [["Classes", "B (L17 probation)"], ["Issued", "15 Nov 2029"], ["Expiry", "14 Nov 2044"]]),
    noCrime("2030-03-01"),
    rec(R.tax, "2029-09-01", [["Last annual income", "€ 4,200 (2028, summer job)"], ["Last assessment year", "2028"], ["Expected refund", "€ 180 (estimate 2029)"]]),
    rec(R.social, "2030-02-01", [["Insurer", "ÖGK"], ["Employer", "None (co-insured)"], ["Insured since", "Birth"], ["Family co-insured", "Co-insured with Sabine Steiner"]]),
    rec(R.transparency, "2030-02-28", [["Benefits received", "Family allowance (to parents)"]]),
    rec(R.education, "2029-10-01", [["University", "TU Graz – Computer Science (BSc)"], ["Enrolled since", "1 Oct 2029"], ["ECTS this year", "24"]]),
  ],
};
