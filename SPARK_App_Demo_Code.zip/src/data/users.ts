import type { User } from "@/types";

const defaults = { largeText: false, readAloud: false, phoneFirst: false, easyLanguage: false, automation: "assisted" as const, notifications: "push+email" as const };

export const users: User[] = [
  {
    id: "marcus", firstName: "Marcus", lastName: "Huber", age: 34, birthDate: "1995-06-12",
    city: "Vienna", postcode: "1100", address: "Favoritenstraße 112/14, 1100 Wien",
    occupation: "Delivery driver", citizenship: "Austria",
    family: [
      { name: "Lena Huber", relation: "spouse", birthDate: "1996-09-03" },
      { name: "Emma Huber", relation: "child", birthDate: "2025-11-20" },
      { name: "Noah Huber", relation: "child", birthDate: "2030-03-02" },
    ],
    preferredLanguage: "en", preferences: { ...defaults }, isDefault: true,
  },
  {
    id: "amira", firstName: "Amira", lastName: "Hadžić", age: 29, birthDate: "2000-08-21",
    city: "Vienna", postcode: "1160", address: "Thaliastraße 45/7, 1160 Wien",
    occupation: "Nurse", citizenship: "Bosnia and Herzegovina", family: [],
    preferredLanguage: "bcs", preferences: { ...defaults },
    note: "Residence permit Rot-Weiß-Rot – Karte plus expires 30 April 2030",
  },
  {
    id: "martha", firstName: "Martha", lastName: "Gruber", age: 72, birthDate: "1957-04-02",
    city: "Zwettl", postcode: "3910", address: "Landstraße 18, 3910 Zwettl",
    occupation: "Retired", citizenship: "Austria", family: [],
    preferredLanguage: "de",
    preferences: { ...defaults, largeText: true, readAloud: true, phoneFirst: true, easyLanguage: true, automation: "manual", notifications: "letter" },
    note: "Widowed, mild visual impairment",
  },
  {
    id: "patrick", firstName: "Patrick", lastName: "Steiner", age: 18, birthDate: "2011-10-05",
    city: "Graz", postcode: "8010", address: "Elisabethstraße 30, 8010 Graz",
    occupation: "Student, TU Graz", citizenship: "Austria",
    family: [
      { name: "Thomas Steiner", relation: "parent", birthDate: "1978-02-14" },
      { name: "Sabine Steiner", relation: "parent", birthDate: "1980-07-30" },
    ],
    preferredLanguage: "en", preferences: { ...defaults, automation: "full", notifications: "push" },
  },
];

export const defaultUser = users.find((u) => u.isDefault)!;
