import type { Office } from "@/types";
import { DEMO_TODAY } from "./config";

/** Deterministic free slots for the next 14 days (weekdays only). */
function makeSlots(seed: number): string[] {
  const out: string[] = [];
  for (let d = 1; d <= 14; d++) {
    const day = new Date(DEMO_TODAY);
    day.setDate(day.getDate() + d);
    const wd = day.getDay();
    if (wd === 0 || wd === 6) continue;
    const hours = [8, 9, 10, 11, 13, 14].filter((_, i) => (i + d + seed) % 3 !== 0);
    for (const h of hours) {
      const s = new Date(day);
      s.setHours(h, (d + seed) % 2 ? 30 : 0, 0, 0);
      out.push(s.toISOString());
    }
  }
  return out;
}

const weekday = "Mon–Fri 8:00–12:00, Thu also 15:30–17:30";

export const offices: Office[] = [
  { id: "ma35", name: "MA 35 – Immigration and Citizenship", address: "Dresdner Straße 93, 1200 Wien", openingHours: "Mon–Fri 8:00–13:00 (appointment only)", slots: makeSlots(1) },
  { id: "mba10", name: "Magistratisches Bezirksamt 10", address: "Laxenburger Straße 43–45, 1100 Wien", openingHours: weekday, slots: makeSlots(2) },
  { id: "passgraz", name: "Passport office Graz", address: "Schmiedgasse 26, 8010 Graz", openingHours: "Mon–Fri 7:30–13:00", slots: makeSlots(3) },
  { id: "bhzwettl", name: "BH Zwettl (District Authority)", address: "Am Statzenberg 1, 3910 Zwettl", openingHours: "Mon–Fri 8:00–12:00, Tue also 16:00–19:00", slots: makeSlots(4) },
  { id: "finanzamt", name: "Finanzamt Österreich – Dienststelle Wien 10", address: "Marxergasse 4, 1030 Wien", openingHours: "Mon–Thu 7:30–15:30, Fri 7:30–12:00", slots: makeSlots(5) },
  { id: "oegk", name: "ÖGK Service Centre Favoriten", address: "Wienerbergstraße 15–19, 1100 Wien", openingHours: "Mon–Fri 7:00–14:00", slots: makeSlots(6) },
  { id: "pva", name: "PVA – Pensionsversicherungsanstalt", address: "Friedrich-Hillegeist-Straße 1, 1020 Wien", openingHours: "Mon–Fri 7:00–15:00", slots: makeSlots(7) },
  { id: "digital-austria", name: "Digital Austria service point", address: "Ballhausplatz 2, 1010 Wien", openingHours: "Mon–Fri 9:00–17:00", slots: makeSlots(8) },
];
