import type { LanguageCode } from "@/types";
import { useApp } from "@/context/AppContext";

const en = {
  "nav.home": "Home", "nav.chat": "Chat", "nav.vault": "Vault", "nav.applications": "Applications", "nav.profile": "Profile",
  "common.continue": "Continue", "common.cancel": "Cancel", "common.back": "Back", "common.skip": "Skip", "common.start": "Start", "common.next": "Next",
  "common.prototype": "Prototype – simulated data", "common.loginCancelled": "Login cancelled",
  "welcome.subtitle": "Your digital assistant for Austria",
  "welcome.lead": "Official services, clear answers and secure help — all in one place.",
  "welcome.b1": "Understands your letters", "welcome.b2": "Does your applications with you", "welcome.b3": "Speaks your language",
  "welcome.login": "Log in with ID Austria", "welcome.ask": "Ask without login", "welcome.language": "Change language",
  "language.title": "Language", "language.easy": "Easy Language", "language.easyDesc": "Short sentences, one idea at a time",
  "login.title": "Log in", "login.banner": "Simulation for the hackathon prototype – no real ID Austria login",
  "login.heading": "Log in with ID Austria (simulation)", "login.text": "You will confirm the login in your Digital Austria app.",
  "login.username": "Username or phone number", "login.qr": "Log in with QR code", "login.scan": "Scan with your phone", "login.or": "or",
  "login.waiting": "Confirm the login request in your app", "login.push": "Login request: ida 2030 – Confirm?",
  "login.wants": "ida 2030 wants to log you in", "login.device": "Device", "login.time": "Time",
  "login.confirm": "Confirm", "login.decline": "Decline", "login.fingerprint": "Confirm with fingerprint or PIN",
  "login.receives": "ida 2030 receives from ID Austria:", "login.name": "Name", "login.dob": "Date of birth",
  "login.bpk": "Sector-specific identifier (bPK)", "login.allow": "Allow", "login.success": "You are logged in",
  "device.title": "New device", "device.text": "New device. Please confirm it's you once with a face scan.",
  "device.why": "This is a critical step. It protects your account if someone else tries to log in.",
  "device.scan": "Start face scan", "device.servicePoint": "Verify at a service point instead",
  "device.spText": "Bring your passport or ID card. A staff member confirms your identity and this device.",
  "onb.title": "Getting started",
  "onb.1.title": "Fetch instead of upload", "onb.1.text": "ida gets your data from the registers – only with your consent.",
  "onb.2.title": "You decide", "onb.2.text": "Nothing is sent without your yes. Critical steps need a face scan.",
  "onb.3.title": "Quick setup", "onb.textSize": "Text size", "onb.preview": "This is how text will look.",
  "onb.readAloud": "Read aloud", "onb.entitlements": "Let ida check my entitlements", "onb.entitlementsDesc": "ida only gives hints – the authority decides.",
  "onb.notifications": "Notifications",
  "profile.logout": "Log out",
};
export type TKey = keyof typeof en;

const de: Record<TKey, string> = {
  "nav.home": "Start", "nav.chat": "Chat", "nav.vault": "Tresor", "nav.applications": "Anträge", "nav.profile": "Profil",
  "common.continue": "Weiter", "common.cancel": "Abbrechen", "common.back": "Zurück", "common.skip": "Überspringen", "common.start": "Los geht's", "common.next": "Weiter",
  "common.prototype": "Prototyp – simulierte Daten", "common.loginCancelled": "Anmeldung abgebrochen",
  "welcome.subtitle": "Ihre digitale Assistentin für Österreich",
  "welcome.lead": "Amtswege, klare Antworten und sichere Hilfe – alles an einem Ort.",
  "welcome.b1": "Versteht Ihre Briefe", "welcome.b2": "Erledigt Anträge mit Ihnen", "welcome.b3": "Spricht Ihre Sprache",
  "welcome.login": "Mit ID Austria anmelden", "welcome.ask": "Ohne Anmeldung fragen", "welcome.language": "Sprache ändern",
  "language.title": "Sprache", "language.easy": "Einfache Sprache", "language.easyDesc": "Kurze Sätze, ein Gedanke pro Satz",
  "login.title": "Anmelden", "login.banner": "Simulation für den Hackathon-Prototyp – keine echte ID-Austria-Anmeldung",
  "login.heading": "Mit ID Austria anmelden (Simulation)", "login.text": "Sie bestätigen die Anmeldung in Ihrer Digitales-Amt-App.",
  "login.username": "Benutzername oder Telefonnummer", "login.qr": "Mit QR-Code anmelden", "login.scan": "Mit dem Handy scannen", "login.or": "oder",
  "login.waiting": "Bestätigen Sie die Anfrage in Ihrer App", "login.push": "Anmeldeanfrage: ida 2030 – Bestätigen?",
  "login.wants": "ida 2030 möchte Sie anmelden", "login.device": "Gerät", "login.time": "Uhrzeit",
  "login.confirm": "Bestätigen", "login.decline": "Ablehnen", "login.fingerprint": "Mit Fingerabdruck oder PIN bestätigen",
  "login.receives": "ida 2030 erhält von ID Austria:", "login.name": "Name", "login.dob": "Geburtsdatum",
  "login.bpk": "Bereichsspezifisches Personenkennzeichen (bPK)", "login.allow": "Erlauben", "login.success": "Sie sind angemeldet",
  "device.title": "Neues Gerät", "device.text": "Neues Gerät. Bitte bestätigen Sie einmal mit einem Gesichtsscan, dass Sie es sind.",
  "device.why": "Das ist ein kritischer Schritt. Er schützt Ihr Konto, falls sich jemand anderer anmeldet.",
  "device.scan": "Gesichtsscan starten", "device.servicePoint": "Stattdessen bei einer Servicestelle bestätigen",
  "device.spText": "Bringen Sie Reisepass oder Personalausweis mit. Eine Mitarbeiterin bestätigt Ihre Identität und dieses Gerät.",
  "onb.title": "Erste Schritte",
  "onb.1.title": "Abrufen statt hochladen", "onb.1.text": "ida holt Ihre Daten aus den Registern – nur mit Ihrer Zustimmung.",
  "onb.2.title": "Sie entscheiden", "onb.2.text": "Ohne Ihr Ja wird nichts gesendet. Kritische Schritte brauchen einen Gesichtsscan.",
  "onb.3.title": "Schnell einrichten", "onb.textSize": "Schriftgröße", "onb.preview": "So wird der Text aussehen.",
  "onb.readAloud": "Vorlesen", "onb.entitlements": "ida darf meine Ansprüche prüfen", "onb.entitlementsDesc": "ida gibt nur Hinweise – die Behörde entscheidet.",
  "onb.notifications": "Benachrichtigungen",
  "profile.logout": "Abmelden",
};

type Partial_ = Partial<Record<TKey, string>>;
const tr: Partial_ = {
  "nav.home": "Ana sayfa", "nav.chat": "Sohbet", "nav.vault": "Kasa", "nav.applications": "Başvurular", "nav.profile": "Profil",
  "common.continue": "Devam", "common.cancel": "İptal", "common.skip": "Atla", "common.start": "Başla", "common.next": "İleri",
  "common.prototype": "Prototip – simüle edilmiş veriler",
  "welcome.subtitle": "Avusturya için dijital asistanınız", "welcome.b1": "Mektuplarınızı anlar", "welcome.b2": "Başvurularınızı sizinle yapar", "welcome.b3": "Dilinizi konuşur",
  "welcome.login": "ID Austria ile giriş", "welcome.ask": "Giriş yapmadan sor", "language.title": "Dil", "language.easy": "Kolay dil",
};
const ar: Partial_ = {
  "nav.home": "الرئيسية", "nav.chat": "محادثة", "nav.vault": "الخزنة", "nav.applications": "الطلبات", "nav.profile": "الملف الشخصي",
  "common.continue": "متابعة", "common.cancel": "إلغاء", "common.skip": "تخطٍ", "common.start": "ابدأ", "common.next": "التالي",
  "common.prototype": "نموذج أولي – بيانات محاكاة",
  "welcome.subtitle": "مساعدك الرقمي في النمسا", "welcome.b1": "يفهم رسائلك", "welcome.b2": "يقدم طلباتك معك", "welcome.b3": "يتحدث لغتك",
  "welcome.login": "تسجيل الدخول عبر ID Austria", "welcome.ask": "اسأل بدون تسجيل دخول", "language.title": "اللغة", "language.easy": "لغة مبسطة",
};
const uk: Partial_ = {
  "nav.home": "Головна", "nav.chat": "Чат", "nav.vault": "Сейф", "nav.applications": "Заяви", "nav.profile": "Профіль",
  "common.continue": "Далі", "common.cancel": "Скасувати", "common.skip": "Пропустити", "common.start": "Почати", "common.next": "Далі",
  "common.prototype": "Прототип – змодельовані дані",
  "welcome.subtitle": "Ваш цифровий помічник в Австрії", "welcome.b1": "Розуміє ваші листи", "welcome.b2": "Оформлює заяви разом з вами", "welcome.b3": "Говорить вашою мовою",
  "welcome.login": "Увійти через ID Austria", "welcome.ask": "Запитати без входу", "language.title": "Мова", "language.easy": "Проста мова",
};
const bcs: Partial_ = {
  "nav.home": "Početna", "nav.chat": "Chat", "nav.vault": "Sef", "nav.applications": "Zahtjevi", "nav.profile": "Profil",
  "common.continue": "Nastavi", "common.cancel": "Otkaži", "common.skip": "Preskoči", "common.start": "Počni", "common.next": "Dalje",
  "common.prototype": "Prototip – simulirani podaci",
  "welcome.subtitle": "Vaš digitalni asistent za Austriju", "welcome.b1": "Razumije vaša pisma", "welcome.b2": "Radi zahtjeve s vama", "welcome.b3": "Govori vaš jezik",
  "welcome.login": "Prijava putem ID Austria", "welcome.ask": "Pitaj bez prijave", "language.title": "Jezik", "language.easy": "Jednostavan jezik",
};

const dicts: Record<LanguageCode, Partial_> = { en, de, tr, ar, uk, bcs };

export const LANGUAGES: { code: LanguageCode; native: string; english: string; short: string }[] = [
  { code: "en", native: "English", english: "English", short: "EN" },
  { code: "de", native: "Deutsch", english: "German", short: "DE" },
  { code: "tr", native: "Türkçe", english: "Turkish", short: "TR" },
  { code: "ar", native: "العربية", english: "Arabic", short: "AR" },
  { code: "uk", native: "Українська", english: "Ukrainian", short: "UK" },
  { code: "bcs", native: "Bosanski / Hrvatski / Srpski", english: "BCS", short: "BCS" },
];

export const isRtl = (l: LanguageCode) => l === "ar";
export const translate = (l: LanguageCode, k: TKey) => dicts[l][k] ?? en[k];

export function useT() {
  const { state } = useApp();
  return (k: TKey) => translate(state.language, k);
}
