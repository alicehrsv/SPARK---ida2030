export type LanguageCode = "en" | "de" | "tr" | "ar" | "uk" | "bcs";
export type SecurityLevel = "public" | "basic" | "critical";
export type Channel = "app" | "phone agent";

export interface FamilyMember { name: string; relation: "spouse" | "child" | "parent"; birthDate: string }

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  age: number;
  birthDate: string;
  city: string;
  postcode: string;
  address: string;
  occupation: string;
  citizenship: string;
  family: FamilyMember[];
  preferredLanguage: LanguageCode;
  preferences: { largeText: boolean; readAloud: boolean; phoneFirst: boolean; easyLanguage: boolean; automation: "manual" | "assisted" | "full"; notifications: "push" | "push+email" | "letter" };
  note?: string;
  isDefault?: boolean;
}

export interface RegisterField { label: string; value: string }
export interface RegisterRecord {
  id: string;
  name: { en: string; de: string };
  authority: string;
  icon: string; // lucide icon name
  fields: RegisterField[];
  lastUpdated: string;
  sensitivity: "normal" | "critical";
  simulated: true;
}

export interface ServiceDescription {
  id: string;
  title: { en: string; de: string };
  whatItIs: string;
  whoCanApply: string;
  documentsNeeded: string[];
  fetchableRegisters: string[]; // register ids
  fee: string;
  deadline: string;
  inPerson: boolean;
  authority: string;
  source: string;
  translations?: Partial<Record<LanguageCode, { title: string; summary: string }>>;
  de?: { whatItIs: string; whoCanApply: string; documentsNeeded: string[]; deadline: string; fee?: string };
}

export interface GlossaryTerm { term: string; plain: string }

export interface Letter {
  id: string;
  userId: string;
  sender: string;
  subject: string;
  date: string;
  deadline?: string;
  body: string;
  relatedServiceId?: string;
  /** Mock OCR result: plain-language summary and steps. */
  summary: string;
  steps: string[];
}

export interface Office {
  id: string;
  name: string;
  address: string;
  openingHours: string;
  slots: string[]; // ISO datetimes
}

export type ActivityType =
  | "login" | "logout" | "consent_granted" | "consent_revoked" | "register_query" | "document_upload"
  | "letter_scanned" | "submission" | "withdrawal" | "face_match" | "entitlement_check" | "appointment_booked"
  | "power_of_attorney" | "handover" | "call" | "settings_changed";

export interface ActivityEntry {
  id: string;
  timestamp: string;
  type: ActivityType;
  title: string;
  purpose: string;
  register?: string;
  dataFields?: string[];
  authority?: string;
  actor: string; // "self" or proxy name
  level: SecurityLevel;
  channel: Channel;
}
