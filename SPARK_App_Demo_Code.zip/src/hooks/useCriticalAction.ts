import { useLocation, useRouter } from "@tanstack/react-router";
import { useApp } from "@/context/AppContext";

/**
 * CRITICAL actions need ID Austria + face match, valid for this single action only.
 * request() opens /facematch; after success the approval for `actionName` is set until consume() is called.
 */
export function useCriticalAction(actionName: string) {
  const { state, dispatch } = useApp();
  const router = useRouter();
  const { href } = useLocation();
  const approved = state.criticalApproval?.action === actionName;
  return {
    approved,
    request: (returnTo: string = href) =>
      router.navigate({ to: "/facematch", search: { returnTo, action: actionName } }),
    consume: () => dispatch({ type: "CONSUME_CRITICAL" }),
  };
}
