import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, CalendarClock, FileWarning, CalendarCheck2, Sparkles } from "lucide-react";
import { useApp, newId } from "@/context/AppContext";
import { DEMO_TODAY } from "@/data/config";
import { daysUntil } from "@/lib/urgent";
import { ScreenHeader, Sheet, Toggle, EmptyState } from "@/components/ida/extras";
import { Button, Card, SectionTitle } from "@/components/ida/core";
import type { Reminder, ReminderKind } from "@/context/AppContext";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/reminders")({
  head: () => ({
    meta: [
      { title: "Reminders – ida 2030" },
      { name: "description", content: "Deadlines, expiring documents and appointments in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Reminders – ida 2030" },
      { property: "og:description", content: "Reminders in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: RemindersScreen,
});

const sections: { kind: ReminderKind; title: string; icon: typeof CalendarClock }[] = [
  { kind: "deadline", title: "Deadlines", icon: CalendarClock },
  { kind: "document", title: "Expiring documents", icon: FileWarning },
  { kind: "appointment", title: "Appointments", icon: CalendarCheck2 },
];

function urgencyClass(days: number) {
  if (days <= 14) return "text-security bg-security-bg";
  if (days <= 45) return "text-warning bg-warning-bg";
  return "text-success bg-success-bg";
}

function RemindersScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const [addOpen, setAddOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [repeat, setRepeat] = useState<"none" | "monthly" | "yearly">("none");

  const grouped = sections.map((s) => ({
    ...s,
    items: state.reminders
      .filter((r) => (r.kind ?? "deadline") === s.kind)
      .sort((a, b) => a.due.localeCompare(b.due)),
  }));

  const addReminder = () => {
    if (!title || !date) return;
    const item: Reminder = { id: newId(), title, due: new Date(date + "T09:00:00").toISOString(), done: false, kind: "deadline", source: "Added by you", enabled: true, repeat };
    dispatch({ type: "UPSERT_REMINDER", item });
    dispatch({ type: "LOG", entry: { type: "settings_changed", title: `Added reminder: ${title}`, purpose: "Manage reminders", actor: "self", level: "public", channel: "app" } });
    setAddOpen(false);
    setTitle(""); setDate(""); setRepeat("none");
  };

  return (
    <>
      <ScreenHeader title="Reminders" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <Button icon={<Plus className="size-5" aria-hidden />} onClick={() => setAddOpen(true)}>Add reminder</Button>

        {grouped.every((g) => g.items.length === 0) && <EmptyState title="No reminders yet" text="ida will remind you about deadlines, documents and appointments." />}

        {grouped.map((g) => g.items.length > 0 && (
          <section key={g.kind}>
            <SectionTitle><span className="flex items-center gap-2"><g.icon className="size-5" aria-hidden />{g.title}</span></SectionTitle>
            <div className="space-y-3">
              {g.items.map((r) => {
                const days = daysUntil(new Date(r.due), DEMO_TODAY);
                return (
                  <Card key={r.id} className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <p className="font-bold">{r.title}</p>
                      <span className={cn("shrink-0 rounded-full px-2.5 py-0.5 text-sm font-bold", urgencyClass(days))}>
                        {days < 0 ? "Overdue" : days === 0 ? "Today" : `${days} days left`}
                      </span>
                    </div>
                    {r.source && <p className="text-sm text-muted-foreground">Source: {r.source}</p>}
                    <div className="flex items-center justify-between gap-3">
                      <Toggle checked={r.enabled ?? true} onChange={(v) => dispatch({ type: "UPSERT_REMINDER", item: { ...r, enabled: v } })} label="Enabled" />
                    </div>
                    {r.procedureId ? (
                      <Button size="sm" icon={<Sparkles className="size-5" aria-hidden />} onClick={() => navigate({ to: "/applications/new/$procedureId", params: { procedureId: r.procedureId! } })}>
                        Let ida prepare it
                      </Button>
                    ) : r.link ? (
                      <Link to={r.link} className="min-h-11 font-bold text-primary underline">Open</Link>
                    ) : null}
                  </Card>
                );
              })}
            </div>
          </section>
        ))}
      </main>

      <Sheet open={addOpen} onOpenChange={setAddOpen} title="Add reminder">
        <div className="space-y-3">
          <label className="block">
            <span className="mb-1 block text-sm font-semibold">Title</span>
            <input value={title} onChange={(e) => setTitle(e.target.value)} className="min-h-[52px] w-full rounded-2xl border border-border px-4 text-base" />
          </label>
          <label className="block">
            <span className="mb-1 block text-sm font-semibold">Date</span>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="min-h-[52px] w-full rounded-2xl border border-border px-4 text-base" />
          </label>
          <div>
            <span className="mb-1 block text-sm font-semibold">Repeat</span>
            <div className="flex gap-2">
              {(["none", "monthly", "yearly"] as const).map((r) => (
                <button key={r} type="button" onClick={() => setRepeat(r)}
                  className={cn("min-h-11 flex-1 rounded-2xl border px-3 text-sm font-bold capitalize", repeat === r ? "border-primary bg-primary text-primary-foreground" : "border-border")}>
                  {r}
                </button>
              ))}
            </div>
          </div>
          <Button disabled={!title || !date} onClick={addReminder}>Save reminder</Button>
        </div>
      </Sheet>
    </>
  );
}
