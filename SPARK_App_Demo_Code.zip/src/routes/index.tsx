import { createFileRoute, redirect } from "@tanstack/react-router";

// Screens are not built yet; the start page shows the component styleguide for now.
export const Route = createFileRoute("/")({
  beforeLoad: () => {
    throw redirect({ to: "/welcome" });
  },
  head: () => ({
    meta: [
      { title: "ida 2030 – Your digital assistant for Austria" },
      { name: "description", content: "Prototype of ida 2030 with simulated data." },
      { property: "og:title", content: "ida 2030" },
      { property: "og:description", content: "Prototype of ida 2030 with simulated data." },
    ],
  }),
});
