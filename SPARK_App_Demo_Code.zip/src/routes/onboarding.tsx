import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { DatabaseZap, ShieldCheck, SlidersHorizontal } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { useT } from "@/i18n";
import { ScreenHeader, Toggle } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Getting started – ida 2030" },
      { name: "description", content: "Learn how ida 2030 fetches data with your consent and set up text size and read aloud." },
      { property: "og:title", content: "Getting started – ida 2030" },
      { property: "og:description", content: "Fetch instead of upload – you decide." },
    ],
  }),
  component: OnboardingScreen,
});

const SIZES = [17, 20, 24];

function OnboardingScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const t = useT();
  const navigate = useNavigate();
  const [i, setI] = useState(0);
  const [size, setSize] = useState(state.accessibility.largeText ? 1 : 0);
  const checks = state.settings.entitlementChecks;
  const notify = state.settings.notifications;
  const setChecks = (v: boolean) => dispatch({ type: "SET_SETTINGS", patch: { entitlementChecks: v } });
  const setNotify = (v: boolean) => dispatch({ type: "SET_SETTINGS", patch: { notifications: v } });
  const touchX = useRef<number | null>(null);

  const finish = () => {
    dispatch({ type: "SET_ACCESSIBILITY", patch: { largeText: size > 0 } });
    dispatch({ type: "LOG", entry: { type: "settings_changed", title: "Onboarding settings saved", purpose: `Text size ${SIZES[size]}px, entitlement checks ${checks ? "on" : "off"}, notifications ${notify ? "on" : "off"}`, actor: "self", level: "basic", channel: "app" } });
    navigate({ to: "/home" });
  };

  const slides = [
    { Icon: DatabaseZap, title: t("onb.1.title"), text: t("onb.1.text") },
    { Icon: ShieldCheck, title: t("onb.2.title"), text: t("onb.2.text") },
  ];

  return (
    <>
      <ScreenHeader title={t("onb.title")} onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex flex-1 flex-col p-5"
        onTouchStart={(e) => (touchX.current = e.touches[0]!.clientX)}
        onTouchEnd={(e) => {
          if (touchX.current == null) return;
          const dx = e.changedTouches[0]!.clientX - touchX.current;
          if (dx < -50) setI((v) => Math.min(2, v + 1));
          if (dx > 50) setI((v) => Math.max(0, v - 1));
          touchX.current = null;
        }}>
        <div className="flex justify-end">
          {i < 2 && <button type="button" onClick={() => setI(2)} className="min-h-11 px-2 font-bold text-primary">{t("common.skip")}</button>}
        </div>

        <section aria-live="polite" aria-label={`${i + 1} / 3`} className="flex-1">
          {i < 2 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              {(() => { const S = slides[i]!; return (<>
                <span className="flex size-32 items-center justify-center rounded-full bg-ida-gradient text-primary-foreground shadow-lift"><S.Icon className="size-16" aria-hidden /></span>
                <h2 className="mt-8 text-[28px] font-bold">{S.title}</h2>
                <p className="mt-3 text-lg text-muted-foreground">{S.text}</p>
              </>); })()}
            </div>
          ) : (
            <div>
              <h2 className="flex items-center gap-2 text-[26px] font-bold"><SlidersHorizontal className="size-6 text-primary" aria-hidden />{t("onb.3.title")}</h2>
              <label htmlFor="ts" className="mt-5 block font-bold">{t("onb.textSize")}</label>
              <input id="ts" type="range" min={0} max={2} step={1} value={size} onChange={(e) => setSize(Number(e.target.value))}
                aria-valuetext={`${SIZES[size]} px`} className="mt-2 h-11 w-full accent-primary" />
              <Card variant="surface" className="mt-2"><p style={{ fontSize: SIZES[size] }}>{t("onb.preview")}</p></Card>
              <div className="mt-3 divide-y divide-border">
                <Toggle checked={state.accessibility.readAloud} onChange={(v) => dispatch({ type: "SET_ACCESSIBILITY", patch: { readAloud: v } })} label={t("onb.readAloud")} />
                <Toggle checked={checks} onChange={setChecks} label={t("onb.entitlements")} description={t("onb.entitlementsDesc")} />
                <Toggle checked={notify} onChange={setNotify} label={t("onb.notifications")} />
              </div>
            </div>
          )}
        </section>

        <div className="my-4 flex justify-center gap-2" aria-hidden>
          {[0, 1, 2].map((d) => <span key={d} className={cn("h-2 rounded-full transition-all", d === i ? "w-8 bg-ida-gradient" : "w-2 bg-border")} />)}
        </div>
        {i < 2 ? <Button onClick={() => setI(i + 1)}>{t("common.next")}</Button> : <Button onClick={finish}>{t("common.start")}</Button>}
      </main>
    </>
  );
}
