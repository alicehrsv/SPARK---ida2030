import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { Gift, ShieldAlert } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { runEntitlementRules } from "@/services/entitlements";
import { ScreenHeader, Toggle, EmptyState } from "@/components/ida/extras";
import { Card, StatusBadge, type BadgeStatus } from "@/components/ida/core";
import * as Icons from "lucide-react";

export const Route = createFileRoute("/entitlements/")({
  head: () => ({
    meta: [
      { title: "Entitlements – ida 2030" },
      { name: "description", content: "Benefits you may be entitled to, hints only – the authority decides, in ida 2030." },
      { property: "og:title", content: "Entitlements – ida 2030" },
      { property: "og:description", content: "Entitlements in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: EntitlementsScreen,
});

const statusChip: Record<string, { label: string; badge: BadgeStatus }> = {
  new: { label: "New", badge: "new" },
  started: { label: "Application started", badge: "in_review" },
  submitted: { label: "Submitted", badge: "in_review" },
  approved: { label: "Approved", badge: "approved" },
  not_eligible: { label: "Not eligible", badge: "rejected" },
};

function EntitlementsScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const ran = useRef(false);

  useEffect(() => {
    if (!state.settings.entitlementChecks || ran.current) return;
    ran.current = true;
    const hints = runEntitlementRules(state.currentUserId, state);
    const fields = new Set<string>();
    for (const h of hints) {
      h.fieldsUsed.forEach((f) => fields.add(f));
      const existing = state.entitlements.find((e) => e.id === h.id);
      dispatch({ type: "UPSERT_ENTITLEMENT", item: { id: h.id, title: h.title, status: existing?.status ?? "new", reason: h.reasons[0]?.text ?? "" } });
    }
    if (hints.length > 0) {
      dispatch({ type: "LOG", entry: { type: "entitlement_check", title: "Checked possible entitlements", purpose: "Find benefits you may qualify for", dataFields: Array.from(fields), actor: "self", level: "basic", channel: "app" } });
    }
  }, [state.settings.entitlementChecks]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!state.settings.entitlementChecks) {
    return (
      <>
        <ScreenHeader title="Entitlements" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex-1 space-y-4 p-5">
          <EmptyState icon={<Gift className="size-7" />} title="Let ida check your entitlements"
            text="ida can look at your register data and suggest benefits you may be entitled to. The authority always decides – ida only gives hints." />
          <Card>
            <Toggle checked={false} onChange={(v) => dispatch({ type: "SET_SETTINGS", patch: { entitlementChecks: v } })} label="Let ida check my entitlements" description="Uses your register data to look for hints." />
          </Card>
        </main>
      </>
    );
  }

  const hints = runEntitlementRules(state.currentUserId, state);
  const hintIds = new Set(hints.map((h) => h.id));
  const visible = [
    ...hints.map((h) => ({ h, status: state.entitlements.find((e) => e.id === h.id)?.status ?? "new" })),
    ...state.entitlements.filter((e) => !hintIds.has(e.id) && e.status !== "new" && e.status !== "hidden").map((e) => ({ h: { id: e.id, title: e.title, icon: "Gift", estimate: "", deadline: undefined as string | undefined }, status: e.status })),
  ].filter((x) => x.status !== "hidden");

  return (
    <>
      <ScreenHeader title="Entitlements" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <Card variant="highlighted" className="flex items-start gap-2">
          <ShieldAlert className="size-5 shrink-0 text-primary" aria-hidden />
          <p className="text-sm font-semibold">Hints, not decisions – the authority decides. This check uses your register data and is logged.</p>
        </Card>

        {visible.length === 0 ? (
          <EmptyState icon={<Gift className="size-7" />} title="No entitlements found right now" text="ida will let you know if something changes." />
        ) : (
          <div className="space-y-3">
            {visible.map(({ h, status }) => {
              const Icon = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[h.icon] ?? Gift;
              const chip = statusChip[status] ?? statusChip["new"]!;
              return (
                <button key={h.id} type="button" onClick={() => navigate({ to: "/entitlements/$id", params: { id: h.id } })} className="block w-full text-left">
                  <Card className="flex items-start gap-3">
                    <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-surface text-primary" aria-hidden><Icon className="size-6" /></span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center justify-between gap-2">
                        <span className="block font-bold">{h.title}</span>
                        <StatusBadge status={chip.badge}>{chip.label}</StatusBadge>
                      </span>
                      {h.estimate && <span className="block text-sm text-muted-foreground">{h.estimate}</span>}
                      {h.deadline && <span className="block text-sm text-muted-foreground">Deadline: {new Date(h.deadline).toLocaleDateString("en-GB")}</span>}
                    </span>
                  </Card>
                </button>
              );
            })}
          </div>
        )}
      </main>
    </>
  );
}
