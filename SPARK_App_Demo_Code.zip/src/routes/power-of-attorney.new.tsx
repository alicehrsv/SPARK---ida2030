import * as React from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Search, ShieldCheck, FileText } from "lucide-react";
import { useApp, currentUser, type PoaArea, type PoaRight, type PowerOfAttorney } from "@/context/AppContext";
import { ScreenHeader, Stepper, Toggle, toast } from "@/components/ida/extras";
import { Button, Card, Chip, SectionTitle } from "@/components/ida/core";
import { useCriticalAction } from "@/hooks/useCriticalAction";
import { POA_AREAS } from "@/lib/acting";
import { fakeLatency } from "@/services/delay";
import { DEMO_TODAY } from "@/data/config";
import { users } from "@/data/users";

type SearchParams = { edit?: string };
export const Route = createFileRoute("/power-of-attorney/new")({
  validateSearch: (s: Record<string, unknown>): SearchParams => (typeof s["edit"] === "string" ? { edit: s["edit"] } : {}),
  head: () => ({
    meta: [
      { title: "New power of attorney – ida 2030" },
      { name: "description", content: "Grant someone a power of attorney in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "New power of attorney – ida 2030" },
      { property: "og:description", content: "Grant someone a power of attorney in ida 2030." },
    ],
  }),
  component: NewPowerOfAttorneyScreen,
});

interface Directory { id: string; name: string; relationship?: string }
const DIRECTORY: Directory[] = [
  { id: "martha", name: "Martha Gruber", relationship: "Neighbour / family friend" },
  { id: "amira", name: "Amira Hadžić" },
  { id: "patrick", name: "Patrick Steiner" },
  { id: "lena", name: "Lena Huber", relationship: "Spouse" },
  { id: "inv-1", name: "Johann Pichler" },
  { id: "inv-2", name: "Sabine Wagner" },
  { id: "inv-3", name: "Klaus Berger" },
];

const RELATIONSHIPS = ["Spouse", "Parent", "Child", "Sibling", "Neighbour / family friend", "Caregiver", "Other"];
const RIGHTS: { id: PoaRight; label: string }[] = [{ id: "view", label: "View only" }, { id: "prepare", label: "Prepare" }, { id: "submit", label: "Submit" }];

interface AreaDraft { area: PoaArea; enabled: boolean; right: PoaRight }
interface Draft {
  personId: string | null; personName: string; verified: boolean;
  relationship: string; areas: AreaDraft[]; validUntil: string;
}

const emptyDraft = (): Draft => ({
  personId: null, personName: "", verified: false, relationship: "",
  areas: POA_AREAS.map((a) => ({ area: a.id, enabled: false, right: "view" as PoaRight })),
  validUntil: "",
});

const minDate = () => { const d = new Date(DEMO_TODAY); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); };

function NewPowerOfAttorneyScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const { edit } = Route.useSearch();
  const navigate = useNavigate();
  const u = currentUser(state);
  const storageKey = `ida2030-poa-draft-${u.id}`;
  const critical = useCriticalAction("create_poa");

  const existing = edit ? state.powersOfAttorney.find((p) => p.id === edit) : undefined;

  const [step, setStep] = React.useState(0);
  const [draft, setDraft] = React.useState<Draft>(() => {
    if (existing) {
      return {
        personId: existing.personUserId ?? null, personName: existing.name, verified: true,
        relationship: existing.relationship,
        areas: POA_AREAS.map((a) => { const found = existing.areas.find((x) => x.area === a.id); return { area: a.id, enabled: !!found, right: found?.right ?? "view" }; }),
        validUntil: existing.validUntil,
      };
    }
    try { const raw = sessionStorage.getItem(storageKey); if (raw) return JSON.parse(raw) as Draft; } catch { /* ignore */ }
    return emptyDraft();
  });
  const [verifying, setVerifying] = React.useState(false);
  const [query, setQuery] = React.useState("");

  React.useEffect(() => {
    if (!existing) { try { sessionStorage.setItem(storageKey, JSON.stringify(draft)); } catch { /* ignore */ } }
  }, [draft, storageKey, existing]);

  React.useEffect(() => {
    if (critical.approved) {
      const item: PowerOfAttorney = {
        id: existing?.id ?? `poa-${Date.now()}`,
        name: draft.personName, relationship: draft.relationship,
        areas: draft.areas.filter((a) => a.enabled).map((a) => ({ area: a.area, right: a.right })),
        validUntil: draft.validUntil, status: "active", direction: "granted",
        ...(draft.personId && users.some((x) => x.id === draft.personId) ? { personUserId: draft.personId } : {}),
      };
      dispatch({ type: "ADD_POWER_OF_ATTORNEY", item });
      dispatch({ type: "LOG", entry: { type: "power_of_attorney", title: `${existing ? "Updated" : "Created"} power of attorney for ${draft.personName}`, purpose: "Grant power of attorney", actor: "self", level: "critical", channel: "app" } });
      toast.success(existing ? "Power of attorney updated" : "Power of attorney created");
      try { sessionStorage.removeItem(storageKey); } catch { /* ignore */ }
      critical.consume();
      navigate({ to: "/power-of-attorney" });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [critical.approved]);

  const steps = ["Person", "Relationship", "Areas", "Expiry", "Summary"];

  const verify = async () => {
    setVerifying(true);
    await fakeLatency();
    setVerifying(false);
    setDraft((d) => ({ ...d, verified: true }));
    toast.success("Identity confirmed with ID Austria");
  };

  const choosePerson = (p: Directory) => setDraft((d) => ({ ...d, personId: p.id, personName: p.name, verified: false, relationship: d.relationship || p.relationship || "" }));

  const results = DIRECTORY.filter((p) => p.name.toLowerCase().includes(query.toLowerCase()));

  const enabledAreas = draft.areas.filter((a) => a.enabled);
  const canNext = [
    !!draft.personName && draft.verified,
    !!draft.relationship,
    enabledAreas.length > 0,
    !!draft.validUntil,
  ];

  const generatePdf = () => {
    dispatch({ type: "ADD_DOCUMENT", item: { id: `doc-poa-${Date.now()}`, title: `Power of attorney – ${draft.personName || "..."} (PDF)`, kind: "letter", status: "verified", addedAt: DEMO_TODAY.toISOString(), category: "other", origin: "Created by ida" } });
    toast.success("PDF created and saved to your vault");
  };

  return (
    <>
      <ScreenHeader title={existing ? "Change power of attorney" : "New power of attorney"} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-5 p-5 pb-10">
        <Stepper steps={steps} current={step} />

        {step === 0 && (
          <div className="space-y-3">
            <SectionTitle>Who do you want to give this power to?</SectionTitle>
            {!draft.personId ? (
              <>
                <label className="relative block">
                  <span className="sr-only">Search by name</span>
                  <Search className="absolute start-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" aria-hidden />
                  <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by name" className="min-h-[52px] w-full rounded-2xl border border-input bg-surface ps-12 pe-4" />
                </label>
                <ul className="space-y-2">
                  {results.map((p) => (
                    <li key={p.id}>
                      <button type="button" onClick={() => choosePerson(p)} className="flex w-full items-center justify-between rounded-2xl border border-border p-4 text-start hover:bg-surface">
                        <span><span className="block font-bold">{p.name}</span>{p.relationship && <span className="block text-sm text-muted-foreground">{p.relationship}</span>}</span>
                      </button>
                    </li>
                  ))}
                  {results.length === 0 && <p className="text-muted-foreground">No match found.</p>}
                </ul>
              </>
            ) : (
              <Card>
                <p className="font-bold">{draft.personName}</p>
                {draft.verified ? (
                  <p className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-success-bg px-2.5 py-1 text-sm font-bold text-success"><ShieldCheck className="size-4" aria-hidden />Verified with ID Austria</p>
                ) : (
                  <Button className="mt-3" variant="secondary" loading={verifying} onClick={verify}>Check with ID Austria</Button>
                )}
                <Button className="mt-3" variant="ghost" size="sm" onClick={() => setDraft((d) => ({ ...d, personId: null, verified: false }))}>Choose someone else</Button>
              </Card>
            )}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-3">
            <SectionTitle>What is your relationship?</SectionTitle>
            <div className="flex flex-wrap gap-2">
              {RELATIONSHIPS.map((r) => <Chip key={r} selected={draft.relationship === r} onClick={() => setDraft((d) => ({ ...d, relationship: r }))}>{r}</Chip>)}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-1">
            <SectionTitle>Which areas can {draft.personName.split(" ")[0] || "they"} act in?</SectionTitle>
            {POA_AREAS.map((a) => {
              const row = draft.areas.find((x) => x.area === a.id)!;
              return (
                <Card key={a.id} variant="surface" className="p-3">
                  <Toggle checked={row.enabled} onChange={(v) => setDraft((d) => ({ ...d, areas: d.areas.map((x) => (x.area === a.id ? { ...x, enabled: v } : x)) }))} label={a.label} />
                  {row.enabled && (
                    <div className="mt-2 flex gap-1.5" role="group" aria-label={`Right for ${a.label}`}>
                      {RIGHTS.map((r) => (
                        <Chip key={r.id} selected={row.right === r.id} onClick={() => setDraft((d) => ({ ...d, areas: d.areas.map((x) => (x.area === a.id ? { ...x, right: r.id } : x)) }))}>{r.label}</Chip>
                      ))}
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            <SectionTitle>How long is this power of attorney valid?</SectionTitle>
            <label className="block">
              <span className="mb-1 block font-semibold">Valid until</span>
              <input type="date" min={minDate()} value={draft.validUntil} onChange={(e) => setDraft((d) => ({ ...d, validUntil: e.target.value }))} className="min-h-[52px] w-full rounded-2xl border border-input bg-surface px-4" />
            </label>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <SectionTitle>Summary</SectionTitle>
            <Card>
              <p className="font-bold">{draft.personName}</p>
              <p className="text-sm text-muted-foreground">{draft.relationship}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {enabledAreas.map((a) => <span key={a.area} className="rounded-full bg-surface px-2.5 py-1 text-xs font-bold">{POA_AREAS.find((p) => p.id === a.area)?.label} · {RIGHTS.find((r) => r.id === a.right)?.label}</span>)}
              </div>
              <p className="mt-3 text-sm text-muted-foreground">Valid until {draft.validUntil ? new Date(draft.validUntil).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" }) : "–"}</p>
            </Card>

            <Card variant="surface">
              <p className="flex items-center gap-2 font-bold"><FileText className="size-5 text-primary" aria-hidden />Some authorities need a written power of attorney</p>
              <p className="mt-1 text-sm text-muted-foreground">ida creates the PDF for you, ready to print or send.</p>
              <Button className="mt-3" variant="secondary" onClick={generatePdf}>Create PDF</Button>
            </Card>

            <Button variant="danger" onClick={() => critical.request()}>{existing ? "Confirm changes" : "Confirm and grant power of attorney"}</Button>
          </div>
        )}

        <div className="flex gap-2">
          {step > 0 && <Button variant="ghost" onClick={() => setStep((s) => s - 1)}>Back</Button>}
          {step < steps.length - 1 && <Button disabled={!canNext[step]} onClick={() => setStep((s) => s + 1)}>Next</Button>}
        </div>
      </main>
    </>
  );
}
