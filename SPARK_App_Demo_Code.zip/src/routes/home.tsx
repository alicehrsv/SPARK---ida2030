import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Bell, Gift, BellOff, MessageCircle, Phone, ScanLine, FilePlus2, MapPin, ListChecks, Loader2, CalendarClock, FileText, Sparkles } from "lucide-react";
import { useApp, currentUser } from "@/context/AppContext";
import { IdaLogo, ListItem, toast } from "@/components/ida/extras";
import { Button, Card, SectionTitle, StatusBadge, type BadgeStatus } from "@/components/ida/core";
import { computeUrgentTask, daysUntil } from "@/lib/urgent";
import { offices } from "@/data/offices";
import { formatTime } from "@/lib/notify";
import { areaAllowed } from "@/lib/acting";

export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Home – ida 2030" },
      { name: "description", content: "Your most urgent tasks, entitlements, appointments and recent activity in ida 2030." },
      { property: "og:title", content: "Home – ida 2030" },
      { property: "og:description", content: "Your personal overview in ida 2030." },
    ],
  }),
  component: HomeScreen,
});

const statusBadge: Record<string, BadgeStatus> = { draft: "new", submitted: "in_review", in_review: "in_review", approved: "approved", rejected: "rejected" };
const statusLabel: Record<string, string> = { draft: "Draft", submitted: "Submitted", in_review: "In review", approved: "Approved", rejected: "Rejected" };

function HomeScreen() {
  const { state, setDemoOpen } = useApp();
  const router = useRouter();
  const u = currentUser(state);
  const [greeting, setGreeting] = useState("Hello");
  const [refreshing, setRefreshing] = useState(false);
  const [pull, setPull] = useState(0);
  const startY = useRef<number | null>(null);

  useEffect(() => {
    const h = new Date().getHours();
    setGreeting(h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening");
  }, []);

  const unread = state.notifications.filter((n) => !n.read).length;
  const urgent = computeUrgentTask(state);
  const tasks = [
    ...state.applications.filter((a) => a.status !== "withdrawn").map((a) => ({ key: a.id, icon: <FileText className="size-5" />, title: a.title, subtitle: a.status === "draft" ? `${a.stepsLeft ?? 1} steps left` : `Since ${formatTime(a.submittedAt ?? a.createdAt)}`, badge: statusBadge[a.status], label: statusLabel[a.status], link: `/applications/${a.id}` })),
    ...state.reminders.filter((r) => !r.done).map((r) => ({ key: r.id, icon: <CalendarClock className="size-5" />, title: r.title, subtitle: `Due in ${daysUntil(new Date(r.due))} days`, badge: "expiring" as BadgeStatus, label: "Deadline", link: r.link ?? "/reminders" })),
  ].slice(0, 3);
  const next = [...state.appointments].sort((a, b) => a.slot.localeCompare(b.slot))[0];
  const office = next && offices.find((o) => o.id === next.officeId);
  const recent = state.activityLog.slice(0, 3);

  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => { setRefreshing(false); toast.success("Everything is up to date"); }, 1000);
  };

  const quick = [
    { to: "/chat", label: "Chat with ida", Icon: MessageCircle },
    { to: "/call", label: "Call ida", Icon: Phone },
    { to: "/scan", label: "Scan a letter", Icon: ScanLine },
    { to: "/applications/catalog", label: "New application", Icon: FilePlus2 },
  ] as const;

  return (
    <main className="flex-1 pb-6"
      onTouchStart={(e) => { const sc = (e.currentTarget.parentElement?.scrollTop ?? 0); startY.current = sc <= 0 ? e.touches[0]!.clientY : null; }}
      onTouchMove={(e) => { if (startY.current != null) setPull(Math.max(0, Math.min(90, e.touches[0]!.clientY - startY.current))); }}
      onTouchEnd={() => { if (pull > 70) refresh(); setPull(0); startY.current = null; }}>
      <div className="flex justify-center overflow-hidden transition-all" style={{ height: refreshing ? 48 : pull * 0.6 }} aria-live="polite">
        {(refreshing || pull > 0) && <Loader2 className={refreshing ? "mt-3 size-6 animate-spin text-primary" : "mt-3 size-6 text-primary"} aria-label={refreshing ? "Refreshing" : "Pull to refresh"} />}
      </div>

      <header className="flex items-center justify-between px-3 pt-2">
        <IdaLogo onTripleTap={() => setDemoOpen(true)} />
        <div className="flex items-center gap-1">
          <button type="button" onClick={refresh} className="sr-only focus:not-sr-only">Refresh</button>
          <Link to="/notifications" aria-label={`Notifications, ${unread} unread`} className="relative flex size-11 items-center justify-center rounded-full hover:bg-surface">
            <Bell className="size-6" aria-hidden />
            {unread > 0 && <span className="absolute right-1 top-1 flex min-w-5 items-center justify-center rounded-full bg-ida-red px-1 text-xs font-bold text-primary-foreground">{unread}</span>}
          </Link>
        </div>
      </header>
      <div className="px-5">
        <h1 className="mt-2 text-[28px] font-bold leading-tight">{greeting}, {u.firstName}</h1>

        {urgent && (
          <div className="mt-4 rounded-2xl bg-ida-gradient p-5 text-primary-foreground shadow-lift">
            <p className="flex items-center gap-1.5 text-sm font-bold opacity-90"><Sparkles className="size-4" aria-hidden />Most urgent</p>
            <h2 className="mt-1 text-2xl font-bold leading-snug">{urgent.title}</h2>
            <p className="mt-1 opacity-90">{urgent.subtitle}</p>
            <button type="button" onClick={() => router.history.push(urgent.link)} className="mt-4 min-h-[52px] w-full rounded-2xl bg-background font-bold text-primary">Let ida handle it</button>
          </div>
        )}

        {state.settings.entitlementChecks && (areaAllowed(state, "money") || areaAllowed(state, "family")) ? (
          state.entitlements.length > 0 && (
            <Link to="/entitlements" className="mt-3 block">
              <Card variant="highlighted" className="flex items-center gap-3">
                <Gift className="size-7 text-primary" aria-hidden />
                <span className="flex-1"><span className="block font-bold">{state.entitlements.length} possible entitlements for you</span><span className="block text-sm text-muted-foreground">Hints only – the authority decides.{state.actingFor && " Shown because this power of attorney covers money & tax."}</span></span>
              </Card>
            </Link>
          )
        ) : !state.actingFor ? (
          <Link to="/profile/settings" className="mt-3 flex min-h-14 items-center gap-3 rounded-2xl bg-surface px-4 py-3">
            <BellOff className="size-5 text-primary" aria-hidden /><span className="font-semibold">Turn on entitlement alerts</span>
          </Link>
        ) : null}

        {tasks.length > 0 && (<>
          <SectionTitle>Open tasks</SectionTitle>
          <div className="-mx-3">
            {tasks.map((t) => <ListItem key={t.key} icon={t.icon} title={t.title} subtitle={t.subtitle} right={t.badge && <StatusBadge status={t.badge}>{t.label}</StatusBadge>} onClick={() => router.history.push(t.link)} />)}
          </div>
        </>)}

        {next && office && (<>
          <SectionTitle>Next appointment</SectionTitle>
          <Card>
            <p className="font-bold">{office.name}</p>
            <p className="text-muted-foreground">{next.purpose}</p>
            <p className="mt-1 text-lg font-bold text-primary">{new Date(next.slot).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", timeZone: "Europe/Vienna" })} · {new Date(next.slot).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" })}</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(office.address)}`} target="_blank" rel="noreferrer"
                className="inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl border-2 border-primary font-bold text-primary">
                <MapPin className="size-5" aria-hidden />Directions
              </a>
              <Button variant="ghost" icon={<ListChecks className="size-5" aria-hidden />} onClick={() => router.history.push("/appointments")}>Checklist</Button>
            </div>
          </Card>
        </>)}

        <SectionTitle>Quick actions</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          {quick.map(({ to, label, Icon }) => (
            <Link key={to} to={to} className="flex min-h-28 flex-col items-start justify-between rounded-2xl bg-surface p-4 font-bold hover:bg-accent">
              <span className="flex size-12 items-center justify-center rounded-xl bg-ida-gradient text-primary-foreground" aria-hidden><Icon className="size-6" /></span>
              {label}
            </Link>
          ))}
        </div>

        <SectionTitle action={<Link to="/cockpit" className="min-h-11 py-2 text-sm font-bold text-primary underline">Open Data Cockpit</Link>}>Recently</SectionTitle>
        {recent.length === 0 ? <p className="text-muted-foreground">Nothing yet.</p> : (
          <ul className="space-y-2">
            {recent.map((e) => (
              <li key={e.id} className="rounded-2xl border border-border p-3">
                <p className="font-semibold">{e.title}</p>
                <p className="text-sm text-muted-foreground">{formatTime(e.timestamp)} · {e.channel === "phone agent" ? "by phone" : "in the app"}</p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
