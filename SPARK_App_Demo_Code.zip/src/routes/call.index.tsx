import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Volume2, VolumeX, MonitorSmartphone, UserRound, PhoneOff, Send, Info } from "lucide-react";
import { useApp, currentUser, newId } from "@/context/AppContext";
import { ask, render, detectIntent, intentService, type RenderedAnswer } from "@/services/ai";
import { getService } from "@/data/knowledge";
import { registersByUser } from "@/data/registers";
import { DEMO_TODAY } from "@/data/config";
import { IdaAvatar } from "@/components/ida/extras";
import { canSpeak, getRecognitionCtor, listenOnce, speak, stopSpeaking } from "@/lib/speech";
import { getCall, startCall, endCall, fmtDuration, isNo, isPersonal, isRepeat, isSlower, isYes, wantsRead, wantsShow, type CallSession } from "@/lib/callSession";
import { cn } from "@/lib/utils";

type Search = { transfer?: string; resume?: string };
export const Route = createFileRoute("/call/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["transfer"] === "string" ? { transfer: s["transfer"] } : {}),
    ...(typeof s["resume"] === "string" ? { resume: s["resume"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Call ida – ida 2030" },
      { name: "description", content: "Talk to ida by voice: the phone agent with the same rules as the chat." },
      { property: "og:title", content: "Call ida – ida 2030" },
      { property: "og:description", content: "ida phone agent – AI assistant by voice." },
    ],
  }),
  component: CallScreen,
});

type Pending =
  | { kind: "confirm_address"; address: string }
  | { kind: "read_or_show"; text: string }
  | { kind: "send"; serviceTitle: string; action: string }
  | null;

const GREETING = "Hi, I'm ida, an AI assistant. You can ask for a person at any time.";
const GREETING_DE = "Hallo, ich bin ida, eine KI-Assistentin. Sie können jederzeit nach einem Menschen fragen.";

function CallScreen() {
  const { state, dispatch } = useApp();
  const { transfer, resume } = Route.useSearch();
  const navigate = useNavigate();
  const de = state.language === "de";
  const loggedIn = state.isLoggedIn;
  const user = currentUser(state);
  const easy = state.accessibility.easyLanguage;

  const sess = useRef<CallSession | null>(null);
  const [lines, setLines] = useState<{ who: "ida" | "you"; text: string }[]>([]);
  const [elapsed, setElapsed] = useState(0);
  const [speaking, setSpeaking] = useState(false);
  const [listening, setListening] = useState(false);
  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState(true);
  const [card, setCard] = useState<string | null>(null);
  const [banner, setBanner] = useState(true);
  const [transferring, setTransferring] = useState(transfer === "1");
  const [typed, setTyped] = useState("");
  const [voiceIn, setVoiceIn] = useState(false);
  const [voiceOut, setVoiceOut] = useState(true);
  const pending = useRef<Pending>(null);
  const last = useRef<string[]>([]);
  const rate = useRef(easy ? 0.8 : 1);
  const stopListen = useRef<() => void>(() => {});
  const alive = useRef(true);
  const misses = useRef(0);

  const add = (who: "ida" | "you", text: string) => {
    sess.current?.lines.push({ who, text });
    setLines((l) => [...l, { who, text }]);
  };

  const say = async (sentences: string[]) => {
    last.current = sentences;
    setSpeaking(true);
    for (const s of sentences) {
      if (!alive.current) return;
      add("ida", s);
      if (speaker) await speak(s, state.language, rate.current);
      else await new Promise((r) => setTimeout(r, 900));
    }
    setSpeaking(false);
    listen();
  };

  const listen = () => {
    if (!alive.current || muted || !getRecognitionCtor()) return;
    setListening(true);
    const l = listenOnce(state.language);
    stopListen.current = l.stop;
    l.promise.then((t) => {
      setListening(false);
      if (t && alive.current) { misses.current = 0; handle(t); }
      else if (++misses.current >= 2) setVoiceIn(false); // speech recognition not working: show text input
    });
  };

  const handle = async (t: string) => {
    add("you", t);
    const s = sess.current!;
    const lower = ` ${t.toLowerCase()} `;
    if (isRepeat(lower)) return say(last.current);
    if (isSlower(lower)) { rate.current = 0.7; return say(last.current); }
    if (detectIntent(t) === "person") return doTransfer();

    const p = pending.current;
    if (p?.kind === "confirm_address") {
      pending.current = null;
      if (isYes(lower)) {
        s.pending = { kind: "send", serviceTitle: "Change of address", action: "change_personal_data" };
        await say([de ? "Dafür brauche ich kurz einen Gesichtsscan auf Ihrem Bildschirm." : "For this I need a quick face scan on your screen."]);
        stopListen.current(); stopSpeaking();
        navigate({ to: "/facematch", search: { returnTo: "/call?resume=1", action: "change_personal_data" } });
        return;
      }
      return say([de ? "Gut. Bitte sagen Sie mir, was nicht stimmt, oder ändern Sie es in der App." : "Okay. Please tell me what is wrong, or change it in the app."]);
    }
    if (p?.kind === "send") {
      pending.current = null; s.pending = null;
      if (isYes(lower)) {
        const id = newId();
        dispatch({ type: "UPSERT_APPLICATION", item: { id, procedureId: "change-address", title: p.serviceTitle, status: "submitted", createdAt: DEMO_TODAY.toISOString(), submittedAt: DEMO_TODAY.toISOString() } });
        dispatch({ type: "LOG", entry: { type: "submission", title: `Submitted "${p.serviceTitle}" by phone`, purpose: p.serviceTitle, authority: "Registration office (Meldeamt)", actor: "self", level: "critical", channel: "phone agent" } });
        dispatch({ type: "CONSUME_CRITICAL" });
        s.actions.push({ label: `Submitted: ${p.serviceTitle}`, link: `/applications/${id}` });
        s.nextSteps.push("You will get a confirmation in your notifications.");
        return say([de ? "Erledigt. Ich habe es gesendet." : "Done. I have sent it.", de ? "Sie bekommen eine Bestätigung." : "You will get a confirmation."]);
      }
      dispatch({ type: "CONSUME_CRITICAL" });
      return say([de ? "In Ordnung, ich sende nichts." : "Alright, I won't send anything."]);
    }
    if (p?.kind === "read_or_show") {
      pending.current = null;
      if (wantsShow(lower)) { setCard(p.text); return say([de ? "Ich zeige es auf dem Bildschirm." : "I'm showing it on your screen."]); }
      if (wantsRead(lower)) return say([p.text]);
      pending.current = p;
      return say([de ? "Soll ich es vorlesen oder am Bildschirm zeigen?" : "Shall I read it aloud or show it on screen?"]);
    }

    const spec = await ask(t);
    const intent = spec.intent;
    const svc = intentService[intent] ? getService(intentService[intent]!) : undefined;
    if (svc && !s.topics.includes(svc.title.en)) s.topics.push(svc.title.en);
    const personal = isPersonal(lower) || intent === "criminal";

    if (personal && !loggedIn && intent !== "unknown") {
      return say([de ? "Bitte melden Sie sich zuerst in der App an." : "Please log in in the app first.", de ? "Allgemeine Fragen beantworte ich gerne." : "I'm happy to answer general questions."]);
    }
    if (loggedIn && intent === "address" && personal) {
      const addr = registersByUser[user.id]?.find((r) => r.id === "zmr")?.fields[0]?.value ?? "";
      pending.current = { kind: "confirm_address", address: addr };
      return say([de ? `Ihre Adresse ist ${addr}.` : `Your address is ${addr}.`, de ? "Stimmt das?" : "Correct?"]);
    }
    if (loggedIn && intent === "criminal") {
      const v = registersByUser[user.id]?.find((r) => r.id === "criminal")?.fields[0]?.value ?? "";
      pending.current = { kind: "read_or_show", text: de ? `Strafregister: ${v === "No entries" ? "keine Einträge" : v}.` : `Criminal record: ${v}.` };
      return say([de ? "Das sind sensible Daten." : "This is sensitive data.", de ? "Soll ich es vorlesen oder am Bildschirm zeigen?" : "Shall I read it aloud or show it on screen?"]);
    }
    const r: RenderedAnswer = render(spec, { userId: loggedIn ? user.id : null, language: state.language, easy: true });
    if (svc) s.nextSteps.push(`${svc.title.en}: ${svc.inPerson ? "an in-person visit is needed" : "can be done online in the app"}`);
    setCard(null);
    return say(r.sentences.slice(0, 4));
  };

  const doTransfer = () => {
    stopListen.current(); stopSpeaking();
    if (sess.current) { sess.current.transferred = true; sess.current.actions.push({ label: "Transferred to a service employee (simulated)" }); }
    dispatch({ type: "LOG", entry: { type: "handover", title: "Transferred to a person", purpose: sess.current?.topics.join(", ") || "General help", actor: "self", level: loggedIn ? "basic" : "public", channel: "phone agent" } });
    setTransferring(true);
  };

  const hangUp = () => {
    alive.current = false; stopListen.current(); stopSpeaking(); endCall();
    navigate({ to: "/call/summary" });
  };

  useEffect(() => {
    setVoiceIn(!!getRecognitionCtor());
    setVoiceOut(canSpeak());
    alive.current = true;
    const existing = getCall();
    if (resume && existing && !existing.endedAt) {
      sess.current = existing;
      setLines(existing.lines.slice(-4));
      setBanner(false);
      if (existing.pending && state.criticalApproval?.action === existing.pending.action) {
        pending.current = existing.pending;
        say([de ? "Danke, das hat geklappt." : "Thanks, that worked.", de ? "Soll ich es senden?" : "Shall I send it?"]);
      } else {
        say([de ? "Der Gesichtsscan wurde nicht abgeschlossen. Ich sende nichts." : "The face scan was not completed. I won't send anything."]);
      }
    } else {
      sess.current = startCall(!loggedIn);
      if (transfer !== "1") say([de ? GREETING_DE : GREETING]);
    }
    const i = setInterval(() => setElapsed(Date.now() - (sess.current?.startedAt ?? Date.now())), 1000);
    const b = setTimeout(() => setBanner(false), 8000);
    return () => { clearInterval(i); clearTimeout(b); alive.current = false; stopListen.current(); stopSpeaking(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const caps = lines.slice(-2);

  if (transferring) {
    const s = sess.current;
    return (
      <main className="flex flex-1 flex-col bg-call p-6 text-primary-foreground">
        <p className="text-center text-sm font-bold opacity-80">{fmtDuration(elapsed)}</p>
        <div className="mt-10 flex flex-col items-center text-center">
          <span className="flex size-28 items-center justify-center rounded-full bg-primary-foreground/15 animate-pulse"><UserRound className="size-14" aria-hidden /></span>
          <h1 className="mt-6 text-2xl font-bold">Connecting you to a person…</h1>
          <p className="mt-2 opacity-90">Simulated live transfer · Service centre</p>
        </div>
        <section className="mt-8 rounded-2xl bg-primary-foreground/10 p-5" aria-label="Case summary">
          <h2 className="font-bold">Case summary for the employee</h2>
          <ul className="mt-2 list-disc space-y-1 ps-5">
            <li>Caller: {loggedIn ? `${user.firstName} ${user.lastName} (logged in with ID Austria)` : "not logged in"}</li>
            <li>Topics: {s?.topics.join(", ") || "general question"}</li>
            <li>Language: {state.language.toUpperCase()}</li>
            {(s?.lines.filter((l) => l.who === "you").slice(-2) ?? []).map((l, i) => <li key={i}>Said: “{l.text}”</li>)}
          </ul>
        </section>
        <Link to="/help" className="mx-auto mt-4 min-h-11 text-sm font-bold underline">More help options</Link>
        <button type="button" onClick={hangUp} className="mx-auto mt-4 flex size-16 items-center justify-center rounded-full bg-security" aria-label="End call"><PhoneOff className="size-7" aria-hidden /></button>
      </main>
    );
  }

  const btn = "flex size-16 items-center justify-center rounded-full bg-primary-foreground/15 hover:bg-primary-foreground/25";
  return (
    <main className="relative flex flex-1 flex-col bg-call px-5 pb-6 pt-4 text-primary-foreground">
      <p className="text-center text-sm font-bold opacity-80" aria-label={`Call duration ${fmtDuration(elapsed)}`}>ida · {fmtDuration(elapsed)}</p>
      {banner && (
        <div role="status" className="mt-3 flex items-start gap-2 rounded-2xl bg-primary-foreground/15 p-3 text-sm font-semibold">
          <Info className="mt-0.5 size-4 shrink-0" aria-hidden />{de ? GREETING_DE : GREETING}
        </div>
      )}

      <div className="flex flex-1 flex-col items-center justify-center">
        <div className="relative">
          <IdaAvatar size={150} speaking={speaking} />
        </div>
        <div className="mt-6 flex h-10 items-end gap-1.5" aria-hidden>
          {listening && [0, 1, 2, 3, 4, 5, 6].map((i) => <span key={i} className="h-10 w-1.5 origin-bottom rounded-full bg-primary-foreground animate-ida-wave" style={{ animationDelay: `${i * 110}ms` }} />)}
        </div>
        <p className="mt-1 text-sm font-bold opacity-80" aria-live="polite">{speaking ? "ida is speaking" : listening ? "Listening…" : muted ? "Muted" : ""}</p>
      </div>

      {card && (
        <div className="mb-3 rounded-2xl bg-background p-4 text-foreground shadow-lift">
          <p className="text-sm font-bold text-muted-foreground">On screen</p>
          <p className="mt-1 text-lg font-semibold">{card}</p>
        </div>
      )}

      <section aria-label="Live captions" aria-live="polite" className="mb-4 min-h-24 space-y-1">
        {caps.map((c, i) => (
          <p key={i} className={cn("text-[22px] leading-snug", c.who === "you" ? "text-end opacity-80" : "font-semibold")}>
            <span className="sr-only">{c.who === "ida" ? "ida: " : "You: "}</span>{c.text}
          </p>
        ))}
      </section>

      {!voiceIn && (
        <form onSubmit={(e) => { e.preventDefault(); if (typed.trim()) { handle(typed); setTyped(""); } }} className="mb-4 flex gap-2">
          <label htmlFor="call-input" className="sr-only">Say something to ida</label>
          <input id="call-input" value={typed} onChange={(e) => setTyped(e.target.value)} placeholder="Type what you want to say…"
            className="min-h-12 min-w-0 flex-1 rounded-full bg-background px-4 text-foreground" />
          <button type="submit" aria-label="Send" className="flex size-12 items-center justify-center rounded-full bg-ida-gradient"><Send className="size-5" aria-hidden /></button>
        </form>
      )}
      {voiceIn && (
        <button type="button" onClick={() => { stopListen.current(); setVoiceIn(false); }} className="mx-auto mb-3 min-h-11 text-sm font-bold underline">Type instead</button>
      )}
      {!voiceOut && <p className="mb-2 text-center text-sm opacity-80">Voice output is not available – read the captions.</p>}

      <div className="grid grid-cols-5 gap-1 text-center text-xs font-semibold">
        <button type="button" onClick={() => { setMuted(!muted); if (!muted) stopListen.current(); else listen(); }} aria-pressed={muted} className="flex flex-col items-center gap-1">
          <span className={btn}>{muted ? <MicOff className="size-6" aria-hidden /> : <Mic className="size-6" aria-hidden />}</span>Mute
        </button>
        <button type="button" onClick={() => { setSpeaker(!speaker); if (speaker) stopSpeaking(); }} aria-pressed={speaker} className="flex flex-col items-center gap-1">
          <span className={btn}>{speaker ? <Volume2 className="size-6" aria-hidden /> : <VolumeX className="size-6" aria-hidden />}</span>Speaker
        </button>
        <button type="button" onClick={() => setCard(last.current.join(" ") || null)} className="flex flex-col items-center gap-1">
          <span className={btn}><MonitorSmartphone className="size-6" aria-hidden /></span>Show on screen
        </button>
        <button type="button" onClick={doTransfer} className="flex flex-col items-center gap-1">
          <span className={btn}><UserRound className="size-6" aria-hidden /></span>Talk to a person
        </button>
        <button type="button" onClick={hangUp} className="flex flex-col items-center gap-1">
          <span className="flex size-16 items-center justify-center rounded-full bg-security"><PhoneOff className="size-6" aria-hidden /></span>End call
        </button>
      </div>
    </main>
  );
}
