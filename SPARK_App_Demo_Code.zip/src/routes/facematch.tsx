import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import * as React from "react";
import { CheckCircle2, ScanFace, ShieldAlert, AlertTriangle } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { ScreenHeader, Sheet } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { offices } from "@/data/offices";

type Search = { returnTo?: string; action?: string };

export const Route = createFileRoute("/facematch")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["returnTo"] === "string" ? { returnTo: s["returnTo"] } : {}),
    ...(typeof s["action"] === "string" ? { action: s["action"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Confirm it's you – ida 2030" },
      { name: "description", content: "Face match to confirm a critical action in ida 2030." },
      { property: "og:title", content: "Confirm it's you – ida 2030" },
      { property: "og:description", content: "Simulated face match for critical actions." },
    ],
  }),
  component: FaceMatchScreen,
});

/** Turns an action id into a plain-English description of what is being confirmed. */
function describeAction(action: string | undefined): string {
  if (!action) return "this critical action";
  if (action === "create_poa") return "granting a power of attorney";
  if (action === "view_criminal_record") return "viewing your criminal record certificate";
  if (action === "first_login_new_device") return "signing in on a new device";
  const [kind, id] = action.split(":");
  if (kind === "submit") return `submitting your application${id ? ` (${id})` : ""}`;
  if (kind === "withdraw") return `withdrawing your application${id ? ` (${id})` : ""}`;
  if (kind === "revoke_poa") return `revoking a power of attorney${id ? ` (${id})` : ""}`;
  return "this critical action";
}

const STEPS = ["Look at the camera", "Blink", "Turn your head slightly"] as const;
const STEP_MS = 1300; // 3 steps ~ well within the 4s total
const TOTAL_MS = 4000;

function LivenessRing({ progress }: { progress: number }) {
  const r = 70;
  const c = 2 * Math.PI * r;
  return (
    <svg width={160} height={160} viewBox="0 0 160 160" className="absolute inset-0" aria-hidden>
      <circle cx={80} cy={80} r={r} fill="none" stroke="var(--border)" strokeWidth={6} />
      <circle
        cx={80} cy={80} r={r} fill="none" stroke="var(--primary)" strokeWidth={6} strokeLinecap="round"
        strokeDasharray={c} strokeDashoffset={c * (1 - progress)}
        transform="rotate(-90 80 80)" style={{ transition: "stroke-dashoffset 0.2s linear" }}
      />
    </svg>
  );
}

function CameraPreview({ stepLabel, progress }: { stepLabel: string; progress: number }) {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const [hasCamera, setHasCamera] = React.useState<boolean | null>(null);

  React.useEffect(() => {
    let stream: MediaStream | null = null;
    let cancelled = false;
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("no camera API");
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        setHasCamera(true);
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch {
        if (!cancelled) setHasCamera(false);
      }
    })();
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
      if (videoRef.current) videoRef.current.srcObject = null;
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative flex size-40 items-center justify-center">
        <LivenessRing progress={progress} />
        <span className="flex size-32 items-center justify-center overflow-hidden rounded-full bg-surface">
          {hasCamera ? (
            <video ref={videoRef} autoPlay playsInline muted className="size-full scale-x-[-1] object-cover" aria-label="Live camera preview (not recorded)" />
          ) : (
            <ScanFace className="size-16 text-primary" aria-hidden />
          )}
        </span>
      </div>
      <p className="text-xl font-bold" aria-live="polite">{stepLabel}</p>
      {hasCamera === false && <p className="text-sm text-muted-foreground">No camera available – showing a simulated scan.</p>}
    </div>
  );
}

function FaceMatchScreen() {
  const { returnTo, action } = Route.useSearch();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const router = useRouter();

  const [phase, setPhase] = React.useState<"scanning" | "success" | "failure">("scanning");
  const [elapsed, setElapsed] = React.useState(0);
  const [helpOpen, setHelpOpen] = React.useState(false);
  const simulateFail = state.demoFaceFail;

  const finish = React.useCallback(() => {
    dispatch({
      type: "LOG",
      entry: { type: "face_match", title: "Face match: success", purpose: describeAction(action), actor: "self", level: "critical", channel: "app" },
    });
    if (action === "first_login_new_device") dispatch({ type: "SET_DEVICE_VERIFIED", value: true });
    else if (action) dispatch({ type: "APPROVE_CRITICAL", action, path: (returnTo ?? "/home").split("?")[0]! });
    if (returnTo) router.history.push(returnTo);
    else navigate({ to: "/home" });
  }, [action, returnTo, dispatch, navigate, router]);

  React.useEffect(() => {
    if (phase !== "scanning") return;
    const tick = setInterval(() => setElapsed((e) => Math.min(e + 100, TOTAL_MS)), 100);
    const timer = setTimeout(() => {
      if (simulateFail) {
        dispatch({ type: "LOG", entry: { type: "face_match", title: "Face match: failed", purpose: describeAction(action), actor: "self", level: "critical", channel: "app" } });
        dispatch({ type: "SET_FACE_FAIL", value: false });
        setPhase("failure");
      } else {
        setPhase("success");
      }
    }, TOTAL_MS);
    return () => { clearInterval(tick); clearTimeout(timer); };
  }, [phase, simulateFail, action, dispatch]);

  React.useEffect(() => {
    if (phase !== "success") return;
    const t = setTimeout(finish, 900);
    return () => clearTimeout(t);
  }, [phase, finish]);

  const stepIndex = Math.min(STEPS.length - 1, Math.floor(elapsed / STEP_MS));
  const progress = elapsed / TOTAL_MS;
  const office = offices.find((o) => o.id === "digital-austria")!;

  return (
    <>
      <ScreenHeader title="Confirm it's you" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex flex-1 flex-col gap-4 p-5">
        <Card variant="security" className="flex items-start gap-3">
          <ShieldAlert className="mt-0.5 size-6 shrink-0 text-security" aria-hidden />
          <div>
            <p className="font-bold text-security">Critical action – confirm it's you</p>
            <p className="mt-1 text-foreground">You're confirming: {describeAction(action)}.</p>
          </div>
        </Card>

        {phase === "scanning" && (
          <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
            <CameraPreview stepLabel={STEPS[stepIndex]!} progress={progress} />
          </div>
        )}

        {phase === "success" && (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center" role="status">
            <CheckCircle2 className="size-20 text-success" aria-hidden />
            <p className="text-xl font-bold">Confirmed – it's you</p>
          </div>
        )}

        {phase === "failure" && (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 text-center">
            <AlertTriangle className="size-16 text-security" aria-hidden />
            <p className="text-xl font-bold">We couldn't confirm it's you</p>
            <p className="text-muted-foreground">Make sure your face is well lit and centred, then try again.</p>
            <Button onClick={() => { setElapsed(0); setPhase("scanning"); }}>Try again</Button>
          </div>
        )}

        <p className="text-center text-sm text-muted-foreground">
          Compared with your passport chip photo on this device. No face data is stored or sent.
        </p>

        {phase !== "success" && (
          <div className="mt-auto space-y-2">
            <button type="button" onClick={() => setHelpOpen(true)} className="min-h-11 w-full font-bold text-primary underline">
              I can't do a face scan
            </button>
            <Button variant="ghost" onClick={() => router.history.back()}>Cancel</Button>
          </div>
        )}
      </main>

      <Sheet open={helpOpen} onOpenChange={setHelpOpen} title="Verify at a service point">
        <p className="text-muted-foreground">
          If you can't use the camera, you can complete a one-time identity verification in person at a Digital Austria service point.
        </p>
        <Card variant="surface" className="mt-4">
          <p className="font-bold">{office.name}</p>
          <p className="text-sm text-muted-foreground">{office.address}</p>
          <p className="text-sm text-muted-foreground">{office.openingHours}</p>
        </Card>
        <div className="mt-4 space-y-2">
          <Button onClick={() => { setHelpOpen(false); navigate({ to: "/appointments/book/$officeId", params: { officeId: office.id } }); }}>
            Book appointment
          </Button>
          <Button variant="ghost" onClick={() => setHelpOpen(false)}>Cancel</Button>
        </div>
      </Sheet>
    </>
  );
}
