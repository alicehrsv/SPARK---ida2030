import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, RefreshCw, Flag, FilePlus2, History, ScanFace, Lock } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { DEMO_TODAY } from "@/data/config";
import { ScreenHeader, toast } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { useConsent } from "@/components/ida/ConsentSheet";
import { RegisterIcon } from "@/components/ida/RegisterIcon";
import { useCriticalAction } from "@/hooks/useCriticalAction";
import { isMasked, unmask } from "@/lib/registers";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/vault/register/$registerId")({
  head: () => ({
    meta: [
      { title: "Register data – ida 2030" },
      { name: "description", content: "Your data from an official register (simulated), with who accessed it." },
      { property: "og:title", content: "Register data – ida 2030" },
      { property: "og:description", content: "Your register data in ida 2030." },
    ],
  }),
  component: RegisterScreen,
});

function RegisterScreen() {
  const { registerId } = Route.useParams();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const consent = useConsent();
  const critical = useCriticalAction("view_criminal_record");
  const [shown, setShown] = useState<Record<string, boolean>>({});
  const r = (registersByUser[state.currentUserId] ?? []).find((x) => x.id === registerId);
  const isCritical = r?.sensitivity === "critical";
  const unlocked = !isCritical || critical.approved;

  // Log the critical view once; the approval expires when the user leaves this screen (see AppShell).
  useEffect(() => {
    if (isCritical && critical.approved && r) {
      dispatch({ type: "LOG", entry: { type: "register_query", title: `Viewed ${r.name.en}`, purpose: "View criminal record data", register: r.name.en, dataFields: r.fields.map((f) => f.label), authority: r.authority, actor: "self", level: "critical", channel: "app" } });
      dispatch({ type: "MARK_FETCHED", registerIds: [r.id], at: DEMO_TODAY.toISOString() });
    }
  }, [isCritical, critical.approved]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!r) return (<><ScreenHeader title="Register" back /><main className="p-5">This register is not available for this resident.</main></>);
  const fetched = state.fetchedRegisters[r.id];

  const refresh = async () => {
    const ok = await consent({ registers: [r.id], purpose: "Refresh my vault data" });
    if (ok) toast.success("Updated from the register");
  };

  return (
    <>
      <ScreenHeader title={r.name.en} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <div className="flex items-start gap-3">
          <span className={cn("flex size-14 shrink-0 items-center justify-center rounded-2xl", isCritical ? "bg-security-bg text-security" : "bg-surface text-primary")}><RegisterIcon name={r.icon} className="size-7" /></span>
          <div>
            <p lang="de" className="font-semibold text-muted-foreground">{r.name.de}</p>
            <p className="text-sm">{r.authority}</p>
            <div className="mt-1 flex flex-wrap gap-2 text-sm">
              <span className="rounded-full bg-warning-bg px-2 py-0.5 font-bold text-warning">simulated</span>
              <span className="text-muted-foreground">Last updated {new Date(r.lastUpdated).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}</span>
            </div>
            {fetched && <p className="text-sm text-muted-foreground">Fetched into your vault on {new Date(fetched).toLocaleDateString("en-GB")}</p>}
          </div>
        </div>

        <Card className={cn("relative overflow-hidden p-0", !unlocked && "min-h-56")}>
          <dl className={cn("divide-y divide-border", !unlocked && "select-none blur-md")} aria-hidden={!unlocked}>
            {r.fields.map((f) => {
              const masked = isMasked(f.value);
              const show = shown[f.label];
              return (
                <div key={f.label} className="flex items-center gap-2 px-5 py-3">
                  <div className="min-w-0 flex-1">
                    <dt className="text-sm text-muted-foreground">{f.label}</dt>
                    <dd className="font-semibold">{masked && show ? unmask(f.value) : f.value}</dd>
                  </div>
                  {masked && unlocked && (
                    <button type="button" onClick={() => setShown((s) => ({ ...s, [f.label]: !show }))} aria-label={show ? `Hide ${f.label}` : `Show ${f.label}`} className="flex size-11 items-center justify-center rounded-full hover:bg-surface">
                      {show ? <EyeOff className="size-5" aria-hidden /> : <Eye className="size-5" aria-hidden />}
                    </button>
                  )}
                </div>
              );
            })}
          </dl>
          {!unlocked && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-security-bg/80 p-5 text-center">
              <Lock className="size-8 text-security" aria-hidden />
              <p className="font-bold">Sensitive data. A face scan is needed to view it – valid for this view only.</p>
              <Button size="inline" variant="danger" icon={<ScanFace className="size-5" aria-hidden />} onClick={() => critical.request()}>Verify with face scan</Button>
            </div>
          )}
        </Card>

        <div className="space-y-2">
          {!isCritical && <Button variant="secondary" icon={<RefreshCw className="size-5" aria-hidden />} onClick={refresh}>Refresh from register</Button>}
          <Button variant="ghost" icon={<Flag className="size-5" aria-hidden />} onClick={() => navigate({ to: "/help", search: { topic: `Error in ${r.name.en}: ` } })}>Report an error</Button>
          {!isCritical && <Button variant="ghost" icon={<FilePlus2 className="size-5" aria-hidden />} onClick={() => navigate({ to: "/applications/catalog" })}>Use in an application</Button>}
        </div>

        <button type="button" onClick={() => navigate({ to: "/cockpit", search: { register: r.name.en } })} className="flex min-h-11 items-center gap-2 font-bold text-primary underline">
          <History className="size-5" aria-hidden />Who accessed this?
        </button>
      </main>
    </>
  );
}
