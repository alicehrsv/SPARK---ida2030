import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import * as Icons from "lucide-react";
import { Check, Gift } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { runEntitlementRules } from "@/services/entitlements";
import { ScreenHeader, Sheet, AiBadge } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";

export const Route = createFileRoute("/entitlements/$id")({
  head: () => ({
    meta: [
      { title: "Entitlement – ida 2030" },
      { name: "description", content: "Why ida thinks you may qualify for a benefit, in ida 2030." },
      { property: "og:title", content: "Entitlement – ida 2030" },
      { property: "og:description", content: "Entitlement in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: EntitlementScreen,
});

function EntitlementScreen() {
  const { id } = Route.useParams();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const [easyOpen, setEasyOpen] = useState(false);
  const hint = runEntitlementRules(state.currentUserId, state).find((h) => h.id === id);
  const entitlement = state.entitlements.find((e) => e.id === id);

  if (!hint) return (<><ScreenHeader title="Entitlement" back /><main className="p-5">This hint is no longer available.</main></>);

  const Icon = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[hint.icon] ?? Gift;

  const notInterested = () => {
    dispatch({ type: "UPSERT_ENTITLEMENT", item: { id: hint.id, title: hint.title, status: "hidden", reason: entitlement?.reason ?? hint.reasons[0]?.text ?? "" } });
    dispatch({ type: "LOG", entry: { type: "entitlement_check", title: `Not interested: ${hint.title}`, purpose: "Manage entitlement hints", actor: "self", level: "public", channel: "app" } });
    navigate({ to: "/entitlements" });
  };

  return (
    <>
      <ScreenHeader title={hint.title} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <div className="flex items-center gap-3">
          <span className="flex size-14 items-center justify-center rounded-2xl bg-surface text-primary" aria-hidden><Icon className="size-7" /></span>
          <div>
            <p className="font-bold">{hint.title}</p>
            {hint.automatic && <p className="text-sm text-muted-foreground">Usually paid automatically</p>}
          </div>
        </div>

        <Card>
          <h2 className="mb-2 text-lg font-bold">Why ida thinks you may qualify</h2>
          <ul className="space-y-2">
            {hint.reasons.map((r) => (
              <li key={r.text} className="flex items-start gap-2">
                <Check className="mt-0.5 size-5 shrink-0 text-success" aria-hidden />
                <span><span className="block">{r.text}</span><span className="block text-sm text-muted-foreground">Source: {r.source}</span></span>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <h2 className="text-lg font-bold">What you could receive</h2>
          <p className="mt-1 text-primary font-bold">{hint.estimate}</p>
          <p className="mt-2 text-sm text-muted-foreground">ida only gives hints – the authority decides the final amount.</p>
        </Card>

        {hint.deadline && (
          <Card>
            <h2 className="text-lg font-bold">Deadline</h2>
            <p className="mt-1">{new Date(hint.deadline).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</p>
          </Card>
        )}

        {hint.missing.length > 0 && (
          <Card>
            <h2 className="text-lg font-bold">What is still missing</h2>
            <ul className="mt-1 list-inside list-disc text-muted-foreground">{hint.missing.map((m) => <li key={m}>{m}</li>)}</ul>
          </Card>
        )}

        <AiBadge source="ida's entitlement rules engine based on your register data" />

        <div className="space-y-2 pt-2">
          <Button onClick={() => navigate({ to: "/entitlements/check/$id", params: { id: hint.id } })}>Check & apply</Button>
          <Button variant="ghost" onClick={() => setEasyOpen(true)}>Explain in Easy Language</Button>
          <Button variant="ghost" onClick={notInterested}>Not interested</Button>
        </div>
      </main>

      <Sheet open={easyOpen} onOpenChange={setEasyOpen} title="Easy Language">
        <p className="text-lg">{hint.easy}</p>
      </Sheet>
    </>
  );
}
