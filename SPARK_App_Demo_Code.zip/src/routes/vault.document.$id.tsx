import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { FileText, Share2, Trash2 } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { ScreenHeader, toast } from "@/components/ida/extras";
import { Button, Card, StatusBadge } from "@/components/ida/core";
import { CATEGORY_FILTERS } from "@/lib/registers";

export const Route = createFileRoute("/vault/document/$id")({
  head: () => ({
    meta: [
      { title: "Document – ida 2030" },
      { name: "description", content: "Preview and details of a document in your ida vault." },
      { property: "og:title", content: "Document – ida 2030" },
      { property: "og:description", content: "A document in your ida vault." },
    ],
  }),
  component: DocumentScreen,
});

const d8 = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

function DocumentScreen() {
  const { id } = Route.useParams();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const doc = state.vaultDocuments.find((d) => d.id === id);
  if (!doc) return (<><ScreenHeader title="Document" back /><main className="p-5">Document not found.</main></>);
  const isUpload = doc.kind !== "register";

  return (
    <>
      <ScreenHeader title="Document" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <div className="flex aspect-[3/4] max-h-80 w-full flex-col items-center justify-center rounded-2xl border border-border bg-surface p-5" role="img" aria-label={`Preview of ${doc.title}`}>
          <FileText className="size-14 text-primary" aria-hidden />
          <p className="mt-3 text-center font-bold">{doc.title}</p>
          {doc.note && <p className="mt-3 line-clamp-6 whitespace-pre-wrap text-center text-sm text-muted-foreground">{doc.note}</p>}
        </div>
        <Card>
          <dl className="space-y-2">
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Status</dt><dd><StatusBadge status={doc.status} /></dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Origin</dt><dd className="text-end font-semibold">{doc.origin ?? "Uploaded by you"}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Category</dt><dd className="font-semibold">{CATEGORY_FILTERS.find((c) => c.id === doc.category)?.label ?? "Other"}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Added</dt><dd className="font-semibold">{d8(doc.addedAt)}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Expiry</dt><dd className="font-semibold">{doc.expiry ? d8(doc.expiry) : "None"}</dd></div>
            {doc.fileName && <div className="flex justify-between gap-3"><dt className="text-muted-foreground">File</dt><dd className="truncate font-semibold">{doc.fileName}</dd></div>}
          </dl>
        </Card>
        <Button variant="secondary" icon={<Share2 className="size-5" aria-hidden />} onClick={() => toast.success("PDF created and ready to share (simulated)")}>Share as PDF</Button>
        {isUpload && (
          <Button variant="danger" icon={<Trash2 className="size-5" aria-hidden />} onClick={() => {
            dispatch({ type: "DELETE_DOCUMENT", id: doc.id });
            dispatch({ type: "LOG", entry: { type: "settings_changed", title: `Deleted "${doc.title}" from the vault`, purpose: "Manage my documents", actor: "self", level: "basic", channel: "app" } });
            toast.info("Document deleted"); navigate({ to: "/vault" });
          }}>Delete</Button>
        )}
      </main>
    </>
  );
}
