import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ScanFace, MapPin } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { useT } from "@/i18n";
import { ScreenHeader, Sheet } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { offices } from "@/data/offices";

export const Route = createFileRoute("/device-check")({
  head: () => ({
    meta: [
      { title: "New device – ida 2030" },
      { name: "description", content: "Confirm a new device once with a face scan in ida 2030." },
      { property: "og:title", content: "New device – ida 2030" },
      { property: "og:description", content: "Confirm a new device once with a face scan." },
    ],
  }),
  component: DeviceCheckScreen,
});

function DeviceCheckScreen() {
  const { setDemoOpen } = useApp();
  const t = useT();
  const navigate = useNavigate();
  const [sp, setSp] = useState(false);
  const point = offices.find((o) => o.id === "digital-austria")!;
  return (
    <>
      <ScreenHeader title={t("device.title")} onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex flex-1 flex-col p-5">
        <Card variant="security">
          <ScanFace className="size-12 text-security" aria-hidden />
          <p className="mt-3 text-xl font-bold">{t("device.text")}</p>
          <p className="mt-2">{t("device.why")}</p>
        </Card>
        <div className="mt-auto space-y-2">
          <Button icon={<ScanFace className="size-5" aria-hidden />} onClick={() => navigate({ to: "/facematch", search: { returnTo: "/onboarding", action: "first_login_new_device" } })}>{t("device.scan")}</Button>
          <Button variant="ghost" onClick={() => setSp(true)}>{t("device.servicePoint")}</Button>
        </div>
      </main>
      <Sheet open={sp} onOpenChange={setSp} title={t("device.servicePoint")}>
        <p>{t("device.spText")}</p>
        <Card variant="surface" className="mt-4">
          <p className="flex items-center gap-2 font-bold"><MapPin className="size-5 text-primary" aria-hidden />{point.name}</p>
          <p className="mt-1">{point.address}</p>
          <p className="text-sm text-muted-foreground">{point.openingHours}</p>
        </Card>
      </Sheet>
    </>
  );
}
