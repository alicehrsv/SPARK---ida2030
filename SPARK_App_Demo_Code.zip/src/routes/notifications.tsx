import { createFileRoute, useRouter } from "@tanstack/react-router";
import { CheckCheck } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { ScreenHeader, EmptyState } from "@/components/ida/extras";
import { Button } from "@/components/ida/core";
import { groupNotifications, kindIcon, formatTime } from "@/lib/notify";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/notifications")({
  head: () => ({
    meta: [
      { title: "Notifications – ida 2030" },
      { name: "description", content: "Deadlines, entitlements, status changes and security alerts in ida 2030." },
      { property: "og:title", content: "Notifications – ida 2030" },
      { property: "og:description", content: "Your notifications in ida 2030." },
    ],
  }),
  component: NotificationsScreen,
});

function NotificationsScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const router = useRouter();
  const groups = groupNotifications(state.notifications);
  const unread = state.notifications.some((n) => !n.read);
  return (
    <>
      <ScreenHeader title="Notifications" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 p-5">
        {unread && (
          <Button size="sm" variant="ghost" icon={<CheckCheck className="size-5" aria-hidden />} onClick={() => dispatch({ type: "READ_ALL_NOTIFICATIONS" })}>
            Mark all as read
          </Button>
        )}
        {groups.length === 0 && <EmptyState title="No notifications" text="We'll let you know when something needs your attention." />}
        {groups.map((g) => (
          <section key={g.key} aria-labelledby={`g-${g.key}`}>
            <h2 id={`g-${g.key}`} className="mb-2 mt-5 text-sm font-bold uppercase tracking-wide text-muted-foreground">{g.key}</h2>
            <ul className="space-y-2">
              {g.items.map((n) => {
                const Icon = kindIcon[n.kind];
                return (
                  <li key={n.id}>
                    <button type="button" onClick={() => { dispatch({ type: "READ_NOTIFICATION", id: n.id }); if (n.link) router.history.push(n.link); }}
                      className={cn("flex w-full items-start gap-3 rounded-2xl border p-4 text-start", n.read ? "border-border" : "border-primary/40 bg-surface")}>
                      <span className={cn("flex size-11 shrink-0 items-center justify-center rounded-xl", n.kind === "security" ? "bg-security-bg text-security" : "bg-background text-primary")} aria-hidden>
                        <Icon className="size-5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2 font-bold">{n.title}{!n.read && <span className="size-2 rounded-full bg-ida-red" aria-label="unread" />}</span>
                        <span className="block text-muted-foreground">{n.body}</span>
                        <span className="block text-sm text-muted-foreground">{formatTime(n.date)}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        ))}
      </main>
    </>
  );
}
