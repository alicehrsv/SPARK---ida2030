import { createFileRoute, useNavigate } from "@tanstack/react-router";
import * as React from "react";
import { Check, Circle, FileText, Upload, Scale } from "lucide-react";
import { useApp, newId } from "@/context/AppContext";
import { useConsent } from "@/components/ida/ConsentSheet";
import { useCriticalAction } from "@/hooks/useCriticalAction";
import { ScreenHeader, Sheet, EmptyState, AiBadge, toast } from "@/components/ida/extras";
import { Button, Card, StatusBadge, type BadgeStatus } from "@/components/ida/core";
import { DEMO_TODAY } from "@/data/config";
import { registersByUser } from "@/data/registers";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/applications/$id")({
  head: () => ({
    meta: [
      { title: "Application status – ida 2030" },
      { name: "description", content: "Application status in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Application status – ida 2030" },
      { property: "og:description", content: "Application status in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: ApplicationStatusScreen,
});

function fmt(iso?: string) {
  if (!iso) return undefined;
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
}

const STATUS_BADGE: Partial<Record<string, BadgeStatus>> = {
  submitted: "in_review", received: "in_review", in_review: "in_review", request: "in_review",
  approved: "approved", rejected: "rejected", withdrawn: "rejected",
};

function ApplicationStatusScreen() {
  const { id } = Route.useParams();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const requestConsent = useConsent();
  const app = state.applications.find((a) => a.id === id);

  const critical = useCriticalAction(`withdraw:${id}`);
  const [appealOpen, setAppealOpen] = React.useState(false);
  const [withdrawConfirmOpen, setWithdrawConfirmOpen] = React.useState(false);
  const [sendingAnswer, setSendingAnswer] = React.useState(false);
  const [uploaded, setUploaded] = React.useState(false);
  const fileRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (critical.approved && app) {
      dispatch({ type: "UPSERT_APPLICATION", item: { ...app, status: "withdrawn" } });
      dispatch({
        type: "LOG",
        entry: { type: "withdrawal", title: `Withdrew application: ${app.title}`, purpose: "Withdraw application within 24h", ...(app.authority ? { authority: app.authority } : {}), actor: "self", level: "critical", channel: "app" },
      });
      critical.consume();
      toast.success("Application withdrawn");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [critical.approved]);

  if (!app) {
    return (
      <>
        <ScreenHeader title="Application" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex-1 p-5">
          <EmptyState icon={<FileText className="size-7" aria-hidden />} title="We couldn't find this application" text="It may have been removed, or the link is out of date." />
        </main>
      </>
    );
  }

  const within24h = app.submittedAt
    ? DEMO_TODAY.getTime() - new Date(app.submittedAt).getTime() <= 24 * 60 * 60 * 1000
    : false;
  const canWithdraw = app.status !== "withdrawn" && app.status !== "rejected" && within24h;

  const steps: { key: string; label: string; date?: string | undefined; text: string; done: boolean; active: boolean }[] = [
    { key: "submitted", label: "Submitted", date: fmt(app.submittedAt), text: "Your application was sent securely to the authority.", done: !!app.submittedAt, active: app.status === "submitted" },
    { key: "received", label: "Received", date: fmt(app.receivedAt), text: "The authority has registered your application.", done: !!app.receivedAt, active: app.status === "received" },
    { key: "in_review", label: "In review", date: fmt(app.reviewAt), text: "A caseworker is checking your application.", done: !!app.reviewAt, active: app.status === "in_review" || app.status === "request" },
    ...(app.request
      ? [{ key: "request", label: "Request for documents", date: fmt(app.request.answeredAt), text: app.request.answeredAt ? "You answered the authority's request." : "The authority needs an extra document from you.", done: !!app.request.answeredAt, active: app.status === "request" }]
      : []),
    { key: "decision", label: "Decision", date: fmt(app.decidedAt), text: app.status === "approved" ? "Your application was approved." : app.status === "rejected" ? "Your application was rejected." : app.status === "withdrawn" ? "You withdrew this application." : "You'll be notified as soon as a decision is made.", done: !!app.decidedAt || app.status === "withdrawn", active: app.status === "approved" || app.status === "rejected" || app.status === "withdrawn" },
  ];

  const needsAnswer = app.request && !app.request.answeredAt;

  const sendAnswer = (via: "register" | "upload") => {
    setSendingAnswer(true);
    setTimeout(() => {
      const answeredAt = DEMO_TODAY.toISOString();
      dispatch({
        type: "UPSERT_APPLICATION",
        item: { ...app, status: "in_review", request: { ...app.request!, answeredAt, via } },
      });
      dispatch({
        type: "LOG",
        entry: { type: "submission", title: `Sent requested document: ${app.request!.document}`, purpose: app.request!.text, ...(app.authority ? { authority: app.authority } : {}), actor: "self", level: "basic", channel: "app" },
      });
      setSendingAnswer(false);
      toast.success("Sent to the authority");
    }, 700);
  };

  const fetchFromRegister = async () => {
    if (!app.request?.fetchRegister) return;
    const ids = await requestConsent({ registers: [app.request.fetchRegister], purpose: app.request.text });
    if (!ids) return;
    sendAnswer("register");
  };

  const handleUploadChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    if (e.target.files?.length) { setUploaded(true); sendAnswer("upload"); }
  };

  const registerLabel = app.request?.fetchRegister
    ? registersByUser[state.currentUserId]?.find((r) => r.id === app.request!.fetchRegister)?.name.en
    : undefined;

  return (
    <>
      <ScreenHeader title={app.title} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{app.reference ? `Reference ${app.reference}` : "No reference yet"}{app.authority ? ` · ${app.authority}` : ""}</p>
          {STATUS_BADGE[app.status] && <StatusBadge status={STATUS_BADGE[app.status]!} />}
        </div>

        <Card>
          <ol className="space-y-5">
            {steps.map((s, i) => (
              <li key={s.key} className="relative flex gap-3">
                <span className="flex flex-col items-center">
                  <span className={cn("flex size-7 shrink-0 items-center justify-center rounded-full", s.done ? "bg-success text-primary-foreground" : s.active ? "bg-ida-gradient text-primary-foreground" : "bg-surface text-muted-foreground")}>
                    {s.done ? <Check className="size-4" aria-hidden /> : <Circle className="size-3" aria-hidden />}
                  </span>
                  {i < steps.length - 1 && <span className={cn("mt-1 w-0.5 flex-1", s.done ? "bg-success" : "bg-border")} aria-hidden />}
                </span>
                <span className={cn("flex-1 pb-1", !s.done && !s.active && "opacity-50")}>
                  <span className="block font-bold">{s.label}</span>
                  {s.date && <span className="block text-sm text-muted-foreground">{s.date}</span>}
                  <span className="block text-sm text-muted-foreground">{s.text}</span>
                </span>
              </li>
            ))}
          </ol>
        </Card>

        {needsAnswer && (
          <Card variant="highlighted" className="space-y-3">
            <p className="font-bold">The authority needs a document from you</p>
            <p className="text-foreground">{app.request!.text}</p>
            <p className="text-sm text-muted-foreground">Needed: {app.request!.document} · due {fmt(app.request!.due)}</p>
            <AiBadge source="Letter from the authority, summarised by ida" />
            <div className="space-y-2 pt-1">
              {app.request!.fetchRegister && (
                <Button loading={sendingAnswer} onClick={fetchFromRegister}>
                  Fetch from {registerLabel ?? "the register"}
                </Button>
              )}
              <Button variant="secondary" loading={sendingAnswer} onClick={() => fileRef.current?.click()}>
                <Upload className="size-5" aria-hidden /> Upload document
              </Button>
              <input ref={fileRef} type="file" className="sr-only" onChange={handleUploadChange} aria-label="Upload document" />
            </div>
            {uploaded && <p className="text-sm text-success">File received (simulated).</p>}
          </Card>
        )}

        {(app.status === "approved" || app.status === "rejected") && app.decisionText && (
          <Card variant="surface" className="space-y-3">
            <p className="flex items-center gap-2 font-bold"><FileText className="size-5 text-primary" aria-hidden /> Official decision</p>
            <p className="rounded-xl border border-border bg-background p-4 font-serif leading-relaxed">{app.decisionText}</p>
            <AiBadge source={`${app.authority ?? "the authority"} decision letter, summarised by ida`} />
            {app.status === "rejected" && (
              <button type="button" onClick={() => setAppealOpen(true)} className="min-h-11 font-bold text-primary underline">
                Appeal options
              </button>
            )}
          </Card>
        )}

        <Card variant={canWithdraw ? "security" : "default"} className="space-y-2">
          <p className="font-bold">Withdraw this application</p>
          {canWithdraw ? (
            <p className="text-foreground">You can withdraw within 24 hours of submitting. After that, contact the authority directly.</p>
          ) : (
            <p className="text-muted-foreground">
              {app.status === "withdrawn" ? "This application was withdrawn." : app.status === "rejected" ? "This application was already decided and can't be withdrawn." : "You can only withdraw within 24 hours of submitting – that window has passed."}
            </p>
          )}
          <Button variant="danger" disabled={!canWithdraw} onClick={() => (app.status === "approved" ? setWithdrawConfirmOpen(true) : critical.request())}>
            Withdraw application
          </Button>
        </Card>

        <div className="grid grid-cols-2 gap-3">
          <Button variant="secondary" onClick={() => navigate({ to: "/chat" })}>Ask ida</Button>
          <Button variant="ghost" onClick={() => navigate({ to: "/help" })}>Talk to a person</Button>
        </div>
      </main>

      <Sheet open={appealOpen} onOpenChange={setAppealOpen} title="Appeal options">
        <p className="text-muted-foreground">
          If you disagree with this decision, you can usually lodge a formal appeal ("Beschwerde") with the authority within the deadline stated in the decision letter. This is general information, not legal advice.
        </p>
        <Card variant="surface" className="mt-4 flex items-start gap-3">
          <Scale className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden />
          <p className="text-sm text-muted-foreground">A caseworker or legal aid service can explain the appeal process and deadlines in detail.</p>
        </Card>
        <div className="mt-4 space-y-2">
          <Button onClick={() => { setAppealOpen(false); navigate({ to: "/help" }); }}>Talk to a person</Button>
          <Button variant="ghost" onClick={() => setAppealOpen(false)}>Close</Button>
        </div>
      </Sheet>

      <Sheet open={withdrawConfirmOpen} onOpenChange={setWithdrawConfirmOpen} title="Withdraw an approved application?">
        <p className="text-muted-foreground">This application was already approved. Withdrawing it cancels the approval. This still needs a face match to confirm it's you.</p>
        <div className="mt-4 space-y-2">
          <Button variant="danger" onClick={() => { setWithdrawConfirmOpen(false); critical.request(); }}>Continue to confirm it's you</Button>
          <Button variant="ghost" onClick={() => setWithdrawConfirmOpen(false)}>Cancel</Button>
        </div>
      </Sheet>
    </>
  );
}
