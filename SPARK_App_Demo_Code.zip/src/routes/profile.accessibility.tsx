import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/context/AppContext";
import { ScreenHeader, Toggle } from "@/components/ida/extras";
import { Card, SectionTitle } from "@/components/ida/core";

export const Route = createFileRoute("/profile/accessibility")({
  head: () => ({
    meta: [
      { title: "Accessibility – ida 2030" },
      { name: "description", content: "Accessibility in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Accessibility – ida 2030" },
      { property: "og:description", content: "Accessibility in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: AccessibilityScreen,
});

function AccessibilityScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const a = state.accessibility;
  const scale = a.textScale ?? (a.largeText ? 1.25 : 1);

  const patch = (p: Partial<typeof a>) => dispatch({ type: "SET_ACCESSIBILITY", patch: p });

  return (
    <>
      <ScreenHeader title="Accessibility" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <p className="text-muted-foreground">These settings apply across the whole app, right away.</p>

        <SectionTitle>Text size</SectionTitle>
        <Card variant="surface">
          <input type="range" min={100} max={200} step={5} value={Math.round(scale * 100)}
            aria-label="Text size" className="w-full accent-primary"
            onChange={(e) => patch({ textScale: Number(e.target.value) / 100 })} />
          <p className="mt-1 text-sm text-muted-foreground">{Math.round(scale * 100)}%</p>
          <p className="mt-3 rounded-xl bg-background p-3" style={{ fontSize: `${scale}rem` }}>This is how text will look.</p>
        </Card>

        <Card variant="surface">
          <Toggle checked={!!a.highContrast} onChange={(v) => patch({ highContrast: v })} label="High contrast" description="Stronger colours and borders" />
          <Toggle checked={!!a.boldText} onChange={(v) => patch({ boldText: v })} label="Bold text" description="Makes all text heavier" />
          <Toggle checked={!!a.reducedMotion} onChange={(v) => patch({ reducedMotion: v })} label="Reduce motion" description="Turns off animations and transitions" />
          <Toggle checked={a.readAloud} onChange={(v) => patch({ readAloud: v })} label="Read aloud" description="Adds a button to read the screen out loud" />
          <Toggle checked={a.easyLanguage} onChange={(v) => patch({ easyLanguage: v })} label="Easy Language" description="Short sentences, one idea at a time" />
          <Toggle checked={!!a.signLanguage} onChange={(v) => patch({ signLanguage: v })} label="Sign language videos" description="Shows Austrian Sign Language (ÖGS) videos where available" />
        </Card>
      </main>
    </>
  );
}
