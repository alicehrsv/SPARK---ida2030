import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CheckCircle2, Clock } from "lucide-react";
import { useApp, newId } from "@/context/AppContext";
import { offices } from "@/data/offices";
import { DEMO_TODAY } from "@/data/config";
import { ScreenHeader } from "@/components/ida/extras";
import { Button, Card, Chip } from "@/components/ida/core";
import { cn } from "@/lib/utils";

type Search = { reason?: string; applicationId?: string; reschedule?: string };

export const Route = createFileRoute("/appointments/book/$officeId")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["reason"] === "string" ? { reason: s["reason"] } : {}),
    ...(typeof s["applicationId"] === "string" ? { applicationId: s["applicationId"] } : {}),
    ...(typeof s["reschedule"] === "string" ? { reschedule: s["reschedule"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Book appointment – ida 2030" },
      { name: "description", content: "Book an appointment at an Austrian office in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Book appointment – ida 2030" },
      { property: "og:description", content: "Book appointment in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: BookAppointmentScreen,
});

const reasonOptions = ["Passport renewal", "ID card", "Residence permit", "Registration confirmation", "Driving licence", "Other"];
const checklistByReason: Record<string, string[]> = {
  "Passport renewal": ["Old passport", "Passport photo (35×45 mm, not older than 6 months)", "Fee approx. € 112"],
  "ID card": ["Old ID card", "Passport photo", "Fee approx. € 61"],
  "Residence permit": ["Passport", "Proof of income", "Proof of health insurance", "Fee approx. € 160"],
  "Registration confirmation": ["Passport or ID card"],
  "Driving licence": ["Old driving licence", "Passport photo", "Medical certificate (if required)"],
  Other: ["Passport or ID card"],
};

function dayLabel(d: Date) {
  return d.toLocaleDateString("en-GB", { weekday: "short", timeZone: "Europe/Vienna" });
}

function BookAppointmentScreen() {
  const { officeId } = Route.useParams();
  const { reason: reasonParam, applicationId, reschedule } = Route.useSearch();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const office = offices.find((o) => o.id === officeId);

  const days = useMemo(() => {
    const out: Date[] = [];
    for (let i = 1; i <= 14; i++) {
      const d = new Date(DEMO_TODAY);
      d.setDate(d.getDate() + i);
      out.push(d);
    }
    return out;
  }, []);

  const [selectedDay, setSelectedDay] = useState<Date | null>(days.find((d) => d.getDay() !== 0 && d.getDay() !== 6) ?? null);
  const [slot, setSlot] = useState<string | null>(null);
  const [reason, setReason] = useState(reasonOptions.includes(reasonParam ?? "") ? reasonParam! : reasonParam ? "Other" : "Passport renewal");
  const [customReason, setCustomReason] = useState(reasonParam && !reasonOptions.includes(reasonParam) ? reasonParam : "");
  const [done, setDone] = useState(false);

  if (!office) return (<><ScreenHeader title="Book appointment" back /><main className="p-5">Office not found.</main></>);

  const slotsForDay = selectedDay
    ? office.slots.filter((s) => {
        const d = new Date(s);
        return d.getFullYear() === selectedDay.getFullYear() && d.getMonth() === selectedDay.getMonth() && d.getDate() === selectedDay.getDate();
      })
    : [];

  const finalReason = reason === "Other" && customReason ? customReason : reason;

  const confirm = () => {
    if (!slot) return;
    if (reschedule) dispatch({ type: "CANCEL_APPOINTMENT", id: reschedule });
    const id = newId();
    const checklist = checklistByReason[reason] ?? checklistByReason["Other"]!;
    dispatch({ type: "ADD_APPOINTMENT", item: { id, officeId: office.id, slot, purpose: finalReason, checklist, ...(applicationId ? { applicationId } : {}) } });
    dispatch({ type: "LOG", entry: { type: "appointment_booked", title: `Booked an appointment at ${office.name}`, purpose: finalReason, authority: office.name, actor: "self", level: "basic", channel: "app" } });
    const dueDate = new Date(slot);
    dueDate.setDate(dueDate.getDate() - 1);
    dueDate.setHours(9, 0, 0, 0);
    dispatch({ type: "UPSERT_REMINDER", item: { id: `r-appt-${id}`, title: `Appointment tomorrow: ${finalReason}`, due: dueDate.toISOString(), done: false, link: "/appointments", kind: "appointment", source: "Your appointment", enabled: true } });
    setDone(true);
  };

  if (done) {
    const { date, time } = { date: new Date(slot!).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", timeZone: "Europe/Vienna" }), time: new Date(slot!).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" }) };
    return (
      <>
        <ScreenHeader title="Booked" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex flex-1 flex-col items-center justify-center gap-4 p-5 text-center">
          <CheckCircle2 className="size-16 text-success" aria-hidden />
          <h2 className="text-2xl font-bold">Appointment confirmed</h2>
          <p className="text-muted-foreground">{office.name}<br />{date} · {time}</p>
          <Link to="/appointments" className="mt-2"><Button>Go to appointments</Button></Link>
        </main>
      </>
    );
  }

  return (
    <>
      <ScreenHeader title={reschedule ? "Reschedule appointment" : "Book appointment"} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-5 p-5">
        <Card>
          <p className="font-bold">{office.name}</p>
          <p className="text-sm text-muted-foreground">{office.address}</p>
          <p className="mt-1 text-sm text-muted-foreground">{office.openingHours}</p>
        </Card>

        <div>
          <h2 className="mb-2 text-lg font-bold">Reason</h2>
          <div className="flex flex-wrap gap-2">
            {reasonOptions.map((r) => <Chip key={r} selected={reason === r} onClick={() => setReason(r)}>{r}</Chip>)}
          </div>
          {reason === "Other" && (
            <input value={customReason} onChange={(e) => setCustomReason(e.target.value)} placeholder="Describe your reason"
              className="mt-2 min-h-[52px] w-full rounded-2xl border border-border px-4 text-base" aria-label="Reason" />
          )}
        </div>

        <div>
          <h2 className="mb-2 text-lg font-bold">Choose a day</h2>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {days.map((d) => {
              const weekend = d.getDay() === 0 || d.getDay() === 6;
              const selected = selectedDay?.toDateString() === d.toDateString();
              return (
                <button key={d.toISOString()} type="button" disabled={weekend} onClick={() => { setSelectedDay(d); setSlot(null); }}
                  className={cn("flex min-h-16 w-14 shrink-0 flex-col items-center justify-center rounded-2xl border text-sm font-bold",
                    weekend ? "cursor-not-allowed border-border bg-surface text-muted-foreground opacity-50" : selected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background hover:bg-surface")}>
                  <span>{dayLabel(d)}</span>
                  <span className="text-lg">{d.getDate()}</span>
                </button>
              );
            })}
          </div>
        </div>

        {selectedDay && (
          <div>
            <h2 className="mb-2 flex items-center gap-1.5 text-lg font-bold"><Clock className="size-5" aria-hidden />Time slots</h2>
            {slotsForDay.length === 0 ? <p className="text-muted-foreground">No free slots this day – choose another day.</p> : (
              <div className="grid grid-cols-3 gap-2">
                {slotsForDay.map((s) => (
                  <Chip key={s} selected={slot === s} onClick={() => setSlot(s)}>
                    {new Date(s).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" })}
                  </Chip>
                ))}
              </div>
            )}
          </div>
        )}

        <Button disabled={!slot || (reason === "Other" && !customReason)} onClick={confirm}>Confirm appointment</Button>
      </main>
    </>
  );
}
