import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Clock, Save, CheckCircle2 } from "lucide-react";
import { useApp, newId } from "@/context/AppContext";
import { ScreenHeader, toast, AiBadge } from "@/components/ida/extras";
import { Button, Card, SectionTitle } from "@/components/ida/core";
import { getCall, clearCall, fmtDuration, type CallSession } from "@/lib/callSession";
import { DEMO_TODAY } from "@/data/config";

export const Route = createFileRoute("/call/summary")({
  head: () => ({
    meta: [
      { title: "Call summary – ida 2030" },
      { name: "description", content: "Summary of your call with the ida phone agent: topics, actions and next steps." },
      { property: "og:title", content: "Call summary – ida 2030" },
      { property: "og:description", content: "Summary of your call with ida." },
    ],
  }),
  component: CallSummaryScreen,
});

function CallSummaryScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const [s, setS] = useState<CallSession | null>(null);
  const [saved, setSaved] = useState(false);
  const logged = useRef(false);

  useEffect(() => {
    const c = getCall();
    setS(c);
    if (c && !logged.current) {
      logged.current = true;
      dispatch({ type: "LOG", entry: { type: "call", title: `Phone call with ida (${fmtDuration((c.endedAt ?? Date.now()) - c.startedAt)})`, purpose: c.topics.join(", ") || "General questions", actor: "self", level: c.publicMode ? "public" : "basic", channel: "phone agent" } });
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (!s) {
    return (<>
      <ScreenHeader title="Call summary" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="p-5"><p className="text-muted-foreground">No recent call.</p><Link to="/call" className="mt-3 inline-block font-bold text-primary underline">Call ida</Link></main>
    </>);
  }

  const duration = fmtDuration((s.endedAt ?? Date.now()) - s.startedAt);
  const youSaid = s.lines.filter((l) => l.who === "you").map((l) => l.text);
  const bullets = s.topics.length ? s.topics.map((t) => `You asked about: ${t}`) : youSaid.length ? youSaid.slice(0, 3).map((t) => `You said: “${t}”`) : ["ida introduced itself. No question was asked."];

  const save = () => {
    dispatch({ type: "ADD_DOCUMENT", item: { id: newId(), title: `Call summary ${DEMO_TODAY.toLocaleDateString("de-AT")}`, kind: "call", status: "uploaded", addedAt: DEMO_TODAY.toISOString(), category: "other", origin: "ida phone agent", note: [...bullets, ...s.actions.map((a) => a.label), ...s.nextSteps].join("\n") } });
    dispatch({ type: "LOG", entry: { type: "document_upload", title: "Saved call summary to vault", purpose: "Keep a record of the call", actor: "self", level: "basic", channel: "phone agent" } });
    setSaved(true); toast.success("Saved to your documents");
  };

  return (
    <>
      <ScreenHeader title="Call summary" back onBack={() => { clearCall(); navigate({ to: state.isLoggedIn ? "/home" : "/welcome" }); }} onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 p-5">
        <Card variant="highlighted" className="flex items-center gap-3">
          <Clock className="size-7 text-primary" aria-hidden />
          <div><p className="text-sm text-muted-foreground">Duration</p><p className="text-2xl font-bold">{duration}</p></div>
          {s.transferred && <span className="ms-auto rounded-full bg-surface px-3 py-1 text-sm font-bold">Transferred</span>}
        </Card>

        <SectionTitle>What we discussed</SectionTitle>
        <ul className="list-disc space-y-1 ps-5">{bullets.map((b, i) => <li key={i}>{b}</li>)}</ul>
        <div className="mt-2"><AiBadge source="ida phone agent – call transcript" /></div>

        <SectionTitle>Actions taken</SectionTitle>
        {s.actions.length ? (
          <ul className="space-y-2">{s.actions.map((a, i) => (
            <li key={i} className="flex items-center gap-2 rounded-2xl bg-surface p-3">
              <CheckCircle2 className="size-5 text-success" aria-hidden />
              {a.link ? <a href={a.link} className="font-semibold text-primary underline">{a.label}</a> : <span className="font-semibold">{a.label}</span>}
            </li>))}
          </ul>
        ) : <p className="text-muted-foreground">No actions were taken.</p>}

        <SectionTitle>Next steps</SectionTitle>
        {s.nextSteps.length ? <ul className="list-disc space-y-1 ps-5">{[...new Set(s.nextSteps)].map((n) => <li key={n}>{n}</li>)}</ul> : <p className="text-muted-foreground">Nothing to do right now.</p>}

        {state.isLoggedIn ? (
          <Button className="mt-6" disabled={saved} icon={<Save className="size-5" aria-hidden />} onClick={save}>{saved ? "Saved" : "Save to my documents"}</Button>
        ) : (
          <p className="mt-6 rounded-2xl bg-surface p-4 text-sm">Log in to save this summary to your documents.</p>
        )}
      </main>
    </>
  );
}
