import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ShieldAlert, UserRoundCog, Plus } from "lucide-react";
import { useApp, currentUser, type PowerOfAttorney } from "@/context/AppContext";
import { ScreenHeader, toast } from "@/components/ida/extras";
import { Button, Card, Chip, StatusBadge, SectionTitle } from "@/components/ida/core";
import { useCriticalAction } from "@/hooks/useCriticalAction";
import { POA_AREAS } from "@/lib/acting";

export const Route = createFileRoute("/power-of-attorney/")({
  head: () => ({
    meta: [
      { title: "Power of attorney – ida 2030" },
      { name: "description", content: "Manage who can act for you, and who you can act for, in ida 2030." },
      { property: "og:title", content: "Power of attorney – ida 2030" },
      { property: "og:description", content: "Power of attorney in ida 2030." },
    ],
  }),
  component: PowerOfAttorneyScreen,
});

const rightLabel: Record<string, string> = { view: "View only", prepare: "Prepare", submit: "Submit" };

function PoaCard({ poa, onActFor }: { poa: PowerOfAttorney; onActFor?: (() => void) | undefined }) {
  const navigate = useNavigate();
  const { dispatch } = useApp();
  const revoke = useCriticalAction(`revoke_poa:${poa.id}`);

  React.useEffect(() => {
    if (revoke.approved) {
      dispatch({ type: "REVOKE_POWER_OF_ATTORNEY", id: poa.id });
      dispatch({ type: "LOG", entry: { type: "power_of_attorney", title: `Revoked power of attorney for ${poa.name}`, purpose: "Revoke power of attorney", actor: "self", level: "critical", channel: "app" } });
      toast.success(`Power of attorney for ${poa.name} revoked`);
      revoke.consume();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [revoke.approved]);

  const badge = poa.status === "active" ? "approved" : poa.status === "pending" ? "in_review" : "rejected";
  return (
    <Card>
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-lg font-bold">{poa.name}</p>
          <p className="text-sm text-muted-foreground">{poa.relationship}</p>
        </div>
        <StatusBadge status={badge as "approved" | "in_review" | "rejected"}>{poa.status === "active" ? "Active" : poa.status === "pending" ? "Pending" : "Revoked"}</StatusBadge>
      </div>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {poa.areas.map((a) => (
          <span key={a.area} className="rounded-full bg-surface px-2.5 py-1 text-xs font-bold">
            {POA_AREAS.find((p) => p.id === a.area)?.label ?? a.area} · {rightLabel[a.right]}
          </span>
        ))}
      </div>
      <p className="mt-3 text-sm text-muted-foreground">Valid until {new Date(poa.validUntil).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</p>
      {poa.status !== "revoked" && (
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" onClick={() => navigate({ to: "/power-of-attorney/new", search: { edit: poa.id } })}>Change</Button>
          <Button variant="danger" size="sm" icon={<ShieldAlert className="size-4" aria-hidden />} onClick={() => revoke.request()}>Revoke</Button>
          {onActFor && <Button variant="ghost" size="sm" icon={<UserRoundCog className="size-4" aria-hidden />} onClick={onActFor}>Act for {poa.name.split(" ")[0]}</Button>}
        </div>
      )}
    </Card>
  );
}

function PowerOfAttorneyScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const u = currentUser(state);

  if (state.actingFor) {
    return (
      <>
        <ScreenHeader title="Power of attorney" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex-1 space-y-4 p-5">
          <Card variant="surface">
            <p className="font-bold">Not available while acting for someone</p>
            <p className="mt-1 text-sm text-muted-foreground">A representative cannot manage {state.actingFor.name}'s powers of attorney. Switch back to your own account first.</p>
          </Card>
        </main>
      </>
    );
  }

  const granted = state.powersOfAttorney.filter((p) => p.direction === "granted");
  const received = state.powersOfAttorney.filter((p) => p.direction === "received");

  const actFor = (poa: PowerOfAttorney) => {
    if (!poa.personUserId) return;
    dispatch({ type: "ACT_FOR", userId: poa.personUserId, name: poa.name, areas: poa.areas.map((a) => a.area) });
    dispatch({ type: "LOG", entry: { type: "power_of_attorney", title: `Started acting for ${poa.name}`, purpose: "Act on behalf of", actor: "self", level: "critical", channel: "app" } });
    toast.success(`Now acting for ${poa.name}`);
    navigate({ to: "/home" });
  };

  return (
    <>
      <ScreenHeader title="Power of attorney" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5 pb-10">
        <p className="text-muted-foreground">Hello {u.firstName}, here you can let others act for you in ida, or act for someone who trusts you.</p>

        <SectionTitle>People who can act for me</SectionTitle>
        {granted.length === 0 ? <p className="text-muted-foreground">No one else can act for you yet.</p> : (
          <div className="space-y-3">{granted.map((p) => <PoaCard key={p.id} poa={p} />)}</div>
        )}

        <SectionTitle>People I can act for</SectionTitle>
        {received.length === 0 ? <p className="text-muted-foreground">You cannot act for anyone yet.</p> : (
          <div className="space-y-3">{received.map((p) => <PoaCard key={p.id} poa={p} onActFor={p.status === "active" && p.personUserId ? () => actFor(p) : undefined} />)}</div>
        )}

        <Link to="/power-of-attorney/new" className="mt-2 flex min-h-[52px] items-center justify-center gap-2 rounded-2xl bg-ida-gradient px-5 font-bold text-primary-foreground shadow-lift">
          <Plus className="size-5" aria-hidden />New power of attorney
        </Link>
      </main>
    </>
  );
}
