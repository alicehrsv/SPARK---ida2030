import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { LogOut, ShieldUser, FolderLock, FileText, LayoutDashboard, UserRoundCog, UserRound, SlidersHorizontal, Accessibility, Smartphone, LifeBuoy, Info } from "lucide-react";
import { useApp, currentUser } from "@/context/AppContext";
import { useT } from "@/i18n";
import { ScreenHeader, PrototypeChip, ListItem, Sheet, toast } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { useState } from "react";

export const Route = createFileRoute("/profile/")({
  head: () => ({
    meta: [
      { title: "Profile – ida 2030" },
      { name: "description", content: "Your profile in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Profile – ida 2030" },
      { property: "og:description", content: "Your profile in ida 2030." },
    ],
  }),
  component: ProfileScreen,
});

function initials(first: string, last: string) {
  return `${first[0] ?? ""}${last[0] ?? ""}`.toUpperCase();
}

function ProfileScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const t = useT();
  const navigate = useNavigate();
  const u = currentUser(state);
  const [aboutOpen, setAboutOpen] = useState(false);

  const logout = () => {
    dispatch({ type: "LOG", entry: { type: "logout", title: "Logged out", purpose: "End session", actor: "self", level: "basic", channel: "app" } });
    dispatch({ type: "LOGOUT" });
    toast.info("Logged out");
    navigate({ to: "/welcome" });
  };

  const switchable = !state.actingFor
    ? state.powersOfAttorney.filter((p) => p.direction === "received" && p.status === "active" && p.personUserId)
    : [];

  const actFor = (p: (typeof switchable)[number]) => {
    if (!p.personUserId) return;
    dispatch({ type: "ACT_FOR", userId: p.personUserId, name: p.name, areas: p.areas.map((a) => a.area) });
    dispatch({ type: "LOG", entry: { type: "power_of_attorney", title: `Started acting for ${p.name}`, purpose: "Act on behalf of", actor: "self", level: "critical", channel: "app" } });
    toast.success(`Now acting for ${p.name}`);
    navigate({ to: "/home" });
  };

  return (
    <>
      <ScreenHeader title={t("nav.profile")} onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex flex-1 flex-col gap-4 p-5">
        <PrototypeChip />
        <Card>
          <div className="flex items-center gap-4">
            <span className="flex size-16 shrink-0 items-center justify-center rounded-full bg-ida-gradient text-xl font-bold text-primary-foreground" aria-hidden>
              {initials(u.firstName, u.lastName)}
            </span>
            <div className="min-w-0">
              <p className="truncate text-2xl font-bold">{u.firstName} {u.lastName}</p>
              <p className="truncate text-muted-foreground">{u.address}</p>
            </div>
          </div>
          <span className="mt-3 inline-flex items-center gap-1 rounded-full bg-success-bg px-3 py-1 text-sm font-bold text-success">
            <ShieldUser className="size-4" aria-hidden /> Verified with ID Austria
          </span>
        </Card>

        {switchable.length > 0 && (
          <Card variant="surface">
            <p className="font-bold">Act for someone else</p>
            <div className="mt-2 space-y-2">
              {switchable.map((p) => (
                <Button key={p.id} variant="secondary" icon={<UserRoundCog className="size-5" aria-hidden />} onClick={() => actFor(p)}>
                  Switch to {p.name}
                </Button>
              ))}
            </div>
          </Card>
        )}

        <div className="-mx-2">
          <ListItem icon={<UserRound className="size-5" />} title="Personal data" onClick={() => navigate({ to: "/profile/personal-data" })} />
          <ListItem icon={<FolderLock className="size-5" />} title="My documents" onClick={() => navigate({ to: "/vault" })} />
          <ListItem icon={<ShieldUser className="size-5" />} title="Power of attorney" onClick={() => navigate({ to: "/power-of-attorney" })} />
          <ListItem icon={<LayoutDashboard className="size-5" />} title="Data Cockpit" onClick={() => navigate({ to: "/cockpit" })} />
          <ListItem icon={<SlidersHorizontal className="size-5" />} title="Settings" onClick={() => navigate({ to: "/profile/settings" })} />
          <ListItem icon={<Accessibility className="size-5" />} title="Accessibility" onClick={() => navigate({ to: "/profile/accessibility" })} />
          <ListItem icon={<Smartphone className="size-5" />} title="Devices" onClick={() => navigate({ to: "/profile/devices" })} />
          <ListItem icon={<LifeBuoy className="size-5" />} title="Help" onClick={() => navigate({ to: "/help" })} />
          <ListItem icon={<Info className="size-5" />} title="About ida 2030" onClick={() => setAboutOpen(true)} />
        </div>

        <Button className="mt-auto" variant="secondary" icon={<LogOut className="size-5" aria-hidden />} onClick={logout}>{t("profile.logout")}</Button>
      </main>

      <Sheet open={aboutOpen} onOpenChange={setAboutOpen} title="About ida 2030">
        <p className="text-muted-foreground">ida 2030 is a hackathon prototype of a digital assistant for Austrian government services.</p>
        <p className="mt-3">Everything you see is simulated: there is no real ID Austria login, no real register data and no requests are sent to any authority. All names, documents and register entries are made up for this demo.</p>
        <p className="mt-3 text-sm text-muted-foreground">Built to show how clearer language, pre-filled forms and ida's hints could make official tasks easier – while every decision always stays with you and the responsible authority.</p>
        <PrototypeChip />
      </Sheet>
    </>
  );
}
