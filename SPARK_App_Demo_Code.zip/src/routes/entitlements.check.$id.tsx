import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import * as Icons from "lucide-react";
import { CheckCircle2, XCircle, Gift } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { runEntitlementRules } from "@/services/entitlements";
import { ScreenHeader, AiBadge } from "@/components/ida/extras";
import { Button, Card, ProgressBar } from "@/components/ida/core";

export const Route = createFileRoute("/entitlements/check/$id")({
  head: () => ({
    meta: [
      { title: "Check entitlement – ida 2030" },
      { name: "description", content: "Answer a few quick questions to see if you may be entitled, in ida 2030." },
      { property: "og:title", content: "Check entitlement – ida 2030" },
      { property: "og:description", content: "Entitlement check in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: EntitlementCheckScreen,
});

function EntitlementCheckScreen() {
  const { id } = Route.useParams();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const hint = runEntitlementRules(state.currentUserId, state).find((h) => h.id === id);

  const [step, setStep] = useState(0);
  const [failReason, setFailReason] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  if (!hint) return (<><ScreenHeader title="Check entitlement" back /><main className="p-5">This hint is no longer available.</main></>);

  const Icon = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[hint.icon] ?? Gift;
  const questions = hint.questions.slice(0, 3);
  const total = questions.length;

  const logCheck = (title: string) => {
    dispatch({ type: "LOG", entry: { type: "entitlement_check", title, purpose: "Check entitlement eligibility", actor: "self", level: "public", channel: "app" } });
  };

  const answer = (yes: boolean) => {
    const q = questions[step]!;
    if (yes !== q.expectYes) {
      setFailReason(q.failReason);
      setDone(true);
      dispatch({ type: "UPSERT_ENTITLEMENT", item: { id: hint.id, title: hint.title, status: "not_eligible", reason: q.failReason } });
      logCheck(`Checked: ${hint.title} – probably not eligible`);
      return;
    }
    if (step + 1 >= total) {
      setDone(true);
      dispatch({ type: "UPSERT_ENTITLEMENT", item: { id: hint.id, title: hint.title, status: "started", reason: hint.reasons[0]?.text ?? "" } });
      logCheck(`Checked: ${hint.title} – likely eligible`);
    } else {
      setStep(step + 1);
    }
  };

  const startApplication = () => {
    if (!hint.procedureId) return;
    dispatch({ type: "UPSERT_ENTITLEMENT", item: { id: hint.id, title: hint.title, status: "started", reason: hint.reasons[0]?.text ?? "" } });
    navigate({ to: "/applications/new/$procedureId", params: { procedureId: hint.procedureId }, search: { from: `entitlement:${hint.id}` } });
  };

  const eligible = done && !failReason;

  return (
    <>
      <ScreenHeader title={`Check: ${hint.title}`} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        {hint.automatic && (
          <Card variant="surface">
            <p className="text-sm text-muted-foreground">
              This benefit is usually paid automatically once the birth is registered – you don't normally need to apply. ida just wants to double-check a few things with you.
            </p>
          </Card>
        )}

        {!done && (
          <>
            <ProgressBar value={(step / total) * 100} label={`Question ${step + 1} of ${total}`} />
            <Card>
              <div className="mb-4 flex items-center gap-3">
                <span className="flex size-12 items-center justify-center rounded-2xl bg-surface text-primary" aria-hidden><Icon className="size-6" /></span>
                <h2 className="text-lg font-bold">{questions[step]!.q}</h2>
              </div>
              <div className="flex gap-3">
                <Button variant="secondary" onClick={() => answer(false)}>No</Button>
                <Button onClick={() => answer(true)}>Yes</Button>
              </div>
            </Card>
          </>
        )}

        {done && (
          <Card variant={eligible ? "highlighted" : "default"}>
            <div className="flex items-start gap-3">
              {eligible ? <CheckCircle2 className="mt-0.5 size-7 shrink-0 text-success" aria-hidden /> : <XCircle className="mt-0.5 size-7 shrink-0 text-muted-foreground" aria-hidden />}
              <div>
                <h2 className="text-lg font-bold">{eligible ? "Likely eligible" : "Probably not eligible"}</h2>
                {eligible ? (
                  <p className="mt-1 text-muted-foreground">Based on your answers, you may be entitled to {hint.title.toLowerCase()}. {hint.estimate} – this is an estimate only; the authority always makes the final decision.</p>
                ) : (
                  <p className="mt-1 text-muted-foreground">{failReason}</p>
                )}
              </div>
            </div>

            <AiBadge source="ida's entitlement rules engine based on your answers" className="mt-4" />

            <div className="mt-4 space-y-2">
              {eligible && hint.automatic && (
                <p className="text-sm text-muted-foreground">No action needed right now – this is usually paid automatically. You can still prepare the application if you'd like a record of it.</p>
              )}
              {eligible && hint.procedureId && <Button onClick={startApplication}>Start application</Button>}
              <Button variant="ghost" onClick={() => navigate({ to: "/entitlements/$id", params: { id: hint.id } })}>Back to overview</Button>
            </div>
          </Card>
        )}
      </main>
    </>
  );
}
