import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Camera, Upload, Zap, ZapOff, CameraOff, FileText } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { letters } from "@/data/letters";
import { ScreenHeader, Sheet } from "@/components/ida/extras";
import { Button, SkeletonCard } from "@/components/ida/core";
import { fakeLatency } from "@/services/delay";

export const Route = createFileRoute("/scan")({
  head: () => ({
    meta: [
      { title: "Scan a letter – ida 2030" },
      { name: "description", content: "Scan an official letter and let ida explain it in plain language." },
      { property: "og:title", content: "Scan a letter – ida 2030" },
      { property: "og:description", content: "Scan a letter – ida explains it." },
    ],
  }),
  component: ScanScreen,
});

function ScanScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [cam, setCam] = useState<"pending" | "on" | "denied">("pending");
  const [flash, setFlash] = useState(false);
  const [reading, setReading] = useState(false);
  const [pick, setPick] = useState(false);
  const mine = letters.filter((l) => l.userId === state.currentUserId);

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (!navigator.mediaDevices?.getUserMedia) { setCam("denied"); return; }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false })
      .then((s) => { stream = s; if (videoRef.current) videoRef.current.srcObject = s; setCam("on"); })
      .catch(() => setCam("denied"));
    return () => stream?.getTracks().forEach((t) => t.stop());
  }, []);

  const open = (id: string) => {
    const l = letters.find((x) => x.id === id)!;
    dispatch({ type: "LOG", entry: { type: "letter_scanned", title: `Scanned a letter from ${l.sender}`, purpose: "Understand an official letter", authority: l.sender, actor: "self", level: "basic", channel: "app" } });
    navigate({ to: "/letter/$id", params: { id } });
  };

  const capture = async () => {
    setReading(true);
    await new Promise((r) => setTimeout(r, 1500));
    await fakeLatency(0, 1);
    setReading(false);
    // Mock OCR: picks the current user's letter; demo mode offers a choice when several letters exist.
    if (mine.length === 1) open(mine[0]!.id);
    else setPick(true);
  };

  if (reading) {
    return (<>
      <ScreenHeader title="Scan a letter" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5" role="status" aria-live="polite">
        <p className="text-xl font-bold">Reading your letter…</p>
        <SkeletonCard /><SkeletonCard />
      </main>
    </>);
  }

  return (
    <>
      <ScreenHeader title="Scan a letter" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex flex-1 flex-col p-5">
        <input ref={fileRef} type="file" accept="image/*,application/pdf" className="sr-only" aria-label="Upload letter" onChange={(e) => e.target.files?.length && capture()} />
        {cam === "denied" ? (
          <div className="flex flex-1 flex-col items-center justify-center rounded-3xl bg-surface p-6 text-center">
            <CameraOff className="size-12 text-primary" aria-hidden />
            <p className="mt-4 text-xl font-bold">No camera access</p>
            <p className="mt-2 text-muted-foreground">That's okay. You can upload a photo or PDF of the letter instead.</p>
            <Button className="mt-6" icon={<Upload className="size-5" aria-hidden />} onClick={() => fileRef.current?.click()}>Upload from files or photos</Button>
            <Button className="mt-2" variant="ghost" onClick={capture}>Use demo letter</Button>
          </div>
        ) : (
          <>
            <div className="relative flex-1 overflow-hidden rounded-3xl bg-foreground">
              <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 size-full object-cover" aria-label="Camera preview" />
              {flash && <div className="absolute inset-0 bg-background/20" aria-hidden />}
              <div className="absolute inset-6 rounded-2xl border-4 border-dashed border-primary-foreground/90" aria-hidden />
              <p className="absolute inset-x-0 bottom-8 text-center font-bold text-primary-foreground">Hold the letter inside the frame</p>
              <button type="button" onClick={() => setFlash(!flash)} aria-pressed={flash} aria-label={flash ? "Flash on" : "Flash off"}
                className="absolute end-3 top-3 flex size-11 items-center justify-center rounded-full bg-foreground/60 text-primary-foreground">
                {flash ? <Zap className="size-5" aria-hidden /> : <ZapOff className="size-5" aria-hidden />}
              </button>
            </div>
            <div className="mt-5 flex items-center justify-around">
              <button type="button" onClick={() => fileRef.current?.click()} className="flex flex-col items-center gap-1 text-sm font-semibold">
                <span className="flex size-14 items-center justify-center rounded-full bg-surface text-primary"><Upload className="size-6" aria-hidden /></span>Upload
              </button>
              <button type="button" onClick={capture} aria-label="Capture" className="flex size-20 items-center justify-center rounded-full bg-ida-gradient p-1 shadow-lift">
                <span className="flex size-full items-center justify-center rounded-full border-4 border-background"><Camera className="size-8 text-primary-foreground" aria-hidden /></span>
              </button>
              <span className="w-14" />
            </div>
          </>
        )}
      </main>
      <Sheet open={pick} onOpenChange={setPick} title="Demo: which letter?" description="The simulated text recognition found several letters for this resident.">
        <div className="space-y-2">
          {(mine.length ? mine : letters).map((l) => (
            <button key={l.id} type="button" onClick={() => { setPick(false); open(l.id); }} className="flex w-full items-center gap-3 rounded-2xl bg-surface p-4 text-start">
              <FileText className="size-6 text-primary" aria-hidden />
              <span><span className="block font-bold">{l.subject}</span><span className="block text-sm text-muted-foreground">{l.sender}</span></span>
            </button>
          ))}
        </div>
      </Sheet>
    </>
  );
}
