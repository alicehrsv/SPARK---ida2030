import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, DatabaseZap, Plus, ShieldCheck, FileUp } from "lucide-react";
import { useApp, type DocCategory } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { ScreenHeader, EmptyState, toast } from "@/components/ida/extras";
import { Button, Chip, SectionTitle, StatusBadge } from "@/components/ida/core";
import { useConsent } from "@/components/ida/ConsentSheet";
import { RegisterIcon } from "@/components/ida/RegisterIcon";
import { CATEGORY_FILTERS, REGISTER_CATEGORY, registerStatus, registerSummary } from "@/lib/registers";
import { REGISTER_AREA, areaAllowed } from "@/lib/acting";

export const Route = createFileRoute("/vault/")({
  head: () => ({
    meta: [
      { title: "Vault – ida 2030" },
      { name: "description", content: "Your documents and data from official registers – fetched only with your consent." },
      { property: "og:title", content: "Vault – ida 2030" },
      { property: "og:description", content: "Your documents and register data in one secure place." },
    ],
  }),
  component: VaultScreen,
});

function VaultScreen() {
  const { state, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const consent = useConsent();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<"all" | DocCategory>("all");
  const allRegs = registersByUser[state.currentUserId] ?? [];
  const regs = allRegs.filter((r) => areaAllowed(state, REGISTER_AREA[r.id]));

  const match = (text: string, c: DocCategory | undefined) =>
    (cat === "all" || c === cat) && (!q.trim() || text.toLowerCase().includes(q.toLowerCase()));
  const shownRegs = useMemo(() => regs.filter((r) => match(`${r.name.en} ${r.name.de} ${r.authority} ${r.fields.map((f) => f.value).join(" ")}`, REGISTER_CATEGORY[r.id])), [regs, q, cat]); // eslint-disable-line react-hooks/exhaustive-deps
  const uploads = state.vaultDocuments.filter((d) => match(`${d.title} ${d.origin ?? ""}`, d.category));

  const openRegister = async (id: string) => {
    const r = regs.find((x) => x.id === id)!;
    if (!state.fetchedRegisters[id] && r.sensitivity !== "critical") {
      const ok = await consent({ registers: [id], purpose: "Show in my vault" });
      if (!ok) return;
    }
    navigate({ to: "/vault/register/$registerId", params: { registerId: id } });
  };

  const fetchAll = async () => {
    const ids = regs.filter((r) => r.sensitivity !== "critical").map((r) => r.id);
    const ok = await consent({ registers: ids, purpose: "Fill my vault with my official data", selectable: true });
    if (ok) toast.success(`${ok.length} registers fetched`);
  };

  return (
    <>
      <ScreenHeader title="Vault" onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="relative flex-1 p-5 pb-24">
        <label className="relative block">
          <span className="sr-only">Search the vault</span>
          <Search className="absolute start-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search documents and data" className="min-h-[52px] w-full rounded-2xl border border-input bg-surface ps-12 pe-4" />
        </label>
        <div className="-mx-5 mt-3 flex gap-2 overflow-x-auto px-5 pb-1" role="group" aria-label="Filter">
          {CATEGORY_FILTERS.map((c) => <Chip key={c.id} selected={cat === c.id} onClick={() => setCat(c.id)} className="shrink-0">{c.label}</Chip>)}
        </div>

        <Button className="mt-4" variant="secondary" icon={<DatabaseZap className="size-5" aria-hidden />} onClick={fetchAll}>Fetch all my data</Button>

        {state.actingFor && <p className="mt-3 rounded-2xl bg-surface p-3 text-sm text-muted-foreground">Only areas covered by the power of attorney are shown.</p>}

        <SectionTitle>From official registers</SectionTitle>
        {shownRegs.length === 0 && <p className="text-muted-foreground">No register matches.</p>}
        <ul className="space-y-2">
          {shownRegs.map((r) => {
            const st = registerStatus(r, !!state.fetchedRegisters[r.id]);
            return (
              <li key={r.id}>
                <button type="button" onClick={() => openRegister(r.id)} className="flex w-full items-start gap-3 rounded-2xl border border-border bg-card p-4 text-start shadow-soft hover:bg-surface">
                  <span className={r.sensitivity === "critical" ? "flex size-11 shrink-0 items-center justify-center rounded-xl bg-security-bg text-security" : "flex size-11 shrink-0 items-center justify-center rounded-xl bg-surface text-primary"}>
                    <RegisterIcon name={r.icon} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-bold">{r.name.en}</span>
                    <span className="block text-sm text-muted-foreground">{r.authority}</span>
                    <span className="mt-1 block truncate text-sm">{st === "not_fetched" && r.sensitivity !== "critical" ? "Tap to fetch with your consent" : registerSummary(r)}</span>
                    <span className="mt-2 flex flex-wrap gap-1.5">
                      <span className="inline-flex items-center gap-1 rounded-full bg-success-bg px-2 py-0.5 text-xs font-bold text-success"><ShieldCheck className="size-3.5" aria-hidden />Verified by the state</span>
                      {st === "not_fetched" && <span className="rounded-full bg-surface px-2 py-0.5 text-xs font-bold text-muted-foreground">Not fetched yet</span>}
                      {st === "up_to_date" && <StatusBadge status="approved" className="text-xs">Up to date</StatusBadge>}
                      {st === "expiring" && <StatusBadge status="expiring" className="text-xs">Expiring soon</StatusBadge>}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>

        <SectionTitle>My uploads</SectionTitle>
        {uploads.length === 0 ? (
          <EmptyState icon={<FileUp className="size-7" />} title="No uploads yet" text="Upload a document or save a letter here." />
        ) : (
          <ul className="space-y-2">
            {uploads.map((d) => (
              <li key={d.id}>
                <Link to="/vault/document/$id" params={{ id: d.id }} className="flex items-center gap-3 rounded-2xl border border-border p-4 hover:bg-surface">
                  <FileUp className="size-6 text-primary" aria-hidden />
                  <span className="min-w-0 flex-1"><span className="block truncate font-bold">{d.title}</span><span className="block text-sm text-muted-foreground">{d.origin ?? "Uploaded by you"}</span></span>
                  <StatusBadge status="uploaded" />
                </Link>
              </li>
            ))}
          </ul>
        )}

        <Link to="/vault/upload" className="sticky bottom-4 float-end mt-4 flex min-h-14 items-center gap-2 rounded-full bg-ida-gradient px-5 font-bold text-primary-foreground shadow-lift">
          <Plus className="size-5" aria-hidden />Upload document
        </Link>
      </main>
    </>
  );
}
