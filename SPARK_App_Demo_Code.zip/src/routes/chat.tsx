import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Phone, MoreVertical, Mic, Camera, Send, Globe, Trash2, UserRound, LogIn, FilePlus2, DatabaseZap, CalendarPlus, ScanLine, Volume2 } from "lucide-react";
import { useApp, newId, type ChatMessage } from "@/context/AppContext";
import { ask, render, type AnswerSpec, type ChatActionKind } from "@/services/ai";
import { IdaAvatar, AiBadge, Sheet, Toggle, toast } from "@/components/ida/extras";
import { Chip, Button } from "@/components/ida/core";
import { GlossaryText } from "@/components/ida/GlossaryText";
import { useConsent } from "@/components/ida/ConsentSheet";
import { LANGUAGES } from "@/i18n";
import { getService } from "@/data/knowledge";
import { getRecognitionCtor, listenOnce, speak } from "@/lib/speech";
import { cn } from "@/lib/utils";

type Search = { letter?: string; q?: string };
export const Route = createFileRoute("/chat")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["letter"] === "string" ? { letter: s["letter"] } : {}),
    ...(typeof s["q"] === "string" ? { q: s["q"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Chat with ida – ida 2030" },
      { name: "description", content: "Ask ida about Austrian official procedures – answers from verified sources, in your language." },
      { property: "og:title", content: "Chat with ida – ida 2030" },
      { property: "og:description", content: "AI assistant with answers from verified sources." },
    ],
  }),
  component: ChatScreen,
});

const actionMeta: Record<ChatActionKind, { label: string; Icon: typeof FilePlus2 }> = {
  start_application: { label: "Start application", Icon: FilePlus2 },
  fetch_data: { label: "Fetch my data", Icon: DatabaseZap },
  book_appointment: { label: "Book appointment", Icon: CalendarPlus },
  talk_to_person: { label: "Talk to a person", Icon: UserRound },
  scan_letter: { label: "Scan a letter", Icon: ScanLine },
};

const time = (iso: string) => new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });

function ChatScreen() {
  const { state, dispatch } = useApp();
  const { letter, q } = Route.useSearch();
  const navigate = useNavigate();
  const consent = useConsent();
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const [menu, setMenu] = useState(false);
  const [langSheet, setLangSheet] = useState(false);
  const [person, setPerson] = useState(false);
  const [listening, setListening] = useState(false);
  const [hasMic, setHasMic] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const started = useRef(false);
  const loggedIn = state.isLoggedIn;
  const ctx = { userId: loggedIn ? state.currentUserId : null, language: state.language, easy: state.accessibility.easyLanguage };
  const lastIdaIdx = state.chat.map((m) => m.from).lastIndexOf("ida");

  useEffect(() => { setHasMic(!!getRecognitionCtor()); }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [state.chat.length, typing]);

  const send = async (msg: string, opts: { letterId?: string } = {}) => {
    if (!msg.trim()) return;
    const now = new Date().toISOString();
    dispatch({ type: "ADD_CHAT", message: { id: newId(), from: "user", text: msg, language: state.language, at: now } });
    setText(""); setTyping(true);
    const spec = await ask(msg, opts);
    setTyping(false);
    const r = render(spec, ctx);
    dispatch({ type: "ADD_CHAT", message: { id: newId(), from: "ida", text: r.text, language: state.language, at: new Date().toISOString(), spec } });
    if (state.accessibility.readAloud) speak(r.text, state.language, state.accessibility.easyLanguage ? 0.8 : 1);
  };

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    if (letter) send("Please explain this letter.", { letterId: letter });
    else if (q) send(q);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const runAction = async (kind: ChatActionKind, serviceId?: string) => {
    const svc = serviceId ? getService(serviceId) : undefined;
    if (kind === "talk_to_person") { setPerson(true); return; }
    if (kind === "scan_letter") { navigate({ to: "/scan" }); return; }
    if (!loggedIn) { navigate({ to: "/login" }); return; }
    const log = (title: string, type: "register_query" | "submission" | "appointment_booked" | "handover") =>
      dispatch({ type: "LOG", entry: { type, title, purpose: svc?.title.en ?? "Chat request", actor: "self", level: "basic", channel: "app", ...(svc ? { authority: svc.authority } : {}) } });
    if (kind === "start_application" && svc) { log(`Started "${svc.title.en}" from chat`, "submission"); navigate({ to: "/applications/new/$procedureId", params: { procedureId: svc.id } }); }
    if (kind === "fetch_data") {
      const regs = svc?.fetchableRegisters ?? ["transparency", "tax", "social"];
      const ok = await consent({ registers: regs, purpose: svc ? svc.title.en : "Check possible entitlements" });
      if (ok) toast.success("Data fetched and saved in your vault");
    }
    if (kind === "book_appointment") { log("Opened appointment booking from chat", "appointment_booked"); navigate({ to: "/appointments" }); }
  };

  const mic = () => {
    if (listening) return;
    setListening(true);
    const { promise } = listenOnce(state.language, (t) => setText(t));
    promise.then((t) => { setListening(false); if (t) setText(t); });
  };

  const lang = LANGUAGES.find((l) => l.code === state.language)!;
  const welcome = state.chat.length === 0;

  return (
    <div className="flex min-h-full flex-1 flex-col">
      <header className="sticky top-0 z-10 flex items-center gap-2 border-b border-border bg-background/95 px-3 py-2 backdrop-blur">
        <IdaAvatar size={44} speaking={typing} />
        <div className="min-w-0 flex-1">
          <h1 className="text-xl font-bold leading-tight">ida</h1>
          <p className="truncate text-sm text-muted-foreground">AI assistant · answers from verified sources</p>
        </div>
        <button type="button" onClick={() => setLangSheet(true)} aria-label={`Language: ${lang.native}`} className="flex min-h-11 items-center gap-1 rounded-full px-2 text-sm font-bold hover:bg-surface"><Globe className="size-5" aria-hidden />{lang.short}</button>
        <Link to="/call" aria-label="Call ida" className="flex size-11 items-center justify-center rounded-full hover:bg-surface"><Phone className="size-5 text-primary" aria-hidden /></Link>
        <button type="button" onClick={() => setMenu(true)} aria-label="Chat menu" className="flex size-11 items-center justify-center rounded-full hover:bg-surface"><MoreVertical className="size-5" aria-hidden /></button>
      </header>

      {!loggedIn && (
        <div role="note" className="flex items-center gap-2 bg-warning-bg px-4 py-2 text-sm font-bold text-warning">
          <span className="flex-1">You are not logged in – ida can only give general answers.</span>
          <Link to="/login" className="min-h-11 py-2 underline">Log in</Link>
        </div>
      )}

      <div className="flex-1 space-y-4 px-4 py-4" aria-live="polite">
        {welcome && (
          <div className="rounded-2xl bg-surface p-4">
            <p className="font-bold">Hi{loggedIn ? "" : " there"}! I'm ida, an AI assistant.</p>
            <p className="mt-1 text-muted-foreground">Ask me about official procedures. You can ask for a person at any time.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {["Renew my residence permit", "Register a birth", "Get my tax refund"].map((s) => <Chip key={s} onClick={() => send(s)}>{s}</Chip>)}
            </div>
          </div>
        )}
        {state.chat.map((m, i) => <Bubble key={m.id} m={m} isLast={i === lastIdaIdx} ctx={ctx} loggedIn={loggedIn} onChip={send} onAction={runAction} />)}
        {typing && (
          <div className="flex w-20 items-center justify-center gap-1 rounded-2xl rounded-bl-md bg-surface px-4 py-4" role="status" aria-label="ida is typing">
            {[0, 1, 2].map((d) => <span key={d} className="size-2 animate-bounce rounded-full bg-primary" style={{ animationDelay: `${d * 150}ms` }} />)}
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form onSubmit={(e) => { e.preventDefault(); send(text); }} className="sticky bottom-0 flex items-center gap-1.5 border-t border-border bg-background p-2">
        <Link to="/scan" aria-label="Scan a letter" className="flex size-11 shrink-0 items-center justify-center rounded-full hover:bg-surface"><Camera className="size-5 text-primary" aria-hidden /></Link>
        <label htmlFor="chat-input" className="sr-only">Message to ida</label>
        <input id="chat-input" value={text} onChange={(e) => setText(e.target.value)} placeholder={listening ? "Listening…" : "Ask ida…"} autoComplete="off"
          className="min-h-11 min-w-0 flex-1 rounded-full border border-input bg-surface px-4" />
        {hasMic && (
          <button type="button" onClick={mic} aria-label={listening ? "Listening" : "Speak"} aria-pressed={listening}
            className={cn("flex size-11 shrink-0 items-center justify-center rounded-full", listening ? "bg-security-bg text-security animate-pulse" : "hover:bg-surface text-primary")}>
            <Mic className="size-5" aria-hidden />
          </button>
        )}
        <button type="submit" aria-label="Send" disabled={!text.trim() || typing} className="flex size-11 shrink-0 items-center justify-center rounded-full bg-ida-gradient text-primary-foreground disabled:opacity-40">
          <Send className="size-5 rtl:rotate-180" aria-hidden />
        </button>
      </form>

      <Sheet open={menu} onOpenChange={setMenu} title="Chat options">
        <div className="divide-y divide-border">
          <Toggle checked={state.accessibility.easyLanguage} onChange={(v) => dispatch({ type: "SET_ACCESSIBILITY", patch: { easyLanguage: v } })} label="Easy Language" description="Shorter sentences" />
          <Toggle checked={state.accessibility.readAloud} onChange={(v) => dispatch({ type: "SET_ACCESSIBILITY", patch: { readAloud: v } })} label="Read answers aloud" />
        </div>
        <div className="mt-4 space-y-2">
          <Button variant="secondary" icon={<UserRound className="size-5" aria-hidden />} onClick={() => { setMenu(false); setPerson(true); }}>Talk to a person</Button>
          <Button variant="ghost" icon={<Trash2 className="size-5" aria-hidden />} onClick={() => { dispatch({ type: "CLEAR_CHAT" }); setMenu(false); toast.info("Chat cleared"); }}>Clear chat</Button>
        </div>
      </Sheet>

      <Sheet open={langSheet} onOpenChange={setLangSheet} title="Language">
        <div className="flex flex-wrap gap-2">
          {LANGUAGES.map((l) => <Chip key={l.code} selected={l.code === state.language} onClick={() => { dispatch({ type: "SET_LANGUAGE", language: l.code }); setLangSheet(false); }}>{l.native}</Chip>)}
        </div>
        <p className="mt-3 text-sm text-muted-foreground">The last answer is shown again in the new language.</p>
      </Sheet>

      <Sheet open={person} onOpenChange={setPerson} title="Talk to a person">
        <p>A service employee can help you. ida passes on a short summary of this chat, so you don't have to repeat yourself.</p>
        <div className="mt-4 space-y-2">
          <Button icon={<Phone className="size-5" aria-hidden />} onClick={() => {
            dispatch({ type: "LOG", entry: { type: "handover", title: "Asked for a person from chat", purpose: "Personal help", actor: "self", level: "public", channel: "app" } });
            setPerson(false); navigate({ to: "/call", search: { transfer: "1" } });
          }}>Call now (simulated)</Button>
          <Button variant="ghost" onClick={() => { setPerson(false); navigate({ to: "/help" }); }}>Other contact options</Button>
        </div>
      </Sheet>
    </div>
  );
}

function Bubble({ m, isLast, ctx, loggedIn, onChip, onAction }: {
  m: ChatMessage; isLast: boolean; ctx: { userId: string | null; language: ChatMessage["language"]; easy: boolean }; loggedIn: boolean;
  onChip: (t: string) => void; onAction: (k: ChatActionKind, s?: string) => void;
}) {
  if (m.from === "user") {
    return (
      <div className="flex flex-col items-end">
        <p className="max-w-[85%] rounded-2xl rounded-br-md bg-ida-gradient px-4 py-3 text-primary-foreground">{m.text}</p>
        <span className="mt-1 text-xs text-muted-foreground">{time(m.at)}</span>
      </div>
    );
  }
  const spec = m.spec as AnswerSpec | undefined;
  // The last answer follows the current language; older answers keep the language they were given in.
  const r = spec ? render(spec, isLast ? ctx : { ...ctx, language: m.language }) : null;
  const shownText = r?.text ?? m.text;
  const lang = isLast ? ctx.language : m.language;
  return (
    <div className="flex flex-col items-start">
      <div className="max-w-[90%] rounded-2xl rounded-bl-md bg-surface px-4 py-3" dir={lang === "ar" ? "rtl" : "ltr"} lang={lang === "bcs" ? "bs" : lang}>
        <p><GlossaryText text={shownText} /></p>
        <div className="mt-1 flex items-center justify-between gap-2">
          {r && <AiBadge source={r.source} />}
          <button type="button" onClick={() => speak(shownText, lang, ctx.easy ? 0.8 : 1)} aria-label="Read aloud" className="flex size-11 items-center justify-center rounded-full hover:bg-background"><Volume2 className="size-4 text-muted-foreground" aria-hidden /></button>
        </div>
      </div>
      <span className="mt-1 text-xs text-muted-foreground">{time(m.at)}</span>
      {isLast && r && (
        <>
          {r.actions.length > 0 && (
            <div className="mt-2 flex w-full flex-col gap-2">
              {r.actions.slice(0, 3).map((a) => {
                const { label, Icon } = actionMeta[a.kind];
                const locked = a.personal && !loggedIn;
                return (
                  <button key={a.kind} type="button" onClick={() => onAction(a.kind, a.serviceId)}
                    className="flex min-h-12 items-center gap-2 rounded-2xl border-2 border-primary px-4 font-bold text-primary hover:bg-surface">
                    {locked ? <LogIn className="size-5" aria-hidden /> : <Icon className="size-5" aria-hidden />}
                    {locked ? `Log in to continue · ${label}` : label}
                  </button>
                );
              })}
            </div>
          )}
          {r.suggestions.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">{r.suggestions.slice(0, 3).map((s) => <Chip key={s} onClick={() => onChip(s)}>{s}</Chip>)}</div>
          )}
        </>
      )}
    </div>
  );
}
