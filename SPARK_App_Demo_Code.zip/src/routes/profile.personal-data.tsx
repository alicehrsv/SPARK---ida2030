import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ShieldAlert, AlertCircle } from "lucide-react";
import { useApp, currentUser } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { ScreenHeader } from "@/components/ida/extras";
import { Button, Card, SectionTitle } from "@/components/ida/core";

export const Route = createFileRoute("/profile/personal-data")({
  head: () => ({
    meta: [
      { title: "Personal data – ida 2030" },
      { name: "description", content: "Personal data in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Personal data – ida 2030" },
      { property: "og:description", content: "Personal data in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: PersonalDataScreen,
});

function PersonalDataScreen() {
  const { state, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const u = currentUser(state);
  const regs = registersByUser[state.currentUserId] ?? [];
  const zpr = regs.find((r) => r.id === "zpr");
  const zmr = regs.find((r) => r.id === "zmr");
  const citizenship = regs.find((r) => r.id === "citizenship");

  const names = zpr?.fields.find((f) => f.label === "Names")?.value ?? `${u.firstName} ${u.lastName}`;
  const birth = zpr?.fields.find((f) => f.label === "Birth")?.value ?? u.birthDate;
  const address = zmr?.fields.find((f) => f.label === "Main residence")?.value ?? u.address;
  const citizenshipValue = citizenship?.fields.find((f) => f.label === "Citizenship")?.value ?? u.citizenship;

  const reportError = (field: string) => navigate({ to: "/help", search: { topic: `Error in ${field}: ` } });

  const Row = ({ label, value, source, onReport }: { label: string; value: string; source?: string; onReport: () => void }) => (
    <Card variant="surface">
      <p className="text-sm font-semibold text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-lg font-bold">{value}</p>
      {source && <p className="mt-1 text-sm text-muted-foreground">from {source}</p>}
      <Button className="mt-3" variant="secondary" size="sm" icon={<AlertCircle className="size-4" aria-hidden />} onClick={onReport}>
        Report an error
      </Button>
    </Card>
  );

  return (
    <>
      <ScreenHeader title="Personal data" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <p className="text-muted-foreground">This information comes from official registers. ida cannot change it directly – incorrect entries must be corrected by the responsible authority.</p>

        <Row label="Name" value={names} source={zpr?.name.en ?? "Central Civil Status Register (ZPR)"} onReport={() => reportError("Name")} />
        <Row label="Date of birth" value={birth} source={zpr?.name.en ?? "Central Civil Status Register (ZPR)"} onReport={() => reportError("Date of birth")} />
        <Row label="Citizenship" value={citizenshipValue} source={citizenship?.name.en ?? "Citizenship Register"} onReport={() => reportError("Citizenship")} />

        <Card variant="surface">
          <p className="text-sm font-semibold text-muted-foreground">Address</p>
          <p className="mt-0.5 text-lg font-bold">{address}</p>
          <p className="mt-1 text-sm text-muted-foreground">from {zmr?.name.en ?? "Central Residence Register (ZMR)"}</p>
          <Button className="mt-3" icon={<ShieldAlert className="size-4" aria-hidden />} onClick={() => navigate({ to: "/applications/new/$procedureId", params: { procedureId: "change-address" } })}>
            Change address
          </Button>
        </Card>

        <SectionTitle>Security note</SectionTitle>
        <Card variant="security">
          <p className="flex items-start gap-2 font-bold"><ShieldAlert className="size-5 shrink-0" aria-hidden />A change of address is a critical action</p>
          <p className="mt-1 text-sm">Before it can be submitted, you must confirm your identity with a face scan. This protects you if someone else tries to change your registered address.</p>
        </Card>
      </main>
    </>
  );
}
