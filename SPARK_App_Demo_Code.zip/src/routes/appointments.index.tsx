import { longDate } from "@/lib/dates";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { CalendarPlus, MapPin, RefreshCcw, XCircle, ClipboardList } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { offices } from "@/data/offices";
import { DEMO_TODAY } from "@/data/config";
import { ScreenHeader, Sheet, ListItem, EmptyState, toast } from "@/components/ida/extras";
import { Button, Card, SectionTitle } from "@/components/ida/core";

export const Route = createFileRoute("/appointments/")({
  head: () => ({
    meta: [
      { title: "Appointments – ida 2030" },
      { name: "description", content: "Your upcoming and past appointments in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Appointments – ida 2030" },
      { property: "og:description", content: "Appointments in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: AppointmentsScreen,
});

function fmtDateTime(iso: string) {
  const d = new Date(iso);
  return {
    date: longDate(d),
    time: d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" }),
  };
}

function AppointmentsScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const [pickOffice, setPickOffice] = useState(false);
  const [cancelId, setCancelId] = useState<string | null>(null);

  const now = DEMO_TODAY.getTime();
  const sorted = [...state.appointments].sort((a, b) => a.slot.localeCompare(b.slot));
  const upcoming = sorted.filter((a) => new Date(a.slot).getTime() >= now);
  const past = sorted.filter((a) => new Date(a.slot).getTime() < now);

  const cancel = (id: string) => {
    const appt = state.appointments.find((a) => a.id === id);
    dispatch({ type: "CANCEL_APPOINTMENT", id });
    const relatedReminder = state.reminders.find((r) => r.kind === "appointment" && r.link === "/appointments" && r.title.includes(appt?.purpose ?? "\u0000"));
    if (relatedReminder) dispatch({ type: "DELETE_REMINDER", id: relatedReminder.id });
    dispatch({ type: "LOG", entry: { type: "appointment_booked", title: `Cancelled appointment: ${appt?.purpose ?? ""}`, purpose: appt?.purpose ?? "Appointment", authority: offices.find((o) => o.id === appt?.officeId)?.name ?? "Authority", actor: "self", level: "basic", channel: "app" } });
    toast.success("Appointment cancelled");
    setCancelId(null);
  };

  function AppointmentCard({ a }: { a: (typeof state.appointments)[number] }) {
    const office = offices.find((o) => o.id === a.officeId);
    const { date, time } = fmtDateTime(a.slot);
    const isUpcoming = new Date(a.slot).getTime() >= now;
    return (
      <Card className="space-y-3">
        <div>
          <p className="font-bold">{office?.name ?? "Office"}</p>
          <p className="text-sm text-muted-foreground">{office?.address}</p>
        </div>
        <p className="text-lg font-bold text-primary">{date} · {time}</p>
        <p className="text-muted-foreground">{a.purpose}</p>
        {a.checklist && a.checklist.length > 0 && (
          <div className="rounded-xl bg-surface p-3">
            <p className="mb-1 flex items-center gap-1.5 text-sm font-bold"><ClipboardList className="size-4" aria-hidden />What to bring</p>
            <ul className="list-inside list-disc text-sm text-muted-foreground">
              {a.checklist.map((c) => <li key={c}>{c}</li>)}
            </ul>
          </div>
        )}
        {isUpcoming && office && (
          <div className="grid grid-cols-2 gap-2">
            <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(office.address)}`} target="_blank" rel="noreferrer"
              className="inline-flex min-h-[52px] items-center justify-center gap-2 rounded-2xl border-2 border-primary font-bold text-primary">
              <MapPin className="size-5" aria-hidden />Directions
            </a>
            <Button variant="ghost" size="sm" icon={<RefreshCcw className="size-5" aria-hidden />}
              onClick={() => navigate({ to: "/appointments/book/$officeId", params: { officeId: office.id }, search: { reason: a.purpose, reschedule: a.id, ...(a.applicationId ? { applicationId: a.applicationId } : {}) } })}>
              Reschedule
            </Button>
            <Button variant="ghost" size="sm" className="col-span-2 text-security" icon={<XCircle className="size-5" aria-hidden />} onClick={() => setCancelId(a.id)}>
              Cancel
            </Button>
          </div>
        )}
      </Card>
    );
  }

  return (
    <>
      <ScreenHeader title="Appointments" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <Button icon={<CalendarPlus className="size-5" aria-hidden />} onClick={() => setPickOffice(true)}>Book appointment</Button>

        <SectionTitle>Upcoming</SectionTitle>
        {upcoming.length === 0 ? <EmptyState title="No upcoming appointments" text="Book one whenever you need to visit an office." /> : (
          <div className="space-y-3">{upcoming.map((a) => <AppointmentCard key={a.id} a={a} />)}</div>
        )}

        <SectionTitle>Past</SectionTitle>
        {past.length === 0 ? <p className="text-muted-foreground">No past appointments.</p> : (
          <div className="space-y-3">{past.map((a) => <AppointmentCard key={a.id} a={a} />)}</div>
        )}
      </main>

      <Sheet open={pickOffice} onOpenChange={setPickOffice} title="Choose an office">
        <div className="-mx-2">
          {offices.map((o) => (
            <ListItem key={o.id} title={o.name} subtitle={o.address} onClick={() => { setPickOffice(false); navigate({ to: "/appointments/book/$officeId", params: { officeId: o.id } }); }} />
          ))}
        </div>
      </Sheet>

      <Sheet open={!!cancelId} onOpenChange={(o) => !o && setCancelId(null)} title="Cancel this appointment?">
        <p className="text-muted-foreground">This cannot be undone. You can always book a new appointment.</p>
        <div className="mt-4 space-y-2">
          <Button variant="danger" onClick={() => cancelId && cancel(cancelId)}>Yes, cancel appointment</Button>
          <Button variant="ghost" onClick={() => setCancelId(null)}>Keep appointment</Button>
        </div>
      </Sheet>
    </>
  );
}
