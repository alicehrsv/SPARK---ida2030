import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  LogIn, LogOut, ShieldCheck, ShieldOff, Database, Upload, ScanLine, Send, Undo2, ScanFace, Gift,
  CalendarCheck, Users, PhoneForwarded, Phone as PhoneIcon, Settings as SettingsIcon, Smartphone, SlidersHorizontal,
  Printer, Tablet, Lock, LogOut as LogOutIcon, ChevronDown,
} from "lucide-react";
import { useApp, newId, type Consent } from "@/context/AppContext";
import type { ActivityEntry, ActivityType, SecurityLevel } from "@/types";
import { ScreenHeader, EmptyState, Sheet, Toggle, toast } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { registersByUser } from "@/data/registers";
import { DEMO_TODAY } from "@/data/config";
import { devices } from "@/lib/devices";
import { cn } from "@/lib/utils";

type Search = { register?: string };
export const Route = createFileRoute("/cockpit")({
  validateSearch: (s: Record<string, unknown>): Search => (typeof s["register"] === "string" ? { register: s["register"] } : {}),
  head: () => ({
    meta: [
      { title: "Data cockpit – ida 2030" },
      { name: "description", content: "Every action and data access in ida 2030 – nothing happens silently." },
      { property: "og:title", content: "Data cockpit – ida 2030" },
      { property: "og:description", content: "See every data access and action." },
    ],
  }),
  component: CockpitScreen,
});

const typeIcon: Record<ActivityType, typeof LogIn> = {
  login: LogIn, logout: LogOut, consent_granted: ShieldCheck, consent_revoked: ShieldOff,
  register_query: Database, document_upload: Upload, letter_scanned: ScanLine, submission: Send,
  withdrawal: Undo2, face_match: ScanFace, entitlement_check: Gift, appointment_booked: CalendarCheck,
  power_of_attorney: Users, handover: PhoneForwarded, call: PhoneIcon, settings_changed: SettingsIcon,
};

const levelStyle: Record<SecurityLevel, string> = {
  public: "bg-surface text-muted-foreground",
  basic: "bg-success-bg text-success",
  critical: "bg-security-bg text-security",
};

function fmtDateTime(iso: string) {
  return new Date(iso).toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" });
}

function describe(e: ActivityEntry): string {
  const when = fmtDateTime(e.timestamp);
  if (e.register) {
    const fields = (e.dataFields ?? []).slice(0, 2).map((f) => f.toLowerCase()).join(", ");
    const fieldsPart = fields ? `${fields} – ` : "";
    return `${e.register} – ${fieldsPart}for: ${e.purpose} – ${when}`;
  }
  return `${e.title} – for: ${e.purpose} – ${when}`;
}

type Tab = "activity" | "consents" | "devices";
const tabs: { id: Tab; label: string }[] = [
  { id: "activity", label: "Activity" },
  { id: "consents", label: "Consents" },
  { id: "devices", label: "Devices" },
];

function CockpitScreen() {
  const { register } = Route.useSearch();
  const { state, dispatch, setDemoOpen } = useApp();
  const [tab, setTab] = useState<Tab>("activity");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [fRegister, setFRegister] = useState(register ?? "");
  const [fType, setFType] = useState("");
  const [fChannel, setFChannel] = useState("");
  const [fFrom, setFFrom] = useState("");
  const [fTo, setFTo] = useState("");
  const [selected, setSelected] = useState<ActivityEntry | null>(null);

  const registerOptions = useMemo(
    () => Array.from(new Set(state.activityLog.map((e) => e.register).filter((r): r is string => !!r))).sort(),
    [state.activityLog],
  );
  const typeOptions = useMemo(
    () => Array.from(new Set(state.activityLog.map((e) => e.type))).sort(),
    [state.activityLog],
  );

  const sorted = useMemo(
    () => [...state.activityLog].sort((a, b) => b.timestamp.localeCompare(a.timestamp)),
    [state.activityLog],
  );
  const filtered = sorted.filter((e) => {
    if (fRegister && e.register !== fRegister) return false;
    if (fType && e.type !== fType) return false;
    if (fChannel && e.channel !== fChannel) return false;
    if (fFrom && e.timestamp < new Date(fFrom).toISOString()) return false;
    if (fTo) {
      const to = new Date(fTo); to.setHours(23, 59, 59, 999);
      if (e.timestamp > to.toISOString()) return false;
    }
    return true;
  });

  const queriesThisMonth = state.activityLog.filter(
    (e) => e.type === "register_query" && new Date(e.timestamp).getFullYear() === DEMO_TODAY.getFullYear() && new Date(e.timestamp).getMonth() === DEMO_TODAY.getMonth(),
  ).length;
  const submissions = state.activityLog.filter((e) => e.type === "submission").length;

  const userRegisters = registersByUser[state.currentUserId] ?? [];

  const revokeConsent = (c: Consent) => {
    dispatch({ type: "REVOKE_CONSENT", id: c.id });
    const regName = userRegisters.find((r) => r.id === c.register)?.name.en;
    dispatch({ type: "LOG", entry: { type: "consent_revoked", title: `Revoked consent for ${c.purpose}`, purpose: c.purpose, ...(regName ? { register: regName } : {}), actor: "self", level: "basic", channel: "app" } });
    toast.success("Consent revoked");
  };

  const deviceStatus = state.settings.deviceStatus ?? {};
  const setDeviceAction = (deviceId: string, name: string, status: "logged_out" | "locked", isThisDevice: boolean) => {
    if (isThisDevice) {
      toast.info("Use Profile → Log out to sign out of this phone.");
      return;
    }
    dispatch({ type: "SET_SETTINGS", patch: { deviceStatus: { ...deviceStatus, [deviceId]: status } } });
    dispatch({ type: "LOG", entry: { type: "settings_changed", title: `${status === "locked" ? "Locked" : "Logged out"} device: ${name}`, purpose: "Device security", actor: "self", level: "critical", channel: "app" } });
    toast.success(status === "locked" ? `${name} locked remotely` : `${name} logged out`);
  };

  return (
    <>
      <style>{`
        @media print {
          nav[aria-label="Main"], header, .no-print { display: none !important; }
          main { padding: 0 !important; overflow: visible !important; }
          body, html { height: auto !important; overflow: visible !important; background: #fff !important; }
          [class*="rounded-[48px]"], [class*="border-[10px]"] { border: none !important; border-radius: 0 !important; box-shadow: none !important; width: 100% !important; height: auto !important; }
        }
      `}</style>
      <ScreenHeader title="Data cockpit" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <div className="grid grid-cols-3 gap-2">
          <Card variant="surface" className="p-3 text-center">
            <p className="text-2xl font-bold text-primary">{queriesThisMonth}</p>
            <p className="text-sm text-muted-foreground">Data queries this month</p>
          </Card>
          <Card variant="surface" className="p-3 text-center">
            <p className="text-2xl font-bold text-primary">{state.consents.length}</p>
            <p className="text-sm text-muted-foreground">Active consents</p>
          </Card>
          <Card variant="surface" className="p-3 text-center">
            <p className="text-2xl font-bold text-primary">{submissions}</p>
            <p className="text-sm text-muted-foreground">Submissions</p>
          </Card>
        </div>

        {register && tab === "activity" && (
          <p className="rounded-2xl bg-surface p-3 text-sm">Filtered: <b>{register}</b> · <Link to="/cockpit" className="font-bold text-primary underline">Show all</Link></p>
        )}

        <div role="tablist" aria-label="Data cockpit sections" className="grid grid-cols-3 gap-1 rounded-2xl bg-surface p-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              role="tab"
              id={`tab-${t.id}`}
              aria-selected={tab === t.id}
              aria-controls={`panel-${t.id}`}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn("min-h-11 rounded-xl text-sm font-bold transition-colors", tab === t.id ? "bg-background text-primary shadow-soft" : "text-muted-foreground")}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === "activity" && (
          <section id="panel-activity" role="tabpanel" aria-labelledby="tab-activity" className="space-y-3">
            <div className="no-print">
              <Button variant="ghost" size="sm" icon={<SlidersHorizontal className="size-4" aria-hidden />} onClick={() => setFiltersOpen((o) => !o)} aria-expanded={filtersOpen}>
                Filters <ChevronDown className={cn("size-4 transition-transform", filtersOpen && "rotate-180")} aria-hidden />
              </Button>
              {filtersOpen && (
                <Card variant="surface" className="mt-2 space-y-3 p-4">
                  <label className="block text-sm font-semibold">Register
                    <select className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3" value={fRegister} onChange={(e) => setFRegister(e.target.value)}>
                      <option value="">All</option>
                      {registerOptions.map((r) => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </label>
                  <label className="block text-sm font-semibold">Type
                    <select className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3" value={fType} onChange={(e) => setFType(e.target.value)}>
                      <option value="">All</option>
                      {typeOptions.map((t) => <option key={t} value={t}>{t.replace(/_/g, " ")}</option>)}
                    </select>
                  </label>
                  <label className="block text-sm font-semibold">Channel
                    <select className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3" value={fChannel} onChange={(e) => setFChannel(e.target.value)}>
                      <option value="">All</option>
                      <option value="app">App</option>
                      <option value="phone agent">Phone agent</option>
                    </select>
                  </label>
                  <div className="flex gap-2">
                    <label className="block flex-1 text-sm font-semibold">From
                      <input type="date" className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3" value={fFrom} onChange={(e) => setFFrom(e.target.value)} />
                    </label>
                    <label className="block flex-1 text-sm font-semibold">To
                      <input type="date" className="mt-1 min-h-11 w-full rounded-xl border border-input bg-background px-3" value={fTo} onChange={(e) => setFTo(e.target.value)} />
                    </label>
                  </div>
                  <Button variant="secondary" size="sm" onClick={() => { setFRegister(""); setFType(""); setFChannel(""); setFFrom(""); setFTo(""); }}>Clear filters</Button>
                </Card>
              )}
            </div>

            {filtered.length === 0 ? (
              <EmptyState title="No entries" text="No one has accessed this data yet." />
            ) : (
              <ul className="space-y-2">
                {filtered.map((e) => {
                  const Icon = typeIcon[e.type] ?? Database;
                  return (
                    <li key={e.id}>
                      <button type="button" onClick={() => setSelected(e)} className="flex w-full items-start gap-3 rounded-2xl border border-border p-4 text-left hover:bg-surface">
                        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-surface text-primary" aria-hidden><Icon className="size-5" /></span>
                        <span className="min-w-0 flex-1">
                          <span className="block font-semibold">{describe(e)}</span>
                          <span className="mt-1 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                            <span className={cn("rounded-full px-2 py-0.5 text-xs font-bold", levelStyle[e.level])}>{e.level}</span>
                            <span>{e.channel === "app" ? "App" : "Phone agent"}</span>
                            <span>{e.actor === "self" ? "you" : `by ${e.actor}`}</span>
                          </span>
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        )}

        {tab === "consents" && (
          <section id="panel-consents" role="tabpanel" aria-labelledby="tab-consents" className="space-y-3">
            <Card variant="surface">
              <Toggle
                checked={state.settings.entitlementChecks}
                onChange={(v) => {
                  dispatch({ type: "SET_SETTINGS", patch: { entitlementChecks: v } });
                  dispatch({ type: "LOG", entry: { type: "settings_changed", title: `${v ? "Enabled" : "Disabled"} entitlement checks`, purpose: "Settings", actor: "self", level: "basic", channel: "app" } });
                  toast.success(v ? "ida will check your entitlements" : "Entitlement checks turned off");
                }}
                label="Let ida check my entitlements"
                description="ida regularly checks if you qualify for benefits."
              />
            </Card>
            {state.consents.length === 0 ? (
              <EmptyState title="No consents" text="You haven't given any data consents yet." />
            ) : (
              state.consents.map((c) => {
                const r = userRegisters.find((x) => x.id === c.register);
                return (
                  <Card key={c.id}>
                    <p className="font-bold">{c.purpose}</p>
                    <p className="text-sm text-muted-foreground">{r?.name.en ?? c.register}</p>
                    {r && <p className="mt-1 text-sm">{r.fields.map((f) => f.label).join(" · ")}</p>}
                    <p className="mt-2 text-sm text-muted-foreground">Given on {fmtDateTime(c.grantedAt)} · {c.scope === "always" ? "Always" : "Once"}</p>
                    <Button variant="danger" size="sm" className="mt-3" onClick={() => revokeConsent(c)}>Revoke</Button>
                  </Card>
                );
              })
            )}
          </section>
        )}

        {tab === "devices" && (
          <section id="panel-devices" role="tabpanel" aria-labelledby="tab-devices" className="space-y-3">
            {devices.map((d) => {
              const status = deviceStatus[d.id];
              const Icon = d.kind === "phone" ? Smartphone : Tablet;
              return (
                <Card key={d.id}>
                  <div className="flex items-start gap-3">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-surface text-primary" aria-hidden><Icon className="size-5" /></span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-bold">{d.name}{d.isThisDevice && " (this device)"}</span>
                      <span className="block text-sm text-muted-foreground">Last used {fmtDateTime(d.lastUsed)}</span>
                      {status && <span className="mt-1 inline-block rounded-full bg-security-bg px-2 py-0.5 text-xs font-bold text-security">{status === "locked" ? "Locked" : "Logged out"}</span>}
                    </span>
                  </div>
                  {d.isThisDevice ? (
                    <p className="mt-3 text-sm text-muted-foreground">To log out of this phone, go to Profile → Log out.</p>
                  ) : (
                    <div className="mt-3 flex gap-2">
                      <Button variant="secondary" size="sm" icon={<Lock className="size-4" aria-hidden />} disabled={status === "locked"} onClick={() => setDeviceAction(d.id, d.name, "locked", d.isThisDevice)}>Lock remotely</Button>
                      <Button variant="danger" size="sm" icon={<LogOutIcon className="size-4" aria-hidden />} disabled={status === "logged_out"} onClick={() => setDeviceAction(d.id, d.name, "logged_out", d.isThisDevice)}>Log out</Button>
                    </div>
                  )}
                </Card>
              );
            })}
          </section>
        )}

        <Button variant="secondary" icon={<Printer className="size-5" aria-hidden />} onClick={() => window.print()} className="no-print">Download as PDF</Button>
      </main>

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)} title={selected?.register ?? selected?.title ?? "Entry"}>
        {selected && (
          <div className="space-y-2 text-sm">
            <p><span className="font-bold">Purpose:</span> {selected.purpose}</p>
            {selected.authority && <p><span className="font-bold">Authority:</span> {selected.authority}</p>}
            {selected.dataFields && <p><span className="font-bold">Fields:</span> {selected.dataFields.join(", ")}</p>}
            <p><span className="font-bold">When:</span> {fmtDateTime(selected.timestamp)}</p>
            <p><span className="font-bold">Who:</span> {selected.actor === "self" ? "you" : `by ${selected.actor}`}</p>
            <p><span className="font-bold">Channel:</span> {selected.channel === "app" ? "App" : "Phone agent"}</p>
            <p><span className="font-bold">Sensitivity:</span> {selected.level}</p>
          </div>
        )}
      </Sheet>
    </>
  );
}
