import { createFileRoute } from "@tanstack/react-router";
import { Lock, LogOut, Smartphone, Tablet } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { ScreenHeader, toast } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { devices } from "@/lib/devices";

export const Route = createFileRoute("/profile/devices")({
  head: () => ({
    meta: [
      { title: "Devices – ida 2030" },
      { name: "description", content: "Devices in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Devices – ida 2030" },
      { property: "og:description", content: "Devices in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: DevicesScreen,
});

const fmt = (iso: string) => new Date(iso).toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" });

function DevicesScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const deviceStatus = state.settings.deviceStatus ?? {};

  const setDeviceAction = (deviceId: string, name: string, status: "logged_out" | "locked", isThisDevice: boolean) => {
    if (isThisDevice) {
      toast.info("Use Profile → Log out to sign out of this phone.");
      return;
    }
    dispatch({ type: "SET_SETTINGS", patch: { deviceStatus: { ...deviceStatus, [deviceId]: status } } });
    dispatch({ type: "LOG", entry: { type: "settings_changed", title: `${status === "locked" ? "Locked" : "Logged out"} device: ${name}`, purpose: "Device security", actor: "self", level: "critical", channel: "app" } });
    toast.success(status === "locked" ? `${name} locked remotely` : `${name} logged out`);
  };

  return (
    <>
      <ScreenHeader title="Devices" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-3 p-5">
        <p className="text-muted-foreground">Devices that are signed in to your ida account.</p>
        {devices.map((d) => {
          const status = deviceStatus[d.id];
          const Icon = d.kind === "phone" ? Smartphone : Tablet;
          return (
            <Card key={d.id}>
              <div className="flex items-start gap-3">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-surface text-primary" aria-hidden><Icon className="size-5" /></span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold">{d.name}{d.isThisDevice && " (this device)"}</span>
                  <span className="block text-sm text-muted-foreground">Last used {fmt(d.lastUsed)}</span>
                  {status && <span className="mt-1 inline-block rounded-full bg-security-bg px-2 py-0.5 text-xs font-bold text-security">{status === "locked" ? "Locked" : "Logged out"}</span>}
                </span>
              </div>
              {d.isThisDevice ? (
                <p className="mt-3 text-sm text-muted-foreground">To log out of this phone, go to Profile → Log out.</p>
              ) : (
                <div className="mt-3 flex gap-2">
                  <Button variant="secondary" size="sm" icon={<Lock className="size-4" aria-hidden />} disabled={status === "locked"} onClick={() => setDeviceAction(d.id, d.name, "locked", d.isThisDevice)}>Lock remotely</Button>
                  <Button variant="danger" size="sm" icon={<LogOut className="size-4" aria-hidden />} disabled={status === "logged_out"} onClick={() => setDeviceAction(d.id, d.name, "logged_out", d.isThisDevice)}>Log out</Button>
                </div>
              )}
            </Card>
          );
        })}
      </main>
    </>
  );
}
