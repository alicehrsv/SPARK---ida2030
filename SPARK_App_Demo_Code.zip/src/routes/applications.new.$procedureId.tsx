import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import * as React from "react";
import {
  Check, Circle, FileText, Upload, Pencil, AlertTriangle, CalendarPlus, Home as HomeIcon, ShieldAlert, Clock, CheckCircle2,
} from "lucide-react";
import { useApp, newId } from "@/context/AppContext";
import type { Application } from "@/context/AppContext";
import { useConsent } from "@/components/ida/ConsentSheet";
import { useCriticalAction } from "@/hooks/useCriticalAction";
import { ScreenHeader, Sheet, EmptyState, toast } from "@/components/ida/extras";
import { Button, Card, StatusBadge } from "@/components/ida/core";
import { getTemplate, type WorkflowTemplate, type WorkflowStep } from "@/services/workflows";
import { registersByUser } from "@/data/registers";
import { offices } from "@/data/offices";
import { DEMO_TODAY } from "@/data/config";
import { fakeLatency } from "@/services/delay";
import { cn } from "@/lib/utils";

interface Search { queue?: string; from?: string }

export const Route = createFileRoute("/applications/new/$procedureId")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["queue"] === "string" ? { queue: s["queue"] } : {}),
    ...(typeof s["from"] === "string" ? { from: s["from"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "New application – ida 2030" },
      { name: "description", content: "New application in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "New application – ida 2030" },
      { property: "og:description", content: "New application in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: NewApplicationScreen,
});

/* ---------------- helpers ---------------- */

function registerFieldValue(userId: string, registerId: string, field: string): string | undefined {
  const reg = (registersByUser[userId] ?? []).find((r) => r.id === registerId);
  return reg?.fields.find((f) => f.label === field)?.value;
}
function registerName(userId: string, registerId: string): string | undefined {
  return (registersByUser[userId] ?? []).find((r) => r.id === registerId)?.name.en;
}
function registerExists(userId: string, registerId: string): boolean {
  return (registersByUser[userId] ?? []).some((r) => r.id === registerId);
}

function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
}
function fmtTime(iso: string) {
  return new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
}

function makeReference(authority: string, appId: string): string {
  let hash = 0;
  for (const ch of appId) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  const num = 10000 + (hash % 90000);
  const abbrev =
    authority
      .split(/[\s–-]+/)
      .filter((w) => /^[A-ZÄÖÜ0-9]/.test(w))
      .map((w) => w[0])
      .join("")
      .slice(0, 4) || "REF";
  return `${abbrev}-2030-${num}`;
}

function buildIcs(title: string, startIso: string, location: string): string {
  const start = new Date(startIso);
  const end = new Date(start.getTime() + 30 * 60 * 1000);
  const fmt = (d: Date) => d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//ida 2030//EN",
    "BEGIN:VEVENT",
    `UID:${newId()}@ida2030`,
    `DTSTAMP:${fmt(new Date())}`,
    `DTSTART:${fmt(start)}`,
    `DTEND:${fmt(end)}`,
    `SUMMARY:${title}`,
    `LOCATION:${location}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
}

function downloadIcs(filename: string, content: string) {
  const blob = new Blob([content], { type: "text/calendar" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ---------------- Stepper (compact for many steps) ---------------- */

function RunnerStepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className={steps.length > 5 ? "-mx-5 overflow-x-auto px-5" : ""}>
      <ol className={cn("flex items-start gap-1", steps.length > 5 && "min-w-max")} aria-label="Progress">
        {steps.map((s, i) => {
          const done = i < current;
          const active = i === current;
          return (
            <li
              key={`${s}-${i}`}
              className={cn("flex flex-col items-center gap-1 text-center", steps.length > 5 ? "w-16 shrink-0" : "flex-1")}
              aria-current={active ? "step" : undefined}
            >
              <span
                className={cn(
                  "flex size-8 items-center justify-center rounded-full text-sm font-bold",
                  done ? "bg-success text-primary-foreground" : active ? "bg-ida-gradient text-primary-foreground" : "bg-surface text-muted-foreground",
                )}
              >
                {done ? <Check className="size-4" aria-label="done" /> : i + 1}
              </span>
              <span className={cn("text-xs leading-tight", active ? "font-bold text-foreground" : "text-muted-foreground")}>{s}</span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

/* ---------------- main screen ---------------- */

type DocStatus = "auto" | "pending" | "fetched" | "uploaded";
type FetchStatus = "idle" | "loading" | "done";

function NewApplicationScreen() {
  const { procedureId } = Route.useParams();
  const search = Route.useSearch();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const requestConsent = useConsent();
  const userId = state.currentUserId;

  const template = getTemplate(procedureId);

  if (!template) {
    return (
      <>
        <ScreenHeader title="New application" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex-1 p-5">
          <EmptyState
            icon={<FileText className="size-7" aria-hidden />}
            title="We don't recognise this procedure"
            text="This application type isn't available yet. Please go back and choose a service from the catalog."
          />
        </main>
      </>
    );
  }

  return <Runner template={template} procedureId={procedureId} search={search} />;
}

function Runner({ template, procedureId, search }: { template: WorkflowTemplate; procedureId: string; search: Search }) {
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const requestConsent = useConsent();
  const userId = state.currentUserId;

  const existingApp = React.useMemo(
    () => state.applications.find((a) => a.procedureId === procedureId && a.status === "draft"),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  const [appId] = React.useState(() => existingApp?.id ?? newId());
  const [stepIndex, setStepIndex] = React.useState(() => existingApp?.stepIndex ?? 0);
  const [data, setData] = React.useState<Record<string, string>>(() => existingApp?.data ?? {});
  const [confirmed, setConfirmed] = React.useState<Set<string>>(new Set());
  const [editingKey, setEditingKey] = React.useState<string | null>(null);

  const steps = template.steps;
  const stepNames = steps.map((s) => s.name);
  const step: WorkflowStep = steps[stepIndex]!;

  // documents checklist status
  const [docStatus, setDocStatus] = React.useState<DocStatus[]>(() =>
    template.documents.map((d) => (d.fromRegister && registerExists(userId, d.fromRegister) ? "auto" : "pending")),
  );

  // fetch step state
  const fetchRegisters = React.useMemo(() => {
    if (step.type === "fetch" && step.registers) return step.registers;
    const fromFields = template.formFields.filter((f) => f.source !== "user").map((f) => (f.source as { register: string }).register);
    return Array.from(new Set(fromFields));
  }, [step, template.formFields]);
  const [fetchStatus, setFetchStatus] = React.useState<Record<string, FetchStatus>>(() =>
    Object.fromEntries(fetchRegisters.map((r) => [r, "idle" as FetchStatus])),
  );

  // choice step
  const [paymentModel, setPaymentModel] = React.useState<string | undefined>(() => data["paymentModel"]);

  // appointment step
  const office = template.officeId ? offices.find((o) => o.id === template.officeId) : undefined;
  const [appointmentSlot, setAppointmentSlot] = React.useState<string | undefined>(() => data["appointmentSlot"]);
  const [appointmentId, setAppointmentId] = React.useState<string | undefined>(() => data["appointmentId"]);

  // facematch / submit
  const critical = useCriticalAction(`submit:${procedureId}`);
  const [submitPhase, setSubmitPhase] = React.useState<"idle" | "sending" | "done">("idle");
  const [result, setResult] = React.useState<{ reference: string; authority: string } | null>(null);
  const submittedRef = React.useRef(false);

  const prefillForField = React.useCallback(
    (key: string) => {
      const field = template.formFields.find((f) => f.key === key);
      if (!field || field.source === "user") return undefined;
      return registerFieldValue(userId, field.source.register, field.source.field);
    },
    [template.formFields, userId],
  );

  // pre-seed form data from registers whenever we reach/pass the form step
  React.useEffect(() => {
    setData((prev) => {
      const next = { ...prev };
      let changed = false;
      for (const f of template.formFields) {
        if (next[f.key] === undefined) {
          const pre = f.source === "user" ? undefined : registerFieldValue(userId, f.source.register, f.source.field);
          if (pre !== undefined) {
            next[f.key] = pre;
            changed = true;
          }
        }
      }
      return changed ? next : prev;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveDraft = (atStep: number, extra?: Record<string, string>) => {
    const title = template.title;
    const app: Application = {
      id: appId,
      procedureId,
      title,
      status: "draft",
      stepIndex: atStep,
      createdAt: existingApp?.createdAt ?? DEMO_TODAY.toISOString(),
      data: { ...data, ...extra },
    };
    dispatch({ type: "UPSERT_APPLICATION", item: app });
    return app;
  };

  const saveAndContinueLater = () => {
    saveDraft(stepIndex);
    toast.success("Saved – continue any time");
    navigate({ to: "/applications" });
  };

  /* ---------- checklist step ---------- */
  const fetchDocument = async (idx: number) => {
    const doc = template.documents[idx]!;
    if (!doc.fromRegister) return;
    const ids = await requestConsent({ registers: [doc.fromRegister], purpose: `Checklist: ${doc.name}` });
    if (!ids) return;
    setDocStatus((prev) => prev.map((s, i) => (i === idx ? "fetched" : s)));
  };
  const uploadDocument = (idx: number) => {
    setDocStatus((prev) => prev.map((s, i) => (i === idx ? "uploaded" : s)));
    toast.success("File received (simulated)");
  };
  const checklistComplete = docStatus.every((s) => s !== "pending");

  /* ---------- fetch step ---------- */
  const runFetch = async () => {
    const ids = await requestConsent({ registers: fetchRegisters, purpose: `Prefill your application: ${template.title}` });
    if (!ids) return;
    setFetchStatus(Object.fromEntries(fetchRegisters.map((r) => [r, "loading" as FetchStatus])));
    ids.forEach((id, i) => {
      setTimeout(() => {
        setFetchStatus((prev) => ({ ...prev, [id]: "done" }));
      }, 400 + i * 350);
    });
  };
  const fetchComplete = fetchRegisters.length === 0 || fetchRegisters.every((r) => fetchStatus[r] === "done");

  /* ---------- form step ---------- */
  const formValid = template.formFields.every((f) => {
    const v = data[f.key];
    if (f.required && !v) return false;
    if (f.uncertain && !confirmed.has(f.key)) return false;
    return true;
  });

  /* ---------- upload step ---------- */
  const uploadDocs = template.documents.map((d, i) => ({ d, i })).filter(({ d }) => !d.fromRegister);
  const uploadComplete = uploadDocs.every(({ i }) => docStatus[i] !== "pending");

  /* ---------- choice step ---------- */
  const choiceValid = !template.paymentModels || !!paymentModel;

  /* ---------- appointment step ---------- */
  const daysWithSlots = React.useMemo(() => {
    if (!office) return [];
    const byDay = new Map<string, string[]>();
    for (const slot of office.slots) {
      const day = slot.slice(0, 10);
      if (!byDay.has(day)) byDay.set(day, []);
      byDay.get(day)!.push(slot);
    }
    return Array.from(byDay.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .slice(0, 3);
  }, [office]);
  const appointmentValid = step.type !== "appointment" || !!appointmentSlot;

  const confirmAppointment = () => {
    if (!office || !appointmentSlot || appointmentId) return;
    const id = newId();
    dispatch({
      type: "ADD_APPOINTMENT",
      item: { id, officeId: office.id, slot: appointmentSlot, purpose: template.title, checklist: template.documents.map((d) => d.name), applicationId: appId },
    });
    const dueDate = new Date(appointmentSlot);
    dueDate.setDate(dueDate.getDate() - 1);
    dueDate.setHours(9, 0, 0, 0);
    dispatch({
      type: "UPSERT_REMINDER",
      item: { id: newId(), title: `Appointment tomorrow: ${template.title}`, due: dueDate.toISOString(), done: false, link: "/appointments", kind: "appointment", source: "Your appointment", enabled: true, procedureId },
    });
    setAppointmentId(id);
    setData((prev) => ({ ...prev, appointmentSlot, appointmentId: id }));
  };

  /* ---------- facematch auto-advance ---------- */
  React.useEffect(() => {
    if (step.type === "facematch" && critical.approved) {
      critical.consume();
      setStepIndex((i) => Math.min(i + 1, steps.length - 1));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step.type, critical.approved]);

  const goFacematch = () => {
    saveDraft(stepIndex, { ...(appointmentSlot ? { appointmentSlot } : {}), ...(appointmentId ? { appointmentId } : {}) });
    critical.request();
  };

  /* ---------- submit step ---------- */
  React.useEffect(() => {
    if (step.type !== "submit" || submittedRef.current) return;
    submittedRef.current = true;
    setSubmitPhase("sending");
    (async () => {
      await fakeLatency(1200, 2000);
      const reference = makeReference(template.authority, appId);
      const nowIso = DEMO_TODAY.toISOString();
      const app: Application = {
        id: appId,
        procedureId,
        title: template.title,
        status: "submitted",
        createdAt: existingApp?.createdAt ?? nowIso,
        submittedAt: nowIso,
        receivedAt: nowIso,
        reference,
        authority: template.authority,
        data,
        ...(appointmentId ? { appointmentId } : {}),
      };
      dispatch({ type: "UPSERT_APPLICATION", item: app });
      dispatch({
        type: "LOG",
        entry: { type: "submission", title: `Submitted application: ${template.title}`, purpose: template.description, authority: template.authority, actor: "self", level: "critical", channel: "app" },
      });
      if (search.from?.startsWith("entitlement:")) {
        const entId = search.from.slice("entitlement:".length);
        const existing = state.entitlements.find((e) => e.id === entId);
        dispatch({
          type: "UPSERT_ENTITLEMENT",
          item: { id: entId, title: existing?.title ?? template.title, reason: existing?.reason ?? template.description, status: "submitted" },
        });
      }
      setResult({ reference, authority: template.authority });
      setSubmitPhase("done");
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step.type]);

  /* ---------- navigation ---------- */
  const canContinue =
    step.type === "checklist" ? checklistComplete :
    step.type === "fetch" ? fetchComplete :
    step.type === "form" ? formValid :
    step.type === "upload" ? uploadComplete :
    step.type === "choice" ? choiceValid :
    step.type === "appointment" ? appointmentValid :
    true;

  const handleContinue = () => {
    if (step.type === "appointment") confirmAppointment();
    if (step.type === "choice" && paymentModel) setData((prev) => ({ ...prev, paymentModel }));
    if (step.type === "facematch") { goFacematch(); return; }
    setStepIndex((i) => Math.min(i + 1, steps.length - 1));
  };
  const handleBack = () => setStepIndex((i) => Math.max(0, i - 1));

  const queueIds = (search.queue ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const nextTemplate = queueIds[0] ? getTemplate(queueIds[0]) : undefined;

  return (
    <>
      <ScreenHeader title={template.title} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        {step.type !== "submit" && (
          <>
            <RunnerStepper steps={stepNames} current={stepIndex} />
            <div className="flex justify-end">
              <button type="button" onClick={saveAndContinueLater} className="min-h-11 text-sm font-bold text-primary underline">
                Save and continue later
              </button>
            </div>
          </>
        )}

        {step.type === "info" && (
          <div className="space-y-3">
            <Card className="space-y-2">
              <p className="text-foreground">{template.description}</p>
              <p className="text-sm text-muted-foreground">Who can apply: {template.whoCanApply}</p>
              <p className="text-sm text-muted-foreground">Deadline: {template.deadline}</p>
              <p className="text-sm text-muted-foreground">Processing time: {template.processingTime}</p>
              <p className="text-sm text-muted-foreground">Authority: {template.authority}</p>
            </Card>
          </div>
        )}

        {step.type === "checklist" && (
          <div className="space-y-3">
            <p className="text-muted-foreground">What's needed for this application:</p>
            {template.documents.map((doc, i) => {
              const status = docStatus[i]!;
              const srcName = doc.fromRegister ? registerName(userId, doc.fromRegister) : undefined;
              return (
                <Card key={doc.name} variant="surface" className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className={cn("flex size-8 shrink-0 items-center justify-center rounded-full", status !== "pending" ? "bg-success text-primary-foreground" : "bg-surface text-muted-foreground")}>
                      {status !== "pending" ? <Check className="size-4" aria-hidden /> : <Circle className="size-3" aria-hidden />}
                    </span>
                    <div>
                      <p className="font-bold">{doc.name}</p>
                      {status === "auto" && srcName && <p className="text-sm text-success">from {srcName}</p>}
                      {status === "fetched" && srcName && <p className="text-sm text-success">fetched from {srcName}</p>}
                      {status === "uploaded" && <p className="text-sm text-success">uploaded</p>}
                    </div>
                  </div>
                  {status === "pending" && doc.fromRegister && (
                    <Button size="sm" variant="secondary" onClick={() => fetchDocument(i)}>Fetch</Button>
                  )}
                  {status === "pending" && !doc.fromRegister && doc.uploadAllowed && (
                    <Button size="sm" variant="secondary" onClick={() => uploadDocument(i)}>
                      <Upload className="size-4" aria-hidden /> Upload
                    </Button>
                  )}
                </Card>
              );
            })}
          </div>
        )}

        {step.type === "fetch" && (
          <div className="space-y-3">
            <p className="text-muted-foreground">ida can fetch your data from these registers to prefill your application.</p>
            {fetchRegisters.map((r) => {
              const st = fetchStatus[r] ?? "idle";
              const name = registerName(userId, r) ?? r;
              return (
                <Card key={r} variant="surface" className="flex items-center justify-between gap-3">
                  <p className="font-bold">{name}</p>
                  {st === "idle" && <span className="text-sm text-muted-foreground">Not fetched</span>}
                  {st === "loading" && <span className="text-sm text-primary">Fetching…</span>}
                  {st === "done" && (
                    <span className="flex items-center gap-1 text-sm text-success">
                      <Check className="size-4" aria-hidden /> Done
                    </span>
                  )}
                </Card>
              );
            })}
            {fetchRegisters.length > 0 && !fetchComplete && Object.values(fetchStatus).every((s) => s === "idle") && (
              <Button onClick={runFetch}>Fetch securely</Button>
            )}
          </div>
        )}

        {step.type === "form" && (
          <div className="space-y-3">
            {template.formFields.map((f) => {
              const uncertain = !!f.uncertain && !confirmed.has(f.key);
              const value = data[f.key] ?? "";
              const srcLabel = f.source === "user" ? undefined : `from ${registerName(userId, f.source.register) ?? f.source.register}`;
              const editing = editingKey === f.key;
              return (
                <Card key={f.key} variant={uncertain ? "highlighted" : "surface"} className={cn("space-y-2", uncertain && "bg-warning-bg border-warning/40")}>
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-bold">{f.label}{f.required && <span className="text-security"> *</span>}</p>
                    <button type="button" aria-label={`Edit ${f.label}`} onClick={() => setEditingKey(editing ? null : f.key)} className="flex size-9 items-center justify-center rounded-full hover:bg-surface">
                      <Pencil className="size-4 text-primary" aria-hidden />
                    </button>
                  </div>
                  {editing ? (
                    <input
                      autoFocus
                      className="w-full rounded-xl border border-border bg-background px-3 py-2 text-base"
                      value={value}
                      onChange={(e) => setData((prev) => ({ ...prev, [f.key]: e.target.value }))}
                      onBlur={() => setEditingKey(null)}
                    />
                  ) : (
                    <p className="text-foreground">{value || <span className="italic text-muted-foreground">Not filled in</span>}</p>
                  )}
                  {srcLabel && <p className="text-sm text-muted-foreground">{srcLabel}</p>}
                  {uncertain && (
                    <div className="flex items-center justify-between gap-2 pt-1">
                      <p className="flex items-center gap-1 text-sm text-warning"><AlertTriangle className="size-4" aria-hidden /> Please confirm this is correct</p>
                      <Button size="sm" onClick={() => setConfirmed((prev) => new Set(prev).add(f.key))}>Confirm</Button>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}

        {step.type === "upload" && (
          <div className="space-y-3">
            {uploadDocs.length === 0 && <p className="text-muted-foreground">No further documents needed – everything is already covered.</p>}
            {uploadDocs.map(({ d, i }) => {
              const status = docStatus[i]!;
              return (
                <Card key={d.name} variant="surface" className="flex items-center justify-between gap-3">
                  <p className="font-bold">{d.name}</p>
                  {status === "uploaded" ? (
                    <span className="flex items-center gap-1 text-sm text-success"><Check className="size-4" aria-hidden /> Uploaded</span>
                  ) : (
                    <Button size="sm" variant="secondary" onClick={() => uploadDocument(i)}>
                      <Upload className="size-4" aria-hidden /> Upload
                    </Button>
                  )}
                </Card>
              );
            })}
          </div>
        )}

        {step.type === "choice" && (
          <div className="space-y-3">
            {(template.paymentModels ?? []).map((m) => (
              <button key={m.id} type="button" onClick={() => setPaymentModel(m.id)} className="block w-full text-left">
                <Card variant={paymentModel === m.id ? "highlighted" : "surface"} className={cn(paymentModel === m.id && "ring-2 ring-primary")}>
                  <p className="font-bold">{m.title}</p>
                  <p className="text-muted-foreground">{m.text}</p>
                </Card>
              </button>
            ))}
          </div>
        )}

        {step.type === "appointment" && office && (
          <div className="space-y-4">
            <Card variant="surface">
              <p className="font-bold">{office.name}</p>
              <p className="text-sm text-muted-foreground">{office.address}</p>
              <p className="text-sm text-muted-foreground">{office.openingHours}</p>
            </Card>
            {appointmentId ? (
              <Card variant="highlighted" className="space-y-1">
                <p className="font-bold text-success">Appointment booked</p>
                <p>{appointmentSlot && `${fmtDate(appointmentSlot)}, ${fmtTime(appointmentSlot)}`}</p>
              </Card>
            ) : (
              daysWithSlots.map(([day, slots]) => (
                <div key={day}>
                  <p className="mb-2 font-bold">{fmtDate(slots[0]!)}</p>
                  <div className="flex flex-wrap gap-2">
                    {slots.map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setAppointmentSlot(s)}
                        className={cn(
                          "min-h-11 rounded-xl border px-3 text-sm font-semibold",
                          appointmentSlot === s ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface text-foreground hover:bg-accent",
                        )}
                      >
                        {fmtTime(s)}
                      </button>
                    ))}
                  </div>
                </div>
              ))
            )}
            <Card variant="surface" className="space-y-2">
              <p className="font-bold">What to bring</p>
              <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
                {template.documents.map((d) => <li key={d.name}>{d.name}</li>)}
              </ul>
            </Card>
          </div>
        )}

        {step.type === "review" && (
          <div className="space-y-4">
            <Card variant="surface" className="space-y-2">
              <p className="font-bold">Your details</p>
              {template.formFields.map((f) => (
                <div key={f.key} className="flex justify-between gap-3 border-b border-border py-1 last:border-0">
                  <span className="text-muted-foreground">{f.label}</span>
                  <span className="text-right font-semibold">{data[f.key] || "–"}</span>
                </div>
              ))}
              {paymentModel && (
                <div className="flex justify-between gap-3 border-t border-border py-1">
                  <span className="text-muted-foreground">Payment model</span>
                  <span className="text-right font-semibold">{template.paymentModels?.find((m) => m.id === paymentModel)?.title}</span>
                </div>
              )}
            </Card>
            <Card className="space-y-1">
              <p className="font-bold">What happens next</p>
              <p className="text-muted-foreground">{template.whatHappensNext}</p>
            </Card>
            {template.inPersonPart && (
              <Card variant="surface" className="space-y-1">
                <p className="font-bold">In-person part</p>
                <p className="text-muted-foreground">{template.inPersonPart}</p>
                {appointmentSlot && <p className="text-sm text-muted-foreground">Appointment: {fmtDate(appointmentSlot)}, {fmtTime(appointmentSlot)}</p>}
              </Card>
            )}
            <Card variant="surface" className="space-y-1">
              <p className="font-bold">Processing time</p>
              <p className="text-muted-foreground">{template.processingTime}</p>
            </Card>
          </div>
        )}

        {step.type === "facematch" && (
          <Card variant="security" className="space-y-3">
            <p className="flex items-center gap-2 font-bold text-security"><ShieldAlert className="size-5" aria-hidden /> Confirm it's you to submit</p>
            <p className="text-foreground">Submitting this application is a critical action and needs a quick face match.</p>
          </Card>
        )}

        {step.type === "submit" && (
          <div className="flex flex-1 flex-col items-center gap-5 pt-6 text-center">
            {submitPhase !== "done" && (
              <>
                <Clock className="size-14 animate-pulse text-primary" aria-hidden />
                <p className="text-xl font-bold">Sending securely to {template.authority}…</p>
              </>
            )}
            {submitPhase === "done" && result && (
              <div className="w-full space-y-4 text-left">
                <div className="flex flex-col items-center gap-2 text-center">
                  <CheckCircle2 className="size-16 text-success" aria-hidden />
                  <p className="text-xl font-bold">Application submitted</p>
                  <StatusBadge status="in_review">Submitted</StatusBadge>
                </div>
                <Card variant="surface" className="space-y-1 text-center">
                  <p className="text-sm text-muted-foreground">Reference number</p>
                  <p className="text-lg font-bold">{result.reference}</p>
                </Card>
                <p className="text-center text-sm text-muted-foreground">
                  You can withdraw within 24 hours – see{" "}
                  <Link to="/applications/$id" params={{ id: appId }} className="font-bold text-primary underline">application status</Link>.
                </p>
                <Card className="space-y-3">
                  <p className="font-bold">Status</p>
                  <ol className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center gap-2"><Check className="size-4 text-success" aria-hidden /> Submitted</li>
                    <li className="flex items-center gap-2"><Check className="size-4 text-success" aria-hidden /> Received</li>
                    <li className="flex items-center gap-2"><Circle className="size-3" aria-hidden /> In review</li>
                    <li className="flex items-center gap-2"><Circle className="size-3" aria-hidden /> Decision</li>
                  </ol>
                </Card>
                {appointmentSlot && office && (
                  <Card variant="surface" className="space-y-2">
                    <p className="font-bold">Your appointment</p>
                    <p className="text-muted-foreground">{office.name}, {fmtDate(appointmentSlot)}, {fmtTime(appointmentSlot)}</p>
                    <Button
                      variant="secondary"
                      onClick={() => downloadIcs(`${template.title}.ics`, buildIcs(template.title, appointmentSlot, office.address))}
                    >
                      <CalendarPlus className="size-5" aria-hidden /> Add to calendar
                    </Button>
                  </Card>
                )}
                <div className="space-y-2 pt-2">
                  {nextTemplate && (
                    <Button
                      onClick={() =>
                        navigate({
                          to: "/applications/new/$procedureId",
                          params: { procedureId: nextTemplate.id },
                          search: queueIds.length > 1 ? { queue: queueIds.slice(1).join(",") } : {},
                        })
                      }
                    >
                      Next: {nextTemplate.title}
                    </Button>
                  )}
                  <Button variant="secondary" onClick={() => navigate({ to: "/home" })}>
                    <HomeIcon className="size-5" aria-hidden /> Back to home
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {step.type !== "submit" && step.type !== "facematch" && (
          <div className="flex gap-3 pt-2">
            {stepIndex > 0 && <Button variant="ghost" onClick={handleBack}>Back</Button>}
            <Button disabled={!canContinue} onClick={handleContinue}>Continue</Button>
          </div>
        )}
        {step.type === "facematch" && (
          <div className="flex gap-3 pt-2">
            {stepIndex > 0 && <Button variant="ghost" onClick={handleBack}>Back</Button>}
            <Button variant="danger" onClick={handleContinue}>Confirm it's you</Button>
          </div>
        )}
      </main>
    </>
  );
}
