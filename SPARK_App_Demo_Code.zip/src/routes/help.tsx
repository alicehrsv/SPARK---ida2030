import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Phone, MapPin, Send, MessageCircle, CalendarClock, CheckCircle2, Loader2 } from "lucide-react";
import { useApp, currentUser, newId } from "@/context/AppContext";
import { ScreenHeader, toast, IdaAvatar } from "@/components/ida/extras";
import { Button, Card, Chip } from "@/components/ida/core";
import { offices } from "@/data/offices";
import { DEMO_TODAY } from "@/data/config";
import { cn } from "@/lib/utils";

type Search = { topic?: string; from?: string };
export const Route = createFileRoute("/help")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["topic"] === "string" ? { topic: s["topic"] } : {}),
    ...(typeof s["from"] === "string" ? { from: s["from"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Help – ida 2030" },
      { name: "description", content: "Talk to a person, report an error or visit a service point." },
      { property: "og:title", content: "Help – ida 2030" },
      { property: "og:description", content: "Get help from a person." },
    ],
  }),
  component: HelpScreen,
});

type Option = "none" | "callback" | "chat" | "visit";

function slotsFor(day: "today" | "tomorrow") {
  const base = new Date(DEMO_TODAY);
  if (day === "tomorrow") base.setDate(base.getDate() + 1);
  const hours = [9, 10, 11, 13, 14, 15, 16];
  return hours
    .filter((h) => !(day === "today" && h <= DEMO_TODAY.getHours()))
    .map((h) => {
      const d = new Date(base);
      d.setHours(h, 0, 0, 0);
      return d;
    });
}

const SCRIPT = [
  "Hi, this is Sabine from MA 35. I can see the summary ida sent over.",
  "Let me just check the details of your case for a moment.",
  "Thanks for waiting. How can I help you with this today?",
];

function HelpScreen() {
  const { topic, from } = Route.useSearch();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const user = currentUser(state);
  const [text, setText] = useState(topic ?? "");
  const [option, setOption] = useState<Option>("none");

  const previousScreen = useMemo(() => {
    if (from) return from;
    if (typeof document !== "undefined" && document.referrer) {
      try { return new URL(document.referrer).pathname; } catch { /* ignore */ }
    }
    return "unknown";
  }, [from]);

  const openApplications = state.applications.filter((a) => a.status !== "approved" && a.status !== "rejected" && a.status !== "withdrawn");
  const lastChats = state.chat.slice(-3);

  const summary = useMemo(() => {
    const lines = [
      `Caller: ${user.firstName} ${user.lastName}`,
      `Came from: ${previousScreen}`,
      `Open applications: ${openApplications.length ? openApplications.map((a) => a.title).join(", ") : "none"}`,
      lastChats.length ? `Recent chat: ${lastChats.map((m) => `${m.from === "user" ? user.firstName : "ida"}: ${m.text}`).join(" / ")}` : "Recent chat: none",
      topic ? `Topic: ${topic}` : undefined,
    ].filter(Boolean);
    return lines.join("\n");
  }, [user, previousScreen, openApplications, lastChats, topic]);

  const [editedSummary, setEditedSummary] = useState(summary);
  useEffect(() => setEditedSummary(summary), [summary]);

  const logHandover = (purpose: string) => {
    dispatch({ type: "LOG", entry: { type: "handover", title: `Handed over to staff: ${purpose}`, purpose, actor: "self", level: "basic", channel: "app" } });
  };

  return (
    <>
      <ScreenHeader title="Help" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <Link to="/call" search={{ transfer: "1" }} className="flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl bg-ida-gradient font-bold text-primary-foreground shadow-lift">
          <Phone className="size-5" aria-hidden />Talk to a person by phone
        </Link>

        <Card variant="surface">
          <p className="font-bold">This is what the staff member will see</p>
          <textarea
            value={editedSummary}
            onChange={(e) => setEditedSummary(e.target.value)}
            rows={6}
            aria-label="Case summary for the staff member"
            className="mt-2 w-full rounded-2xl border border-input bg-background p-3 text-sm"
          />
        </Card>

        {option === "none" && (
          <div className="space-y-2">
            <Button icon={<CalendarClock className="size-5" aria-hidden />} onClick={() => setOption("callback")}>Call me back</Button>
            <Button variant="secondary" icon={<MessageCircle className="size-5" aria-hidden />} onClick={() => { setOption("chat"); logHandover("Chat with a person"); }}>Chat with a person</Button>
            <Button variant="secondary" icon={<MapPin className="size-5" aria-hidden />} onClick={() => setOption("visit")}>Visit a service point</Button>
          </div>
        )}

        {option === "callback" && <CallbackPanel onBack={() => setOption("none")} logHandover={logHandover} />}
        {option === "chat" && <ChatPanel summary={editedSummary} onBack={() => setOption("none")} />}
        {option === "visit" && <VisitPanel user={user} onBack={() => setOption("none")} logHandover={logHandover} />}

        <Card>
          <label htmlFor="help-msg" className="font-bold">Write to the service team</label>
          <textarea id="help-msg" value={text} onChange={(e) => setText(e.target.value)} rows={4} className="mt-2 w-full rounded-2xl border border-input p-3" />
          <Button className="mt-3" disabled={!text.trim()} icon={<Send className="size-5" aria-hidden />} onClick={() => {
            dispatch({ type: "LOG", entry: { type: "handover", title: "Sent a message to the service team", purpose: text.slice(0, 80), actor: "self", level: "public", channel: "app" } });
            setText(""); toast.success("Message sent (simulated)");
          }}>Send</Button>
        </Card>
      </main>
    </>
  );
}

function CallbackPanel({ onBack, logHandover }: { onBack: () => void; logHandover: (p: string) => void }) {
  const { dispatch } = useApp();
  const [confirmed, setConfirmed] = useState<Date | null>(null);
  const todaySlots = slotsFor("today");
  const tomorrowSlots = slotsFor("tomorrow");

  if (confirmed) {
    return (
      <Card variant="surface" className="space-y-2 text-center">
        <CheckCircle2 className="mx-auto size-8 text-success" aria-hidden />
        <p className="font-bold">We'll call you back</p>
        <p className="text-muted-foreground">{confirmed.toLocaleString("en-GB", { weekday: "long", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" })}</p>
        <Button variant="ghost" size="sm" onClick={onBack}>Done</Button>
      </Card>
    );
  }

  const pick = (d: Date) => {
    dispatch({ type: "LOG", entry: { type: "handover", title: "Booked a call back", purpose: "Call back", actor: "self", level: "basic", channel: "app" } });
    setConfirmed(d);
    toast.success("Call back booked (simulated)");
  };

  return (
    <Card variant="surface" className="space-y-3">
      <p className="font-bold">Pick a time</p>
      {[{ label: "Today", slots: todaySlots }, { label: "Tomorrow", slots: tomorrowSlots }].map((g) => (
        <div key={g.label}>
          <p className="mb-1 text-sm font-semibold text-muted-foreground">{g.label}</p>
          <div className="flex flex-wrap gap-2">
            {g.slots.length === 0 && <p className="text-sm text-muted-foreground">No slots left</p>}
            {g.slots.map((s) => (
              <Chip key={s.toISOString()} onClick={() => pick(s)}>{s.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" })}</Chip>
            ))}
          </div>
        </div>
      ))}
      <Button variant="ghost" size="sm" onClick={onBack}>Back</Button>
    </Card>
  );
}

function ChatPanel({ summary, onBack }: { summary: string; onBack: () => void }) {
  const [lines, setLines] = useState<{ from: "user" | "staff"; text: string }[]>([]);
  const [typing, setTyping] = useState(true);
  const [input, setInput] = useState("");
  const step = useRef(0);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    SCRIPT.forEach((line, i) => {
      timers.push(setTimeout(() => {
        setTyping(true);
        timers.push(setTimeout(() => {
          setLines((l) => [...l, { from: "staff", text: line }]);
          setTyping(i < SCRIPT.length - 1);
        }, 900));
      }, i * 1800 + 300));
    });
    return () => timers.forEach(clearTimeout);
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [lines, typing]);

  const send = () => {
    if (!input.trim()) return;
    setLines((l) => [...l, { from: "user", text: input.trim() }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setLines((l) => [...l, { from: "staff", text: "Got it, thanks – I'll take care of that for you." }]);
      setTyping(false);
    }, 1100);
  };

  return (
    <Card variant="surface" className="space-y-3">
      <div className="flex items-center gap-2">
        <IdaAvatar size={36} />
        <div>
          <p className="font-bold">Sabine, MA 35</p>
          <p className="text-sm text-muted-foreground">Simulated conversation</p>
        </div>
      </div>
      <div className="max-h-72 space-y-2 overflow-y-auto" aria-live="polite">
        {lines.map((l, i) => (
          <p key={i} className={cn("max-w-[85%] rounded-2xl px-3 py-2 text-sm", l.from === "staff" ? "bg-surface" : "ml-auto bg-ida-gradient text-primary-foreground")}>
            {l.text}
          </p>
        ))}
        {typing && <p className="flex items-center gap-1 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" aria-hidden />Sabine is typing…</p>}
        <div ref={endRef} />
      </div>
      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2">
        <label htmlFor="help-chat-input" className="sr-only">Message to Sabine</label>
        <input id="help-chat-input" value={input} onChange={(e) => setInput(e.target.value)} className="min-h-11 min-w-0 flex-1 rounded-full border border-input px-4" placeholder="Type a message…" />
        <button type="submit" aria-label="Send" className="flex size-11 items-center justify-center rounded-full bg-ida-gradient text-primary-foreground"><Send className="size-5" aria-hidden /></button>
      </form>
      <Button variant="ghost" size="sm" onClick={onBack}>End chat</Button>
    </Card>
  );
}

function VisitPanel({ user, onBack, logHandover }: { user: ReturnType<typeof currentUser>; onBack: () => void; logHandover: (p: string) => void }) {
  const navigate = useNavigate();
  const nearest = useMemo(() => {
    const inCity = offices.filter((o) => o.address.includes(user.city));
    const rest = offices.filter((o) => !inCity.includes(o));
    return [...inCity, ...rest].slice(0, 3);
  }, [user.city]);

  return (
    <Card variant="surface" className="space-y-3">
      <p className="font-bold">Nearest service points</p>
      {nearest.map((o) => (
        <div key={o.id} className="rounded-2xl bg-background p-3">
          <p className="font-bold">{o.name}</p>
          <p className="text-sm text-muted-foreground">{o.address}</p>
          <p className="text-sm text-muted-foreground">{o.openingHours}</p>
          <Button
            size="sm"
            className="mt-2"
            onClick={() => {
              logHandover("Visit a service point");
              navigate({ to: "/appointments/book/$officeId", params: { officeId: o.id }, search: { reason: "Other" } });
            }}
          >
            Book appointment
          </Button>
        </div>
      ))}
      <Button variant="ghost" size="sm" onClick={onBack}>Back</Button>
    </Card>
  );
}
