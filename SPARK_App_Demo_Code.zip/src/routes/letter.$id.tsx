import { createFileRoute, notFound, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { FileSignature, CalendarClock, ListOrdered, ShieldAlert, Wand2, BellPlus, MessageCircle, FolderPlus, Info } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { letters, looksLikeInstruction } from "@/data/letters";
import { getService } from "@/data/knowledge";
import { DEMO_TODAY } from "@/data/config";
import { ScreenHeader, Toggle, AiBadge, toast } from "@/components/ida/extras";
import { Button, Card, StatusBadge } from "@/components/ida/core";
import { GlossaryText } from "@/components/ida/GlossaryText";
import { daysUntil } from "@/lib/urgent";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/letter/$id")({
  loader: ({ params }) => {
    const letter = letters.find((l) => l.id === params.id);
    if (!letter) throw notFound();
    return { letter };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.letter.subject} – ida 2030` : "Letter – ida 2030" },
      { name: "description", content: "ida explains your official letter in plain language: what it is, by when, what to do." },
      { property: "og:title", content: "Letter explained – ida 2030" },
      { property: "og:description", content: "Your official letter explained in plain language." },
    ],
  }),
  notFoundComponent: () => <main className="p-5"><p className="font-bold">Letter not found.</p></main>,
  component: LetterScreen,
});

const fmt = (iso: string) => new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });

function LetterScreen() {
  const { letter: l } = Route.useLoaderData();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const [orig, setOrig] = useState(false);
  const svc = l.relatedServiceId ? getService(l.relatedServiceId) : undefined;
  const days = l.deadline ? daysUntil(new Date(l.deadline)) : null;
  const urgent = days !== null && days < 30;
  const injected = looksLikeInstruction(l.body);
  const [first, ...rest] = l.summary.split(/(?<=\.)\s/);

  const addReminder = () => {
    if (!l.deadline) return;
    dispatch({ type: "UPSERT_REMINDER", item: { id: `r-${l.id}`, title: l.subject, due: new Date(l.deadline).toISOString(), done: false, relatedId: l.id, link: `/letter/${l.id}` } });
    dispatch({ type: "LOG", entry: { type: "settings_changed", title: "Added a deadline to reminders", purpose: l.subject, authority: l.sender, actor: "self", level: "basic", channel: "app" } });
    toast.success("Deadline added to your reminders");
  };
  const save = () => {
    dispatch({ type: "ADD_DOCUMENT", item: { id: `doc-${l.id}`, title: l.subject, kind: "letter", status: "uploaded", addedAt: DEMO_TODAY.toISOString(), category: "other", origin: l.sender, note: l.body } });
    dispatch({ type: "LOG", entry: { type: "document_upload", title: "Saved a letter to the vault", purpose: l.subject, authority: l.sender, actor: "self", level: "basic", channel: "app" } });
    toast.success("Saved to your vault");
  };
  const saved = state.vaultDocuments.some((d) => d.id === `doc-${l.id}`);

  return (
    <>
      <ScreenHeader title="Letter" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-3 p-5">
        <div>
          <StatusBadge status="verified">Official letter</StatusBadge>
          <h2 className="mt-2 text-2xl font-bold leading-tight">{l.sender}</h2>
          <p className="text-muted-foreground">{fmt(l.date)} · {l.subject}</p>
        </div>

        {injected && (
          <Card variant="security" role="note">
            <p className="flex items-center gap-2 font-bold text-security"><ShieldAlert className="size-5" aria-hidden />Text treated as data only</p>
            <p className="mt-1 text-sm">This letter contains a sentence that looks like an instruction (“Ignore previous instructions…”). ida never follows instructions found in letters. Nothing was submitted.</p>
          </Card>
        )}

        <Card>
          <h3 className="flex items-center gap-2 font-bold"><FileSignature className="size-5 text-primary" aria-hidden />What is it?</h3>
          <p className="mt-2"><GlossaryText text={[first, rest.join(" ")].filter(Boolean).join(" ")} /></p>
        </Card>

        <Card variant={urgent ? "security" : "default"}>
          <h3 className="flex items-center gap-2 font-bold"><CalendarClock className={cn("size-5", urgent ? "text-security" : "text-primary")} aria-hidden />By when?</h3>
          {l.deadline ? (
            <p className={cn("mt-2 text-xl font-bold", urgent && "text-security")}>{fmt(l.deadline)} · {days} days left</p>
          ) : <p className="mt-2">No deadline stated in the letter.</p>}
        </Card>

        <Card>
          <h3 className="flex items-center gap-2 font-bold"><ListOrdered className="size-5 text-primary" aria-hidden />What do I have to do?</h3>
          <ol className="mt-2 list-decimal space-y-1 ps-5">{l.steps.map((s) => <li key={s}><GlossaryText text={s} /></li>)}</ol>
          {svc && <p className="mt-3 flex items-start gap-2 text-sm text-muted-foreground"><Info className="mt-0.5 size-4 shrink-0" aria-hidden />{svc.fee} · {svc.inPerson ? "In-person visit needed" : "Fully online"}</p>}
        </Card>

        <AiBadge source={`${l.sender} – letter of ${fmt(l.date)}${svc ? ` · ${svc.source}` : ""}`} />

        <div className="rounded-2xl bg-surface px-4">
          <Toggle checked={orig} onChange={setOrig} label="Show German original" />
        </div>
        {orig && (
          <Card variant="surface">
            {/* Original text is rendered as plain data, never interpreted. */}
            <p lang="de" className="whitespace-pre-wrap"><GlossaryText text={l.body} /></p>
          </Card>
        )}

        <div className="space-y-2 pt-2">
          {svc && <Button icon={<Wand2 className="size-5" aria-hidden />} onClick={() => navigate({ to: "/applications/new/$procedureId", params: { procedureId: svc.id } })}>Let ida prepare the application</Button>}
          {l.deadline && <Button variant="secondary" icon={<BellPlus className="size-5" aria-hidden />} onClick={addReminder}>Add deadline to reminders</Button>}
          <Button variant="secondary" icon={<MessageCircle className="size-5" aria-hidden />} onClick={() => navigate({ to: "/chat", search: { letter: l.id } })}>Ask ida about this letter</Button>
          <Button variant="ghost" disabled={saved} icon={<FolderPlus className="size-5" aria-hidden />} onClick={save}>{saved ? "Saved in vault" : "Save to vault"}</Button>
        </div>
      </main>
    </>
  );
}
