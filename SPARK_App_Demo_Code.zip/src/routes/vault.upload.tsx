import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { Camera, FolderOpen, CheckCircle2 } from "lucide-react";
import { useApp, newId, type DocCategory } from "@/context/AppContext";
import { DEMO_TODAY } from "@/data/config";
import { ScreenHeader, toast } from "@/components/ida/extras";
import { Button, Chip } from "@/components/ida/core";
import { fakeLatency } from "@/services/delay";
import { CATEGORY_FILTERS } from "@/lib/registers";

export const Route = createFileRoute("/vault/upload")({
  head: () => ({
    meta: [
      { title: "Upload document – ida 2030" },
      { name: "description", content: "Add a photo or file to your ida vault." },
      { property: "og:title", content: "Upload document – ida 2030" },
      { property: "og:description", content: "Add a document to your vault." },
    ],
  }),
  component: UploadScreen,
});

const cats = CATEGORY_FILTERS.filter((c) => c.id !== "all") as { id: DocCategory; label: string }[];

function UploadScreen() {
  const { dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const camRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<string | null>(null);
  const [cat, setCat] = useState<DocCategory>("identity");
  const [name, setName] = useState("");
  const [expiry, setExpiry] = useState("");
  const [busy, setBusy] = useState(false);

  const pick = (f?: File) => { if (f) { setFile(f.name); if (!name) setName(f.name.replace(/\.[^.]+$/, "")); } };

  const save = async () => {
    setBusy(true);
    await fakeLatency();
    const id = newId();
    dispatch({ type: "ADD_DOCUMENT", item: { id, title: name.trim() || "Document", kind: "uploaded", status: "uploaded", addedAt: DEMO_TODAY.toISOString(), category: cat, origin: "Uploaded by you", ...(file ? { fileName: file } : {}), ...(expiry ? { expiry: new Date(expiry).toISOString() } : {}) } });
    dispatch({ type: "LOG", entry: { type: "document_upload", title: `Uploaded "${name.trim() || "Document"}"`, purpose: "Store in my vault", actor: "self", level: "basic", channel: "app" } });
    toast.success("Saved to your vault");
    navigate({ to: "/vault/document/$id", params: { id } });
  };

  return (
    <>
      <ScreenHeader title="Upload document" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-5 p-5">
        <input ref={camRef} type="file" accept="image/*" capture="environment" className="sr-only" tabIndex={-1} aria-hidden onChange={(e) => pick(e.target.files?.[0])} />
        <input ref={fileRef} type="file" accept="image/*,application/pdf" className="sr-only" tabIndex={-1} aria-hidden onChange={(e) => pick(e.target.files?.[0])} />
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={() => camRef.current?.click()} className="flex min-h-28 flex-col items-center justify-center gap-2 rounded-2xl bg-surface font-bold"><Camera className="size-8 text-primary" aria-hidden />Take photo</button>
          <button type="button" onClick={() => fileRef.current?.click()} className="flex min-h-28 flex-col items-center justify-center gap-2 rounded-2xl bg-surface font-bold"><FolderOpen className="size-8 text-primary" aria-hidden />Choose file</button>
        </div>
        {file && <p className="flex items-center gap-2 font-semibold text-success"><CheckCircle2 className="size-5" aria-hidden />{file}</p>}

        <fieldset>
          <legend className="font-bold">Category</legend>
          <div className="mt-2 flex flex-wrap gap-2">{cats.map((c) => <Chip key={c.id} selected={cat === c.id} onClick={() => setCat(c.id)}>{c.label}</Chip>)}</div>
        </fieldset>
        <div>
          <label htmlFor="doc-name" className="font-bold">Name</label>
          <input id="doc-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Rental contract" className="mt-2 min-h-[52px] w-full rounded-2xl border border-input px-4" />
        </div>
        <div>
          <label htmlFor="doc-exp" className="font-bold">Expiry date <span className="font-normal text-muted-foreground">(optional)</span></label>
          <input id="doc-exp" type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} className="mt-2 min-h-[52px] w-full rounded-2xl border border-input px-4" />
        </div>
        <Button loading={busy} disabled={!file && !name.trim()} onClick={save}>Save to vault</Button>
      </main>
    </>
  );
}
