import { createFileRoute, Link } from "@tanstack/react-router";
import { Globe, ChevronDown, Mail, FileCheck2, Languages, Lock, ArrowRight } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { useT, LANGUAGES } from "@/i18n";
import { PrototypeChip } from "@/components/ida/extras";
import { idaButtonVariants } from "@/components/ida/core";

export const Route = createFileRoute("/welcome")({
  head: () => ({
    meta: [
      { title: "Welcome – ida 2030" },
      { name: "description", content: "ida 2030 – your digital assistant for Austria. Understands letters, does applications with you, speaks your language." },
      { property: "og:title", content: "Welcome – ida 2030" },
      { property: "og:description", content: "Your digital assistant for Austria (prototype, simulated data)." },
    ],
  }),
  component: WelcomeScreen,
});

function WelcomeScreen() {
  const { state, setDemoOpen } = useApp();
  const t = useT();
  const lang = LANGUAGES.find((l) => l.code === state.language)!;
  const taps: number[] = [];
  const onLogo = () => {
    const now = Date.now();
    taps.push(now);
    while (taps.length && now - taps[0]! > 600) taps.shift();
    if (taps.length >= 3) setDemoOpen(true);
  };
  const benefits = [
    { Icon: Mail, text: t("welcome.b1") },
    { Icon: FileCheck2, text: t("welcome.b2") },
    { Icon: Languages, text: t("welcome.b3") },
  ];
  return (
    <main className="flex flex-1 flex-col">
      <div className="relative overflow-hidden bg-welcome px-6 pb-8 pt-4">
        <div className="flex justify-end">
          <Link to="/language" aria-label={`${t("welcome.language")}: ${lang.native}`} className="flex min-h-11 items-center gap-1.5 rounded-full px-3 font-bold hover:bg-surface">
            <Globe className="size-5" aria-hidden /> {lang.short} <ChevronDown className="size-4" aria-hidden />
          </Link>
        </div>
        <button type="button" onClick={onLogo} className="mt-2 block" aria-label="ida">
          <img src="/ida_logo.png" alt="ida logo" width={570} height={370} className="h-24 w-auto" />
        </button>
        <span className="mt-1 block text-xl font-bold text-primary">2030</span>
        <h1 className="mt-5 text-[28px] font-semibold leading-tight">{t("welcome.subtitle")}</h1>
        <p className="mt-3 text-muted-foreground">{t("welcome.lead")}</p>
        <div className="mt-4"><PrototypeChip /></div>
      </div>
      <ul className="space-y-3 px-6">
        {benefits.map(({ Icon, text }) => (
          <li key={text} className="flex items-center gap-3 font-semibold">
            <span className="flex size-10 items-center justify-center rounded-xl bg-surface text-primary" aria-hidden><Icon className="size-5" /></span>
            {text}
          </li>
        ))}
      </ul>
      <div className="mt-auto space-y-3 p-6">
        <Link to="/login" className={idaButtonVariants({ variant: "primary" })}><Lock className="size-5" aria-hidden />{t("welcome.login")}</Link>
        <Link to="/chat" className={idaButtonVariants({ variant: "ghost" })}>{t("welcome.ask")}<ArrowRight className="size-5 rtl:rotate-180" aria-hidden /></Link>
      </div>
    </main>
  );
}
