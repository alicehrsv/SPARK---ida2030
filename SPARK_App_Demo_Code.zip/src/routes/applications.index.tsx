import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FilePlus2, FileStack } from "lucide-react";
import { useApp, type Application, type ApplicationStatus } from "@/context/AppContext";
import { getTemplate } from "@/services/workflows";
import { ScreenHeader, EmptyState } from "@/components/ida/extras";
import { Button, Card, StatusBadge, type BadgeStatus } from "@/components/ida/core";
import { RegisterIcon } from "@/components/ida/RegisterIcon";

export const Route = createFileRoute("/applications/")({
  head: () => ({
    meta: [
      { title: "Applications – ida 2030" },
      { name: "description", content: "Track your applications with official authorities, from draft to decision." },
      { property: "og:title", content: "Applications – ida 2030" },
      { property: "og:description", content: "Your applications in ida 2030." },
    ],
  }),
  component: ApplicationsScreen,
});

type Segment = "progress" | "submitted" | "completed";
const segments: { id: Segment; label: string }[] = [
  { id: "progress", label: "In progress" },
  { id: "submitted", label: "Submitted" },
  { id: "completed", label: "Completed" },
];

const badgeFor: Record<ApplicationStatus, BadgeStatus> = {
  draft: "new", submitted: "in_review", received: "in_review", in_review: "in_review", request: "expiring",
  approved: "approved", rejected: "rejected", withdrawn: "rejected",
};
const labelFor: Record<ApplicationStatus, string> = {
  draft: "Draft", submitted: "Submitted", received: "Received", in_review: "In review", request: "Action needed",
  approved: "Approved", rejected: "Rejected", withdrawn: "Withdrawn",
};

function segmentOf(a: Application): Segment {
  if (a.status === "draft") return "progress";
  if (a.status === "approved" || a.status === "rejected" || a.status === "withdrawn") return "completed";
  return "submitted";
}

function nextStepText(a: Application): string {
  if (a.status === "draft") {
    const t = getTemplate(a.procedureId);
    const idx = a.stepIndex ?? 0;
    const step = t?.steps[idx];
    return step ? `Next: ${step.name}` : "Continue your draft";
  }
  if (a.status === "request") return "Authority needs more documents from you";
  if (a.status === "in_review" || a.status === "received") return "Being reviewed by the authority";
  if (a.status === "submitted") return "Waiting to be received";
  if (a.status === "approved") return "Decision received";
  if (a.status === "rejected") return "Decision received";
  return "Withdrawn";
}

function ApplicationsScreen() {
  const { state, setDemoOpen } = useApp();
  const [seg, setSeg] = useState<Segment>("progress");
  const grouped = useMemo(() => {
    const g: Record<Segment, Application[]> = { progress: [], submitted: [], completed: [] };
    for (const a of state.applications) g[segmentOf(a)].push(a);
    return g;
  }, [state.applications]);
  const list = grouped[seg];

  return (
    <>
      <ScreenHeader title="Applications" back={false} onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <Link to="/applications/catalog">
          <Button icon={<FilePlus2 className="size-5" aria-hidden />}>New application</Button>
        </Link>

        <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1" role="tablist" aria-label="Filter applications">
          {segments.map((s) => (
            <button
              key={s.id}
              type="button"
              role="tab"
              aria-selected={seg === s.id}
              onClick={() => setSeg(s.id)}
              className={`min-h-11 shrink-0 rounded-full px-4 text-sm font-bold ${seg === s.id ? "bg-primary text-primary-foreground" : "bg-surface text-foreground"}`}
            >
              {s.label} ({grouped[s.id].length})
            </button>
          ))}
        </div>

        {list.length === 0 ? (
          <EmptyState
            icon={<FileStack className="size-7" />}
            title={seg === "progress" ? "Nothing in progress" : seg === "submitted" ? "Nothing submitted" : "Nothing completed yet"}
            text="Start a new application from the catalog."
            action={
              <Link to="/applications/catalog">
                <Button size="inline" icon={<FilePlus2 className="size-5" aria-hidden />}>New application</Button>
              </Link>
            }
          />
        ) : (
          <ul className="space-y-2">
            {list.map((a) => {
              const t = getTemplate(a.procedureId);
              const card = (
                <Card className="flex items-start gap-3">
                  <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-surface text-primary">
                    <RegisterIcon name={t?.icon ?? "FileText"} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="block min-w-0 flex-1 truncate font-bold">{a.title}</span>
                      <StatusBadge status={badgeFor[a.status]}>{labelFor[a.status]}</StatusBadge>
                    </span>
                    <span className="mt-1 block text-sm text-muted-foreground">{nextStepText(a)}</span>
                  </span>
                </Card>
              );
              return (
                <li key={a.id}>
                  {a.status === "draft" ? (
                    <Link to="/applications/new/$procedureId" params={{ procedureId: a.procedureId }}>{card}</Link>
                  ) : (
                    <Link to="/applications/$id" params={{ id: a.id }}>{card}</Link>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </main>
    </>
  );
}
