import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { allTemplates, categories, lifeEvents, prefillCount } from "@/services/workflows";
import { ScreenHeader } from "@/components/ida/extras";
import { Card, Chip, SectionTitle } from "@/components/ida/core";
import { RegisterIcon } from "@/components/ida/RegisterIcon";

export const Route = createFileRoute("/applications/catalog")({
  head: () => ({
    meta: [
      { title: "Service catalog – ida 2030" },
      { name: "description", content: "Find a procedure by name, category or life event – also in German, e.g. Meldezettel." },
      { property: "og:title", content: "Service catalog – ida 2030" },
      { property: "og:description", content: "Service catalog in ida 2030." },
    ],
  }),
  component: ServiceCatalogScreen,
});

function ServiceCatalogScreen() {
  const { state, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<"all" | string>("all");

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return allTemplates.filter((t) => {
      if (cat !== "all" && t.category !== cat) return false;
      if (!query) return true;
      return [t.title, t.titleDe, t.authority, t.category].some((s) => s.toLowerCase().includes(query));
    });
  }, [q, cat]);

  return (
    <>
      <ScreenHeader title="Service catalog" onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <label className="relative block">
          <span className="sr-only">Search procedures</span>
          <Search className="absolute start-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search, e.g. Meldezettel"
            className="min-h-[52px] w-full rounded-2xl border border-input bg-surface ps-12 pe-4"
          />
        </label>

        <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1" role="group" aria-label="Category">
          <Chip selected={cat === "all"} onClick={() => setCat("all")} className="shrink-0">All</Chip>
          {categories.map((c) => (
            <Chip key={c} selected={cat === c} onClick={() => setCat(c)} className="shrink-0">{c}</Chip>
          ))}
        </div>

        <SectionTitle>Life events</SectionTitle>
        <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1" role="group" aria-label="Life events">
          {lifeEvents.map((le) => (
            <button
              key={le.id}
              type="button"
              onClick={() => {
                const [first, ...rest] = le.procedureIds;
                if (!first) return;
                navigate({ to: "/applications/new/$procedureId", params: { procedureId: first }, search: rest.length ? { queue: rest.join(",") } : {} });
              }}
              className="shrink-0 rounded-2xl border border-border bg-card px-4 py-3 text-start shadow-soft hover:bg-surface"
            >
              <span className="block font-bold">{le.label}</span>
              <span className="block text-sm text-muted-foreground">{le.procedureIds.length} procedures</span>
            </button>
          ))}
        </div>

        <SectionTitle>Procedures ({filtered.length})</SectionTitle>
        <ul className="space-y-2">
          {filtered.map((t) => {
            const { filled, total } = prefillCount(t, state.currentUserId);
            return (
              <li key={t.id}>
                <Link to="/applications/procedure/$procedureId" params={{ procedureId: t.id }}>
                  <Card className="flex items-start gap-3">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-surface text-primary">
                      <RegisterIcon name={t.icon} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-bold">{t.title}</span>
                      <span className="block text-sm text-muted-foreground">{t.authority}</span>
                      <span className="mt-1 flex flex-wrap items-center gap-2 text-sm">
                        <span className="text-primary font-semibold">ida can pre-fill {filled} of {total} fields</span>
                        {t.inPersonPart && <span className="rounded-full bg-warning-bg px-2 py-0.5 text-xs font-bold text-warning">Partly in person</span>}
                      </span>
                    </span>
                  </Card>
                </Link>
              </li>
            );
          })}
          {filtered.length === 0 && <p className="text-muted-foreground">No procedure matches your search.</p>}
        </ul>
      </main>
    </>
  );
}
