import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Baby, Check, Circle, HandCoins, HeartPulse, FolderLock, Gift } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { ScreenHeader, AiBadge, EmptyState } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";

export const Route = createFileRoute("/life-event/$id")({
  head: () => ({
    meta: [
      { title: "Life event – ida 2030" },
      { name: "description", content: "ida helps you handle everything that comes with a life event, in ida 2030." },
      { property: "og:title", content: "Life event – ida 2030" },
      { property: "og:description", content: "Life event guidance in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: LifeEventScreen,
});

interface Step {
  procedureId: string;
  title: string;
  description: string;
  done: boolean;
  automatic?: boolean;
}

function findField(fields: { label: string; value: string }[] | undefined, label: string): string | undefined {
  return fields?.find((f) => f.label === label)?.value;
}

function parseChildren(value: string | undefined): { name: string; birth: Date }[] {
  if (!value) return [];
  const out: { name: string; birth: Date }[] = [];
  const re = /([A-Za-zÀ-ÿ'’.\- ]+?)\s*\((\d{1,2} \w{3,} \d{4})\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(value))) {
    const d = new Date(m[2]!);
    if (!Number.isNaN(d.getTime())) out.push({ name: m[1]!.trim(), birth: d });
  }
  return out;
}

function LifeEventScreen() {
  const { id } = Route.useParams();
  const { state, dispatch, setDemoOpen } = useApp();
  const navigate = useNavigate();

  if (id !== "birth") {
    return (
      <>
        <ScreenHeader title="Life event" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex-1 space-y-4 p-5">
          <EmptyState icon={<Gift className="size-7" />} title="We don't know this life event yet" text="ida doesn't have a guide for this life event in the prototype." />
        </main>
      </>
    );
  }

  const regs = registersByUser[state.currentUserId] ?? [];
  const byId = (rid: string) => regs.find((r) => r.id === rid);
  const zpr = byId("zpr");
  const social = byId("social");

  const children = parseChildren(findField(zpr?.fields, "Children"));
  const newest = children.length > 0 ? children.reduce((a, b) => (b.birth > a.birth ? b : a)) : undefined;
  const childFirstName = newest?.name.split(" ")[0] ?? "your child";

  const birthApp = state.applications.find((a) => a.procedureId === "birth-registration");
  const birthDone = birthApp?.status != null && birthApp.status !== "draft" && birthApp.status !== "rejected" && birthApp.status !== "withdrawn";

  const childcareApp = state.applications.find((a) => a.procedureId === "childcare-benefit");
  const childcareDone = childcareApp?.status != null && childcareApp.status !== "draft" && childcareApp.status !== "rejected" && childcareApp.status !== "withdrawn";

  const familyAllowanceApp = state.applications.find((a) => a.procedureId === "family-allowance");
  const familyAllowanceDone = familyAllowanceApp?.status != null && familyAllowanceApp.status !== "draft" && familyAllowanceApp.status !== "rejected" && familyAllowanceApp.status !== "withdrawn";

  const coInsured = findField(social?.fields, "Family co-insured") ?? "";
  const socialDone = newest ? coInsured.toLowerCase().includes(newest.name.toLowerCase()) || coInsured.toLowerCase().includes(childFirstName.toLowerCase()) : false;

  const vaultDone = newest ? state.vaultDocuments.some((d) => [d.title, d.note, d.fileName].filter(Boolean).some((t) => t!.toLowerCase().includes(childFirstName.toLowerCase()))) : false;

  const steps: Step[] = [
    { procedureId: "birth-registration", title: "Register birth certificate", description: `Register ${childFirstName}'s birth with the civil registry office.`, done: birthDone },
    { procedureId: "childcare-benefit", title: "Childcare benefit", description: "Apply for monthly childcare benefit payments.", done: childcareDone },
    { procedureId: "family-allowance", title: "Family allowance", description: "Usually paid automatically once the birth is registered.", done: familyAllowanceDone, automatic: true },
    { procedureId: "social-insurance", title: "Add child to social insurance", description: `Co-insure ${childFirstName} with your social insurance.`, done: socialDone },
    { procedureId: "vault-update", title: "Update your vault", description: `Add ${childFirstName}'s documents to your vault.`, done: vaultDone },
  ];

  const applicationSteps = steps.filter((s) => s.procedureId !== "social-insurance" && s.procedureId !== "vault-update");
  const notDone = applicationSteps.filter((s) => !s.done);

  const prepareEverything = () => {
    if (notDone.length === 0) return;
    const [first, ...rest] = notDone;
    dispatch({ type: "LOG", entry: { type: "entitlement_check", title: "Started 'Let ida prepare everything' for birth", purpose: "Handle new child life event", actor: "self", level: "public", channel: "app" } });
    navigate({ to: "/applications/new/$procedureId", params: { procedureId: first!.procedureId }, search: { queue: rest.map((s) => s.procedureId).join(",") } });
  };

  const iconFor = (procedureId: string) => {
    switch (procedureId) {
      case "childcare-benefit": return Baby;
      case "family-allowance": return HandCoins;
      case "social-insurance": return HeartPulse;
      case "vault-update": return FolderLock;
      default: return Gift;
    }
  };

  return (
    <>
      <ScreenHeader title="New child" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <Card variant="highlighted">
          <h2 className="text-xl font-bold">Congratulations on {childFirstName}'s birth!</h2>
          <p className="mt-1 text-muted-foreground">ida gathered the things you may need to take care of – the authorities always make the final decision.</p>
        </Card>

        <div className="space-y-2">
          {steps.map((s) => {
            const Icon = iconFor(s.procedureId);
            return (
              <Card key={s.procedureId} className="flex items-start gap-3">
                <span className={`flex size-11 shrink-0 items-center justify-center rounded-xl ${s.done ? "bg-success-bg text-success" : "bg-surface text-primary"}`} aria-hidden>
                  {s.done ? <Check className="size-5" /> : <Icon className="size-5" />}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="font-bold">{s.title}</p>
                  <p className="text-sm text-muted-foreground">{s.description}</p>
                  {s.automatic && !s.done && <p className="mt-1 text-sm text-muted-foreground">Usually automatic – no action needed, ida just lets you know.</p>}
                </div>
                <span className="shrink-0 pt-1" aria-hidden>{s.done ? <Check className="size-5 text-success" /> : <Circle className="size-5 text-muted-foreground" />}</span>
              </Card>
            );
          })}
        </div>

        <AiBadge source="ida's life-event checklist based on your register data" />

        <div className="pt-2">
          <Button onClick={prepareEverything} disabled={notDone.length === 0}>
            {notDone.length === 0 ? "Everything is done" : "Let ida prepare everything"}
          </Button>
        </div>
      </main>
    </>
  );
}
