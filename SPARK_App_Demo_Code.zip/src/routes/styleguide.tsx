import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FileText, Home as HomeIcon, Lock, ArrowRight, ShieldCheck, Bell } from "lucide-react";
import { Button, Card, StatusBadge, Chip, SectionTitle, ProgressBar, Skeleton, SkeletonCard, type BadgeStatus } from "@/components/ida/core";
import { AiBadge, ListItem, Stepper, Toggle, Sheet, toast, EmptyState, IdaAvatar, ScreenHeader, BottomNav, PrototypeChip } from "@/components/ida/extras";
import { users } from "@/data/users";
import { registersByUser } from "@/data/registers";
import { services, glossary } from "@/data/knowledge";
import { letters } from "@/data/letters";
import { offices } from "@/data/offices";

export const Route = createFileRoute("/styleguide")({
  head: () => ({
    meta: [
      { title: "Styleguide – ida 2030" },
      { name: "description", content: "All ida 2030 base components and mock data overview." },
      { property: "og:title", content: "Styleguide – ida 2030" },
      { property: "og:description", content: "All ida 2030 base components and mock data overview." },
    ],
  }),
  component: Styleguide,
});

const statuses: BadgeStatus[] = ["verified", "uploaded", "new", "in_review", "approved", "rejected", "expiring"];

function Styleguide() {
  const [sheet, setSheet] = useState(false);
  const [on, setOn] = useState(true);
  const [chip, setChip] = useState("en");
  const [speaking, setSpeaking] = useState(true);

  return (
    <>
      <ScreenHeader title="Styleguide" back onHelp={() => toast.info("Talk to a person")} />
      <main className="flex-1 overflow-y-auto px-5 pb-8">
        <div className="mt-4 flex items-center gap-4">
          <IdaAvatar size={64} speaking={speaking} />
          <IdaAvatar size={44} />
          <Button size="sm" variant="ghost" onClick={() => setSpeaking(!speaking)}>{speaking ? "Stop" : "Speak"}</Button>
        </div>
        <div className="mt-3"><PrototypeChip /></div>

        <SectionTitle>Buttons</SectionTitle>
        <div className="space-y-3">
          <Button icon={<Lock className="size-5" aria-hidden />}>Log in with ID Austria</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="ghost">Ask without login <ArrowRight className="size-5" aria-hidden /></Button>
          <Button variant="danger">Withdraw application</Button>
          <Button loading>Loading</Button>
        </div>

        <SectionTitle>Cards</SectionTitle>
        <div className="space-y-3">
          <Card><h3 className="font-bold">Default card</h3><p className="text-muted-foreground">Soft shadow, 16px radius.</p></Card>
          <Card variant="highlighted"><h3 className="font-bold">Highlighted</h3><p className="text-muted-foreground">Gradient border.</p></Card>
          <Card variant="security"><h3 className="flex items-center gap-2 font-bold text-security"><ShieldCheck className="size-5" aria-hidden />Critical action</h3><p>Face match required.</p></Card>
        </div>

        <SectionTitle>Badges & AI</SectionTitle>
        <div className="flex flex-wrap gap-2">{statuses.map((s) => <StatusBadge key={s} status={s} />)}</div>
        <div className="mt-3"><AiBadge source="oesterreich.gv.at – Familienbeihilfe" /></div>

        <SectionTitle>Chips</SectionTitle>
        <div className="flex flex-wrap gap-2">
          {["en", "de", "tr", "ar", "uk", "bcs"].map((l) => <Chip key={l} selected={chip === l} onClick={() => setChip(l)}>{l.toUpperCase()}</Chip>)}
        </div>

        <SectionTitle>List items</SectionTitle>
        <div className="-mx-3">
          <ListItem icon={<FileText className="size-5" />} title="Letter from MA 35" subtitle="1 March 2030" onClick={() => {}} right={<StatusBadge status="new" />} />
          <ListItem icon={<HomeIcon className="size-5" />} title="Residence register" subtitle="Simulated" onClick={() => {}} />
        </div>

        <SectionTitle>Progress & Stepper</SectionTitle>
        <ProgressBar value={60} label="Application" />
        <div className="mt-4"><Stepper steps={["Data", "Documents", "Check", "Submit"]} current={2} /></div>

        <SectionTitle>Toggle</SectionTitle>
        <Toggle checked={on} onChange={setOn} label="Easy Language" description="Shorter sentences" />

        <SectionTitle>Sheet & Toast</SectionTitle>
        <div className="space-y-3">
          <Button variant="secondary" onClick={() => setSheet(true)}>Open bottom sheet</Button>
          <Button variant="ghost" onClick={() => toast.success("Saved to your vault")}>Show toast</Button>
        </div>
        <Sheet open={sheet} onOpenChange={setSheet} title="Consent" description="ida wants to fetch data from the Central Residence Register.">
          <div className="space-y-3"><Button>Allow once</Button><Button variant="secondary">Always allow for this purpose</Button><Button variant="ghost">Decline</Button></div>
        </Sheet>

        <SectionTitle>Empty state & Skeleton</SectionTitle>
        <EmptyState icon={<Bell className="size-7" />} title="No reminders" text="You're all set for now." />
        <div className="mt-3 space-y-3"><SkeletonCard /><Skeleton className="h-12" /></div>

        <SectionTitle>Mock data (simulated)</SectionTitle>
        <Card variant="surface" className="text-sm">
          <p>{users.length} users: {users.map((u) => u.firstName).join(", ")}</p>
          <p>{Object.values(registersByUser).flat().length} register records</p>
          <p>{services.length} services · {glossary.length} glossary terms</p>
          <p>{letters.length} letters · {offices.length} offices</p>
        </Card>
      </main>
      <BottomNav active="/home" />
    </>
  );
}
