import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, CalendarClock, ShieldCheck, Sparkles } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { getTemplate, prefillCount } from "@/services/workflows";
import { getService } from "@/data/knowledge";
import { registersByUser } from "@/data/registers";
import { ScreenHeader, EmptyState } from "@/components/ida/extras";
import { SignLanguageCard } from "@/components/ida/SignLanguageCard";
import { Button, Card, SectionTitle } from "@/components/ida/core";
import { RegisterIcon } from "@/components/ida/RegisterIcon";

export const Route = createFileRoute("/applications/procedure/$procedureId")({
  head: () => ({
    meta: [
      { title: "Procedure – ida 2030" },
      { name: "description", content: "Plain-language information about this procedure before you start with ida." },
      { property: "og:title", content: "Procedure – ida 2030" },
      { property: "og:description", content: "Procedure in ida 2030." },
    ],
  }),
  component: ProcedureScreen,
});

function ProcedureScreen() {
  const { procedureId } = Route.useParams();
  const { state, setDemoOpen } = useApp();
  const navigate = useNavigate();
  const t = getTemplate(procedureId);

  if (!t) {
    return (
      <>
        <ScreenHeader title="Procedure" back onLogoTripleTap={() => setDemoOpen(true)} />
        <main className="flex-1 p-5"><EmptyState title="Procedure not found" text={`Unknown procedure: ${procedureId}`} /></main>
      </>
    );
  }

  const svc = t.knowledgeId ? getService(t.knowledgeId) : undefined;
  const description = svc?.whatItIs ?? t.description;
  const whoCanApply = svc?.whoCanApply ?? t.whoCanApply;
  const documentsNeeded = svc?.documentsNeeded ?? t.documents.map((d) => d.name);
  const fee = svc?.fee;
  const source = svc?.source;
  const regs = registersByUser[state.currentUserId] ?? [];
  const fetchStep = t.steps.find((s) => s.type === "fetch");
  const fetchRegisters = (fetchStep?.registers ?? []).map((id) => regs.find((r) => r.id === id)?.name.en ?? id);
  const { filled, total } = prefillCount(t, state.currentUserId);

  return (
    <>
      <ScreenHeader title={t.title} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <div className="flex items-start gap-3">
          <span className="flex size-14 shrink-0 items-center justify-center rounded-2xl bg-surface text-primary"><RegisterIcon name={t.icon} className="size-7" /></span>
          <div>
            <p lang="de" className="font-semibold text-muted-foreground">{t.titleDe}</p>
            <p className="text-sm">{t.authority}</p>
          </div>
        </div>

        <Card>
          <p>{description}</p>
          <p className="mt-3 text-sm text-muted-foreground"><span className="font-bold text-foreground">Who can apply: </span>{whoCanApply}</p>
          {source && <p className="mt-1 text-sm text-muted-foreground">Source: {source}</p>}
        </Card>

        {fetchRegisters.length > 0 && (
          <Card variant="surface">
            <p className="flex items-center gap-2 font-bold"><Sparkles className="size-5 text-primary" aria-hidden />ida can pre-fill {filled} of {total} fields</p>
            <p className="mt-1 text-sm text-muted-foreground">ida will fetch, with your consent:</p>
            <ul className="mt-2 flex flex-wrap gap-2">
              {fetchRegisters.map((r) => <li key={r} className="rounded-full bg-background px-3 py-1 text-sm font-semibold">{r}</li>)}
            </ul>
          </Card>
        )}

        <SectionTitle>Documents still needed</SectionTitle>
        <ul className="space-y-1">
          {documentsNeeded.map((d) => <li key={d} className="flex items-start gap-2"><ShieldCheck className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden /><span>{d}</span></li>)}
        </ul>

        {state.accessibility.signLanguage && <SignLanguageCard />}

        {t.inPersonPart && (
          <Card variant="surface" className="flex items-start gap-3">
            <CalendarClock className="size-5 shrink-0 text-primary" aria-hidden />
            <div>
              <p className="font-bold">Partly in person</p>
              <p className="text-sm text-muted-foreground">{t.inPersonPart}</p>
            </div>
          </Card>
        )}

        <dl className="grid grid-cols-2 gap-3 text-sm">
          <div><dt className="text-muted-foreground">Deadline</dt><dd className="font-semibold">{t.deadline}</dd></div>
          <div><dt className="text-muted-foreground">Processing time</dt><dd className="font-semibold">{t.processingTime}</dd></div>
          {fee && <div className="col-span-2"><dt className="text-muted-foreground">Fee</dt><dd className="font-semibold">{fee}</dd></div>}
        </dl>

        <Button icon={<ArrowRight className="size-5" aria-hidden />} onClick={() => navigate({ to: "/applications/new/$procedureId", params: { procedureId: t.id } })}>
          Start with ida
        </Button>
      </main>
    </>
  );
}
