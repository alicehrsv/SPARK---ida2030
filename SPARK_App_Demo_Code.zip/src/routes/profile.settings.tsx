import { createFileRoute, Link } from "@tanstack/react-router";
import { Languages, Sparkles } from "lucide-react";
import { useApp } from "@/context/AppContext";
import type { PoaArea } from "@/context/AppContext";
import { LANGUAGES } from "@/i18n";
import { POA_AREAS } from "@/lib/acting";
import { ScreenHeader, Toggle } from "@/components/ida/extras";
import { Card, Chip, SectionTitle } from "@/components/ida/core";

export const Route = createFileRoute("/profile/settings")({
  head: () => ({
    meta: [
      { title: "Settings – ida 2030" },
      { name: "description", content: "Settings in ida 2030, the Austrian digital government assistant prototype." },
      { property: "og:title", content: "Settings – ida 2030" },
      { property: "og:description", content: "Settings in ida 2030, the Austrian digital government assistant prototype." },
    ],
  }),
  component: SettingsScreen,
});

const NOTIFY_TYPES: { id: "deadline" | "entitlement" | "status" | "appointment"; label: string }[] = [
  { id: "deadline", label: "Deadlines" },
  { id: "entitlement", label: "Entitlements" },
  { id: "status", label: "Application status" },
  { id: "appointment", label: "Appointments" },
];

const ENTITLEMENT_REGISTERS = ["ZPR", "ZMR", "Social Insurance", "Tax", "Transparency DB", "Pension", "Education", "Vehicle"];

function SettingsScreen() {
  const { state, dispatch, setDemoOpen } = useApp();

  const logChange = (title: string) => dispatch({ type: "LOG", entry: { type: "settings_changed", title, purpose: "Change settings", actor: "self", level: "basic", channel: "app" } });

  const setNotifyType = (id: (typeof NOTIFY_TYPES)[number]["id"], v: boolean) => {
    dispatch({ type: "SET_SETTINGS", patch: { notifyTypes: { ...state.settings.notifyTypes, [id]: v } } });
    logChange(`Notifications for ${id}: ${v ? "on" : "off"}`);
  };

  const setAutomation = (area: PoaArea, level: "ask" | "prepare") => {
    dispatch({ type: "SET_SETTINGS", patch: { automation: { ...state.settings.automation, [area]: level } } });
    logChange(`Automation for ${area}: ${level}`);
  };

  return (
    <>
      <ScreenHeader title="Settings" back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 space-y-4 p-5">
        <SectionTitle>Language</SectionTitle>
        <div className="flex flex-wrap gap-2">
          {LANGUAGES.map((l) => (
            <Chip key={l.code} selected={state.language === l.code} icon={<Languages className="size-4" aria-hidden />}
              onClick={() => { dispatch({ type: "SET_LANGUAGE", language: l.code }); logChange(`Language: ${l.english}`); }}>
              {l.native}
            </Chip>
          ))}
        </div>
        <Link to="/language" className="text-sm font-semibold text-primary underline underline-offset-2">Open full language screen</Link>

        <Card variant="surface">
          <Toggle checked={state.accessibility.easyLanguage} onChange={(v) => { dispatch({ type: "SET_ACCESSIBILITY", patch: { easyLanguage: v } }); logChange(`Easy language: ${v ? "on" : "off"}`); }}
            label="Easy Language" description="Short sentences, one idea at a time" />
        </Card>

        <SectionTitle>Notifications</SectionTitle>
        <Card variant="surface">
          {NOTIFY_TYPES.map((n) => (
            <Toggle key={n.id} checked={state.settings.notifyTypes?.[n.id] ?? true} onChange={(v) => setNotifyType(n.id, v)} label={n.label} />
          ))}
        </Card>

        <SectionTitle>Entitlement checks</SectionTitle>
        <Card variant="surface">
          <Toggle checked={state.settings.entitlementChecks} onChange={(v) => { dispatch({ type: "SET_SETTINGS", patch: { entitlementChecks: v } }); logChange(`Let ida check my entitlements: ${v ? "on" : "off"}`); }}
            label="Let ida check my entitlements" description="ida compares your data with the rules for benefits and suggests ones you may be entitled to" />
          <p className="mt-2 flex items-start gap-2 text-sm text-muted-foreground"><Sparkles className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
            For this, ida reads: {ENTITLEMENT_REGISTERS.join(", ")}. ida only gives hints – the authority always decides.
          </p>
        </Card>

        <SectionTitle>Automation</SectionTitle>
        <p className="text-sm text-muted-foreground">Choose how much ida may prepare on its own in each area. ida never submits fully automatically – you always confirm before anything is sent.</p>
        {POA_AREAS.map((a) => {
          const level = state.settings.automation?.[a.id] ?? "ask";
          return (
            <Card key={a.id} variant="surface">
              <p className="font-bold">{a.label}</p>
              <div className="mt-2 flex gap-2">
                <Chip selected={level === "ask"} onClick={() => setAutomation(a.id, "ask")}>Ask me every time</Chip>
                <Chip selected={level === "prepare"} onClick={() => setAutomation(a.id, "prepare")}>Prepare, I confirm</Chip>
              </div>
            </Card>
          );
        })}
        <p className="text-sm text-muted-foreground">ida never submits fully automatically.</p>
      </main>
    </>
  );
}
