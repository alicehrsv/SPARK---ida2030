import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { BellRing, CheckCircle2, Fingerprint, QrCode, Smartphone, User, CalendarDays, KeyRound } from "lucide-react";
import { useApp, currentUser } from "@/context/AppContext";
import { useT } from "@/i18n";
import { ScreenHeader, Sheet, toast } from "@/components/ida/extras";
import { Button, Card } from "@/components/ida/core";
import { SimBanner } from "@/components/ida/SimBanner";
import { DEMO_TODAY } from "@/data/config";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in (simulation) – ida 2030" },
      { name: "description", content: "Simulated ID Austria login for the ida 2030 hackathon prototype." },
      { property: "og:title", content: "Log in (simulation) – ida 2030" },
      { property: "og:description", content: "Simulated ID Austria login for the ida 2030 prototype." },
    ],
  }),
  component: LoginScreen,
});

type Step = "start" | "qr" | "waiting" | "transfer" | "success";

function LoginScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const t = useT();
  const navigate = useNavigate();
  const user = currentUser(state);
  const [step, setStep] = useState<Step>("start");
  const [username, setUsername] = useState(`${user.firstName.toLowerCase()}.${user.lastName.toLowerCase()}`);
  const [push, setPush] = useState(false);
  const [phoneOpen, setPhoneOpen] = useState(false);
  const [fingerprint, setFingerprint] = useState(false);
  const [seconds, setSeconds] = useState(120);

  const cancel = () => { setPhoneOpen(false); toast.info(t("common.loginCancelled")); navigate({ to: "/welcome" }); };

  useEffect(() => {
    if (step !== "waiting") return;
    setSeconds(120); setPush(false);
    const p = setTimeout(() => setPush(true), 2000);
    const i = setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => { clearTimeout(p); clearInterval(i); };
  }, [step]);

  useEffect(() => { if (step === "waiting" && seconds === 0) cancel(); }, [seconds]); // eslint-disable-line react-hooks/exhaustive-deps

  const confirmOnPhone = () => {
    setFingerprint(true);
    setTimeout(() => { setFingerprint(false); setPhoneOpen(false); setStep("transfer"); }, 1000);
  };

  const allow = () => {
    dispatch({ type: "LOGIN" });
    dispatch({ type: "LOG", entry: { type: "login", title: "Logged in with ID Austria (simulated)", purpose: "Access to personal services", authority: "ID Austria (simulated)", dataFields: ["Name", "Date of birth", "bPK"], actor: "self", level: "basic", channel: "app" } });
    setStep("success");
    setTimeout(() => navigate({ to: state.deviceVerified ? "/home" : "/device-check" }), 1400);
  };

  const fmt = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
  const dob = new Date(user.birthDate).toLocaleDateString("de-AT");

  return (
    <>
      <ScreenHeader title={t("login.title")} back onBack={cancel} onLogoTripleTap={() => setDemoOpen(true)} />
      <SimBanner />
      <main className="relative flex flex-1 flex-col p-5">
        {push && step === "waiting" && (
          <button type="button" onClick={() => setPhoneOpen(true)}
            className="absolute inset-x-3 top-2 z-20 flex items-center gap-3 rounded-2xl border border-border bg-background p-3 text-start shadow-lift animate-in slide-in-from-top">
            <span className="flex size-10 items-center justify-center rounded-xl bg-ida-gradient text-primary-foreground" aria-hidden><BellRing className="size-5" /></span>
            <span><span className="block text-sm text-muted-foreground">Digital Austria (simulated)</span><span className="block font-bold">{t("login.push")}</span></span>
          </button>
        )}

        {step === "start" && (
          <Card>
            <h2 className="text-2xl font-bold">{t("login.heading")}</h2>
            <p className="mt-2 text-muted-foreground">{t("login.text")}</p>
            <label htmlFor="uname" className="mt-5 block font-bold">{t("login.username")}</label>
            <input id="uname" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="off"
              className="mt-2 min-h-[52px] w-full rounded-2xl border border-input bg-background px-4" />
            <Button className="mt-4" onClick={() => setStep("waiting")}>{t("common.continue")}</Button>
            <p className="my-3 text-center text-sm text-muted-foreground">{t("login.or")}</p>
            <Button variant="secondary" icon={<QrCode className="size-5" aria-hidden />} onClick={() => setStep("qr")}>{t("login.qr")}</Button>
          </Card>
        )}

        {step === "qr" && (
          <Card className="text-center">
            <div role="img" aria-label="Simulated QR code placeholder" className="mx-auto grid size-48 grid-cols-8 gap-1 rounded-2xl bg-surface p-3">
              {Array.from({ length: 64 }, (_, i) => <span key={i} className={(i * 7 + (i >> 3)) % 3 === 0 ? "rounded-sm bg-foreground" : ""} />)}
            </div>
            <p className="mt-4 font-bold">{t("login.scan")}</p>
            <Button className="mt-4" onClick={() => setStep("waiting")}>{t("common.continue")}</Button>
            <Button className="mt-2" variant="ghost" onClick={cancel}>{t("common.cancel")}</Button>
          </Card>
        )}

        {step === "waiting" && (
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <div className="relative flex size-36 items-center justify-center">
              <span className="absolute inset-0 rounded-full bg-ida-gradient animate-ida-speak" aria-hidden />
              <span className="relative flex size-28 items-center justify-center rounded-full bg-background text-primary"><Smartphone className="size-14" aria-hidden /></span>
            </div>
            <p className="mt-6 text-xl font-bold" aria-live="polite">{t("login.waiting")}</p>
            <p className="mt-2 text-3xl font-bold tabular-nums text-primary" aria-label={`Time left ${fmt}`}>{fmt}</p>
            <button type="button" onClick={cancel} className="mt-4 min-h-11 font-bold text-primary underline">{t("common.cancel")}</button>
          </div>
        )}

        {step === "transfer" && (
          <Card variant="highlighted">
            <h2 className="text-xl font-bold">{t("login.receives")}</h2>
            <ul className="mt-4 space-y-3">
              <li className="flex items-center gap-3"><User className="size-5 text-primary" aria-hidden /><span><span className="block text-sm text-muted-foreground">{t("login.name")}</span><span className="font-bold">{user.firstName} {user.lastName}</span></span></li>
              <li className="flex items-center gap-3"><CalendarDays className="size-5 text-primary" aria-hidden /><span><span className="block text-sm text-muted-foreground">{t("login.dob")}</span><span className="font-bold">{dob}</span></span></li>
              <li className="flex items-center gap-3"><KeyRound className="size-5 text-primary" aria-hidden /><span><span className="block text-sm text-muted-foreground">{t("login.bpk")}</span><span className="font-bold">ZP:••••{user.id.toUpperCase().slice(0, 3)}7Q2 (simulated)</span></span></li>
            </ul>
            <Button className="mt-5" onClick={allow}>{t("login.allow")}</Button>
            <Button className="mt-2" variant="ghost" onClick={cancel}>{t("common.cancel")}</Button>
          </Card>
        )}

        {step === "success" && (
          <div className="flex flex-1 flex-col items-center justify-center text-center" role="status">
            <span className="flex size-24 items-center justify-center rounded-full bg-success-bg text-success"><CheckCircle2 className="size-14" aria-hidden /></span>
            <p className="mt-5 text-2xl font-bold">{t("login.success")}</p>
          </div>
        )}
      </main>

      <Sheet open={phoneOpen} onOpenChange={(o) => (o ? setPhoneOpen(true) : cancel())} title="Digital Austria (simulated)">
        <div className="rounded-3xl border-4 border-foreground bg-surface p-5 text-center">
          {fingerprint ? (
            <div className="py-6" role="status">
              <Fingerprint className="mx-auto size-20 animate-pulse text-primary" aria-hidden />
              <p className="mt-3 font-bold">{t("login.fingerprint")}</p>
            </div>
          ) : (
            <>
              <p className="text-xl font-bold">{t("login.wants")}</p>
              <dl className="mt-4 space-y-1 text-start">
                <div className="flex justify-between"><dt className="text-muted-foreground">{t("login.time")}</dt><dd className="font-bold">{DEMO_TODAY.toLocaleTimeString("de-AT", { hour: "2-digit", minute: "2-digit" })}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">{t("login.device")}</dt><dd className="font-bold">Browser · Vienna</dd></div>
              </dl>
              <Button className="mt-5" onClick={confirmOnPhone}>{t("login.confirm")}</Button>
              <Button className="mt-2" variant="ghost" onClick={cancel}>{t("login.decline")}</Button>
            </>
          )}
        </div>
      </Sheet>
    </>
  );
}
