import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Check, Languages } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { useT, LANGUAGES } from "@/i18n";
import { ScreenHeader, Toggle } from "@/components/ida/extras";
import { Button } from "@/components/ida/core";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/language")({
  head: () => ({
    meta: [
      { title: "Language – ida 2030" },
      { name: "description", content: "Choose your language for ida 2030: English, Deutsch, Türkçe, العربية, Українська, BCS." },
      { property: "og:title", content: "Language – ida 2030" },
      { property: "og:description", content: "Choose your language for ida 2030." },
    ],
  }),
  component: LanguageScreen,
});

function LanguageScreen() {
  const { state, dispatch, setDemoOpen } = useApp();
  const t = useT();
  const navigate = useNavigate();
  return (
    <>
      <ScreenHeader title={t("language.title")} back onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex flex-1 flex-col p-5">
        <ul role="radiogroup" aria-label={t("language.title")} className="space-y-2">
          {LANGUAGES.map((l) => {
            const sel = state.language === l.code;
            return (
              <li key={l.code}>
                <button type="button" role="radio" aria-checked={sel} onClick={() => dispatch({ type: "SET_LANGUAGE", language: l.code })}
                  className={cn("flex min-h-14 w-full items-center gap-3 rounded-2xl border px-4 text-start", sel ? "border-ida-gradient" : "border-border")}>
                  <span className="flex size-10 items-center justify-center rounded-xl bg-surface text-primary" aria-hidden><Languages className="size-5" /></span>
                  <span className="flex-1">
                    <span lang={l.code === "bcs" ? "bs" : l.code} className="block font-bold">{l.native}</span>
                    <span className="block text-sm text-muted-foreground">{l.english}</span>
                  </span>
                  {sel && <Check className="size-6 text-primary" aria-hidden />}
                </button>
              </li>
            );
          })}
        </ul>
        <div className="mt-4 rounded-2xl bg-surface px-4">
          <Toggle checked={state.accessibility.easyLanguage} onChange={(v) => dispatch({ type: "SET_ACCESSIBILITY", patch: { easyLanguage: v } })} label={t("language.easy")} description={t("language.easyDesc")} />
        </div>
        <Button className="mt-auto" onClick={() => navigate({ to: "/welcome" })}>{t("common.continue")}</Button>
      </main>
    </>
  );
}
