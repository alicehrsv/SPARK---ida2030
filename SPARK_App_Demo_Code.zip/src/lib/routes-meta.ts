/** Route access rules for the app shell. */
export const PUBLIC_PATHS = ["/welcome", "/language", "/login", "/chat", "/call", "/help", "/styleguide"];
/** A public-mode call can end on its summary, so /call/summary is public too (saving needs login). */
export const TAB_PATHS = ["/home", "/chat", "/vault", "/applications", "/profile"];
export const NO_NAV_PREFIXES = ["/welcome", "/language", "/login", "/device-check", "/onboarding", "/call", "/facematch", "/styleguide"];

const matches = (path: string, base: string) => path === base || path.startsWith(base + "/");

export function isPublicPath(path: string) {
  return PUBLIC_PATHS.some((p) => matches(path, p));
}
export const hidesBottomNav = (path: string) => NO_NAV_PREFIXES.some((p) => matches(path, p));
export const activeTab = (path: string) => TAB_PATHS.find((t) => matches(path, t));

/** Jump targets for the demo menu (dynamic segments filled with sample ids). */
export const DEMO_JUMP_PATHS = [
  "/welcome", "/language", "/login", "/device-check", "/onboarding", "/home", "/notifications",
  "/chat", "/call", "/call/summary", "/scan", "/letter/l-ma35",
  "/vault", "/vault/register/zmr", "/vault/document/doc-1", "/vault/upload",
  "/applications", "/applications/catalog", "/applications/procedure/residence-permit-renewal",
  "/applications/new/residence-permit-renewal", "/applications/app-1",
  "/facematch", "/appointments", "/appointments/book/ma35", "/reminders",
  "/entitlements", "/entitlements/family-allowance", "/entitlements/check/family-allowance", "/life-event/birth",
  "/power-of-attorney", "/power-of-attorney/new",
  "/cockpit", "/help", "/profile", "/profile/personal-data", "/profile/settings", "/profile/accessibility", "/profile/devices",
  "/styleguide",
];
