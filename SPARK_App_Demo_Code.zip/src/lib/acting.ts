import type { AppState, PoaArea } from "@/context/AppContext";

export const POA_AREAS: { id: PoaArea; label: string }[] = [
  { id: "residence", label: "Residence" }, { id: "documents", label: "Documents" }, { id: "family", label: "Family" },
  { id: "money", label: "Money & tax" }, { id: "health", label: "Health" }, { id: "applications", label: "Applications" },
];

/** Register → power-of-attorney area (used to hide data while acting for someone). */
export const REGISTER_AREA: Record<string, PoaArea> = {
  zmr: "residence", foreigners: "residence", vehicle: "residence",
  zpr: "family", iddocs: "documents", citizenship: "documents", driving: "documents", criminal: "documents",
  tax: "money", transparency: "money", pension: "money", social: "health", education: "documents",
};

/** True when not acting for someone, or when the power of attorney covers this area. */
export const areaAllowed = (state: AppState, area: PoaArea | undefined) =>
  !state.actingFor || !area || state.actingFor.areas.includes(area);
