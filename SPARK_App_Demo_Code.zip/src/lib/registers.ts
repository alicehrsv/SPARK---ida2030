import type { RegisterRecord } from "@/types";
import type { DocCategory } from "@/context/AppContext";
import { DEMO_TODAY } from "@/data/config";

export const REGISTER_CATEGORY: Record<string, DocCategory> = {
  zmr: "residence", zpr: "family", citizenship: "identity", iddocs: "identity", driving: "mobility", foreigners: "residence",
  vehicle: "mobility", criminal: "sensitive", tax: "money", social: "work", transparency: "money", pension: "work", education: "education",
};

export const CATEGORY_FILTERS: { id: "all" | DocCategory; label: string }[] = [
  { id: "all", label: "All" }, { id: "identity", label: "Identity" }, { id: "residence", label: "Residence" }, { id: "family", label: "Family" },
  { id: "money", label: "Money & tax" }, { id: "work", label: "Work & social" }, { id: "mobility", label: "Mobility" },
  { id: "education", label: "Education" }, { id: "sensitive", label: "Sensitive" },
];

const DATE_RE = /(\d{1,2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4})/;
const parse = (s: string) => { const m = s.match(DATE_RE); return m ? new Date(`${m[1]} ${m[2]} ${m[3]}`) : null; };

/** Nearest expiry date mentioned in expiry-like fields. */
export function registerExpiry(r: RegisterRecord): Date | null {
  const dates = r.fields
    .filter((f) => /expir/i.test(f.label) || /expires/i.test(f.value))
    .map((f) => parse(f.value.includes("expires") ? f.value.split("expires")[1]! : f.value))
    .filter((d): d is Date => !!d);
  return dates.sort((a, b) => a.getTime() - b.getTime())[0] ?? null;
}

export function registerSummary(r: RegisterRecord): string {
  if (r.sensitivity === "critical") return "Protected – face scan needed to view";
  if (r.id === "iddocs") { const p = r.fields[0]!; const d = p.value.split("expires ")[1]; return d ? `${p.label} valid until ${d}` : p.value; }
  if (r.id === "foreigners") { const t = r.fields.find((f) => f.label === "Title type")?.value; const e = r.fields.find((f) => f.label === "Expiry")?.value; return `${t} valid until ${e}`; }
  const f = r.fields[0]!;
  return `${f.label}: ${f.value}`;
}

export type RegisterStatus = "not_fetched" | "up_to_date" | "expiring";
export function registerStatus(r: RegisterRecord, fetched: boolean): RegisterStatus {
  if (!fetched) return "not_fetched";
  const e = registerExpiry(r);
  if (e && (e.getTime() - DEMO_TODAY.getTime()) / 86_400_000 < 180) return "expiring";
  return "up_to_date";
}

export const isMasked = (v: string) => v.includes("•");
/** Simulated unmasking: replaces the mask with fixed demo digits. */
export const unmask = (v: string) => v.replace(/•+/g, "3907");
