import { describe, expect, it } from "vitest";
import { isYes, isNo, isRepeat, isSlower } from "./callSession";

describe("phone agent voice commands", () => {
  it("understands yes / no in English and German", () => {
    expect(isYes("Yes, correct")).toBe(true);
    expect(isYes("Ja, genau")).toBe(true);
    expect(isNo("Nein")).toBe(true);
  });
  it("understands repeat and slower", () => {
    expect(isRepeat("Can you repeat that?")).toBe(true);
    expect(isSlower("Bitte langsamer")).toBe(true);
  });
});
