import { describe, expect, it } from "vitest";
import { initialState } from "@/context/AppContext";
import { computeUrgentTask } from "./urgent";

describe("most urgent task on Home", () => {
  it("Amira: residence permit expires in 46 days", () => {
    expect(computeUrgentTask(initialState("amira"))?.title).toBe("Residence permit expires in 46 days");
  });
  it("Marcus: register Noah's birth with 2 steps left", () => {
    expect(computeUrgentTask(initialState("marcus"))?.title).toBe("Register Noah's birth – 2 steps left");
  });
  it("Martha: passport expires in 6 months", () => {
    expect(computeUrgentTask(initialState("martha"))?.title).toBe("Your passport expires in 6 months");
  });
});
