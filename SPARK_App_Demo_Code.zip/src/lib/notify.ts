import type { AppNotification, NotificationKind } from "@/context/AppContext";
import { BellRing, CalendarClock, FileWarning, Gift, RefreshCw, ShieldAlert, type LucideIcon } from "lucide-react";
import { DEMO_TODAY } from "@/data/config";

export const kindIcon: Record<NotificationKind, LucideIcon> = {
  deadline: CalendarClock, entitlement: Gift, status: RefreshCw, request: FileWarning, appointment: BellRing, security: ShieldAlert,
};

/** Group notifications relative to the demo date. */
export function groupNotifications(list: AppNotification[], today = DEMO_TODAY) {
  const start = new Date(today); start.setHours(0, 0, 0, 0);
  const week = new Date(start); week.setDate(week.getDate() - 6);
  const sorted = [...list].sort((a, b) => b.date.localeCompare(a.date));
  return [
    { key: "Today", items: sorted.filter((n) => new Date(n.date) >= start) },
    { key: "This week", items: sorted.filter((n) => new Date(n.date) < start && new Date(n.date) >= week) },
    { key: "Earlier", items: sorted.filter((n) => new Date(n.date) < week) },
  ].filter((g) => g.items.length);
}

export const formatTime = (iso: string) =>
  new Date(iso).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Vienna" });
