import { describe, expect, it } from "vitest";
import { isPublicPath } from "./routes-meta";

describe("route guard rules", () => {
  it("allows public routes without login", () => {
    for (const p of ["/welcome", "/language", "/login", "/chat", "/call", "/call/summary", "/help"]) expect(isPublicPath(p)).toBe(true);
  });
  it("requires login for basic routes", () => {
    for (const p of ["/home", "/vault", "/vault/register/zmr", "/cockpit", "/applications/catalog"]) expect(isPublicPath(p)).toBe(false);
  });
});
