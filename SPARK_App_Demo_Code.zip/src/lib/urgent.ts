import type { AppState } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { DEMO_TODAY } from "@/data/config";

export interface UrgentTask { title: string; subtitle: string; link: string }

const DAY = 86_400_000;
const parseDate = (s: string) => {
  const m = s.match(/(\d{1,2}) (\w{3}) (\d{4})/);
  return m ? new Date(`${m[1]} ${m[2]} ${m[3]}`) : null;
};
export const daysUntil = (d: Date, today = DEMO_TODAY) =>
  Math.round((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())) / DAY);

/** Most urgent task: residence title expiry (≤90 d) › draft applications › passport expiry (≤12 months) › nearest reminder. */
export function computeUrgentTask(state: AppState): UrgentTask | null {
  const regs = registersByUser[state.currentUserId] ?? [];
  const foreign = regs.find((r) => r.id === "foreigners")?.fields.find((f) => f.label === "Expiry");
  if (foreign) {
    const d = parseDate(foreign.value);
    const n = d ? daysUntil(d) : 999;
    if (n <= 90) return { title: `Residence permit expires in ${n} days`, subtitle: "Apply for renewal at MA 35 before it expires.", link: "/applications/procedure/residence-permit-renewal" };
  }
  const draft = state.applications.find((a) => a.status === "draft");
  if (draft) return { title: `${draft.title} – ${draft.stepsLeft ?? 1} steps left`, subtitle: "ida already pre-filled the rest for you.", link: `/applications/new/${draft.procedureId}` };
  const pass = regs.find((r) => r.id === "iddocs")?.fields.find((f) => f.label.startsWith("Passport"));
  const pd = pass ? parseDate(pass.value.split("expires ")[1] ?? "") : null;
  if (pd) {
    const n = daysUntil(pd);
    if (n <= 365) {
      const months = Math.round(n / 30.4);
      return { title: months >= 2 ? `Your passport expires in ${months} months` : `Your passport expires in ${n} days`, subtitle: "Renew it in time – ida can book an appointment.", link: "/applications/procedure/passport-renewal" };
    }
  }
  const r = [...state.reminders].filter((x) => !x.done).sort((a, b) => a.due.localeCompare(b.due))[0];
  if (r) return { title: r.title, subtitle: `Due in ${daysUntil(new Date(r.due))} days`, link: r.link ?? "/reminders" };
  return null;
}
