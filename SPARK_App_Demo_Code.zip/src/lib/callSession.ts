/** In-memory phone call session. Survives client navigation (e.g. to /facematch and back), cleared on reload. */
export interface CallLine { who: "ida" | "you"; text: string }
export interface CallAction { label: string; link?: string }
export interface CallSession {
  startedAt: number;
  endedAt?: number;
  lines: CallLine[];
  topics: string[];
  actions: CallAction[];
  nextSteps: string[];
  pending?: { kind: "send"; serviceTitle: string; action: string } | null;
  transferred?: boolean;
  publicMode: boolean;
}

let session: CallSession | null = null;
export const getCall = () => session;
export const startCall = (publicMode: boolean): CallSession => (session = { startedAt: Date.now(), lines: [], topics: [], actions: [], nextSteps: [], publicMode });
export const endCall = () => { if (session) session.endedAt = Date.now(); };
export const clearCall = () => { session = null; };

export const fmtDuration = (ms: number) => {
  const s = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};

const has = (t: string, words: string[]) => words.some((w) => t.includes(w));
export const isYes = (t: string) => has(t.toLowerCase(), ["yes", "yeah", "correct", "right", "ja", "genau", "stimmt", "evet", "نعم", "так", "da", "tačno"]);
export const isNo = (t: string) => has(t.toLowerCase(), ["no", "nope", "nein", "falsch", "hayır", "لا", "ні", "ne"]);
export const isRepeat = (t: string) => has(t.toLowerCase(), ["repeat", "again", "wiederhol", "nochmal", "tekrar", "كرر", "повтор", "ponovi"]);
export const isSlower = (t: string) => has(t.toLowerCase(), ["slower", "slow down", "langsamer", "yavaş", "أبطأ", "повільн", "sporije"]);
export const isPersonal = (t: string) => has(t.toLowerCase(), [" my ", "my ", " mein", "meine", "benim", "моя", "мій", "мого", "moj", "moja", "لي", "change", "ändern", "apply", "beantrag"]);
export const wantsShow = (t: string) => has(t.toLowerCase(), ["show", "screen", "zeig", "bildschirm", "göster", "اعرض", "покаж", "pokaži"]);
export const wantsRead = (t: string) => has(t.toLowerCase(), ["read", "aloud", "vorlesen", "lies", "oku", "اقرأ", "прочитай", "pročitaj"]);
