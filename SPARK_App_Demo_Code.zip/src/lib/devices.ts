import { DEMO_TODAY } from "@/data/config";

export interface SimDevice {
  id: string;
  name: string;
  kind: "phone" | "tablet";
  isThisDevice: boolean;
  lastUsed: string;
}

const at = (days: number, hour = 9, min = 0) => {
  const d = new Date(DEMO_TODAY);
  d.setDate(d.getDate() - days);
  d.setHours(hour, min, 0, 0);
  return d.toISOString();
};

/** Shared simulated device list: used by Profile Devices and Cockpit Devices tab. */
export const devices: SimDevice[] = [
  { id: "this-phone", name: "This phone", kind: "phone", isThisDevice: true, lastUsed: DEMO_TODAY.toISOString() },
  { id: "ipad-sim", name: "iPad (simulated)", kind: "tablet", isThisDevice: false, lastUsed: at(3, 18, 20) },
];
