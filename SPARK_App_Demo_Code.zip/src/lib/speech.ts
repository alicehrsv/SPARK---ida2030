import type { LanguageCode } from "@/types";

export const SPEECH_LANG: Record<LanguageCode, string> = { en: "en-GB", de: "de-AT", tr: "tr-TR", ar: "ar", uk: "uk-UA", bcs: "bs-BA" };

type Rec = { lang: string; interimResults: boolean; continuous: boolean; start(): void; stop(): void; abort(): void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onend: (() => void) | null; onerror: (() => void) | null };

export function getRecognitionCtor(): (new () => Rec) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

/** Listen once; resolves with the final transcript ("" on error). */
export function listenOnce(lang: LanguageCode, onInterim?: (t: string) => void): { promise: Promise<string>; stop: () => void } {
  const Ctor = getRecognitionCtor();
  if (!Ctor) return { promise: Promise.resolve(""), stop: () => {} };
  const r = new Ctor();
  r.lang = SPEECH_LANG[lang]; r.interimResults = true; r.continuous = false;
  let final = "";
  const promise = new Promise<string>((resolve) => {
    r.onresult = (e) => {
      let txt = "";
      for (let i = 0; i < e.results.length; i++) { const res = e.results[i]!; txt += res[0]!.transcript; if (res.isFinal) final = txt; }
      onInterim?.(txt);
    };
    r.onerror = () => resolve(final);
    r.onend = () => resolve(final);
  });
  try { r.start(); } catch { /* already started */ }
  return { promise, stop: () => { try { r.stop(); } catch { /* noop */ } } };
}

export const canSpeak = () => typeof window !== "undefined" && "speechSynthesis" in window;

export function speak(text: string, lang: LanguageCode, rate = 1): Promise<void> {
  if (!canSpeak()) return Promise.resolve();
  return new Promise((resolve) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = SPEECH_LANG[lang]; u.rate = rate;
    u.onend = () => resolve(); u.onerror = () => resolve();
    window.speechSynthesis.speak(u);
    // Safety net when no voice is available (headless browsers)
    setTimeout(resolve, Math.max(1500, text.length * 70 / rate));
  });
}
export const stopSpeaking = () => { if (canSpeak()) window.speechSynthesis.cancel(); };
