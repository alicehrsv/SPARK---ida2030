import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

/* ---------- Button ---------- */
export const idaButtonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-2xl font-bold text-base min-h-[52px] px-5 transition-all disabled:opacity-50 disabled:pointer-events-none active:scale-[0.98]",
  {
    variants: {
      variant: {
        primary: "bg-ida-gradient text-primary-foreground shadow-lift hover:brightness-110",
        secondary: "border-2 border-primary bg-background text-primary hover:bg-surface",
        ghost: "bg-surface text-foreground hover:bg-accent",
        danger: "bg-security text-destructive-foreground hover:brightness-110",
      },
      size: { default: "w-full", inline: "w-auto", sm: "min-h-11 text-sm px-4 w-auto" },
    },
    defaultVariants: { variant: "primary", size: "default" },
  },
);

export interface IdaButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof idaButtonVariants> {
  loading?: boolean;
  icon?: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, IdaButtonProps>(
  ({ className, variant, size, loading, icon, children, ...props }, ref) => (
    <button ref={ref} className={cn(idaButtonVariants({ variant, size }), className)} aria-busy={loading || undefined} {...props}>
      {loading ? <Loader2 className="size-5 animate-spin" aria-hidden /> : icon}
      {children}
    </button>
  ),
);
Button.displayName = "IdaButton";

/* ---------- Card ---------- */
const cardVariants = cva("rounded-2xl p-5 shadow-soft", {
  variants: {
    variant: {
      default: "bg-card border border-border",
      highlighted: "border-ida-gradient",
      security: "bg-security-bg border border-security/30 text-foreground",
      surface: "bg-surface",
    },
  },
  defaultVariants: { variant: "default" },
});
export function Card({
  variant,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof cardVariants>) {
  return <div className={cn(cardVariants({ variant }), className)} {...props} />;
}

/* ---------- Status Badge ---------- */
export type BadgeStatus = "verified" | "uploaded" | "new" | "in_review" | "approved" | "rejected" | "expiring";
const badgeStyles: Record<BadgeStatus, { cls: string; label: string }> = {
  verified: { cls: "bg-success-bg text-success", label: "Verified" },
  uploaded: { cls: "bg-surface text-accent-foreground", label: "Uploaded" },
  new: { cls: "bg-ida-gradient text-primary-foreground", label: "New" },
  in_review: { cls: "bg-warning-bg text-warning", label: "In review" },
  approved: { cls: "bg-success-bg text-success", label: "Approved" },
  rejected: { cls: "bg-security-bg text-security", label: "Rejected" },
  expiring: { cls: "bg-warning-bg text-warning", label: "Expiring" },
};
export function StatusBadge({ status, children, className }: { status: BadgeStatus; children?: React.ReactNode; className?: string }) {
  const s = badgeStyles[status];
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-sm font-bold", s.cls, className)}>
      {children ?? s.label}
    </span>
  );
}

/* ---------- Chip ---------- */
export function Chip({
  selected,
  className,
  icon,
  children,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { selected?: boolean; icon?: React.ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={selected}
      className={cn(
        "inline-flex min-h-11 items-center gap-1.5 rounded-full border px-4 text-sm font-semibold transition-colors",
        selected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-surface text-foreground hover:bg-accent",
        className,
      )}
      {...props}
    >
      {icon}
      {children}
    </button>
  );
}

/* ---------- SectionTitle ---------- */
export function SectionTitle({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="mb-3 mt-6 flex items-center justify-between">
      <h2 className="text-xl font-bold text-foreground">{children}</h2>
      {action}
    </div>
  );
}

/* ---------- ProgressBar ---------- */
export function ProgressBar({ value, label }: { value: number; label: string }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm text-muted-foreground">
        <span>{label}</span>
        <span>{Math.round(value)}%</span>
      </div>
      <div role="progressbar" aria-label={label} aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100} className="h-2.5 overflow-hidden rounded-full bg-surface">
        <div className="h-full rounded-full bg-ida-gradient transition-all" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

/* ---------- Skeleton ---------- */
export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden className={cn("animate-pulse rounded-xl bg-surface", className)} />;
}
export function SkeletonCard() {
  return (
    <div role="status" aria-label="Loading" className="space-y-3 rounded-2xl border border-border p-5">
      <Skeleton className="h-5 w-2/3" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
    </div>
  );
}
