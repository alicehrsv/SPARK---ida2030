import * as React from "react";
import { ShieldCheck } from "lucide-react";
import { useApp, newId } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { DEMO_TODAY } from "@/data/config";
import { fakeLatency } from "@/services/delay";
import { Sheet } from "./extras";
import { Button } from "./core";

export interface ConsentRequest { registers: string[]; purpose: string; selectable?: boolean }
type Resolver = (ids: string[] | null) => void;
const Ctx = React.createContext<((r: ConsentRequest) => Promise<string[] | null>) | null>(null);

/** Opens the consent sheet before ANY register query. Resolves with approved register ids, or null if declined. */
export function useConsent() {
  const fn = React.useContext(Ctx);
  if (!fn) throw new Error("useConsent outside ConsentProvider");
  return fn;
}

export function ConsentProvider({ children }: { children: React.ReactNode }) {
  const { state, dispatch } = useApp();
  const [req, setReq] = React.useState<(ConsentRequest & { resolve: Resolver }) | null>(null);
  const [checked, setChecked] = React.useState<string[]>([]);
  const [busy, setBusy] = React.useState(false);
  const records = (registersByUser[state.currentUserId] ?? []).filter((r) => req?.registers.includes(r.id));

  const request = React.useCallback((r: ConsentRequest) => new Promise<string[] | null>((resolve) => {
    setChecked(r.registers);
    setReq({ ...r, resolve });
  }), []);

  const finish = async (scope: "once" | "always" | null) => {
    if (!req) return;
    if (!scope) {
      dispatch({ type: "LOG", entry: { type: "consent_revoked", title: "Declined a data request", purpose: req.purpose, actor: "self", level: "basic", channel: "app" } });
      req.resolve(null); setReq(null); return;
    }
    setBusy(true);
    await fakeLatency();
    const ids = req.selectable ? checked : req.registers;
    for (const r of records.filter((x) => ids.includes(x.id))) {
      dispatch({ type: "GRANT_CONSENT", item: { id: `${r.id}:${req.purpose}:${scope === "once" ? newId() : "always"}`, register: r.id, purpose: req.purpose, scope, grantedAt: DEMO_TODAY.toISOString() } });
      dispatch({ type: "LOG", entry: { type: "register_query", title: `Fetched data from ${r.name.en}`, purpose: req.purpose, register: r.name.en, dataFields: r.fields.map((f) => f.label), authority: r.authority, actor: "self", level: r.sensitivity === "critical" ? "critical" : "basic", channel: "app" } });
    }
    if (scope === "always") dispatch({ type: "LOG", entry: { type: "consent_granted", title: "Allowed always for this purpose", purpose: req.purpose, dataFields: ids, actor: "self", level: "basic", channel: "app" } });
    dispatch({ type: "MARK_FETCHED", registerIds: ids, at: DEMO_TODAY.toISOString() });
    setBusy(false);
    req.resolve(ids); setReq(null);
  };

  return (
    <Ctx.Provider value={request}>
      {children}
      <Sheet open={!!req} onOpenChange={(o) => !o && !busy && finish(null)} title="ida wants to fetch">
        <p className="font-semibold text-primary">for: {req?.purpose}</p>
        <ul className="mt-4 space-y-3">
          {records.map((r) => (
            <li key={r.id} className="rounded-2xl bg-surface p-4">
              <label className="flex items-start gap-3">
                {req?.selectable && (
                  <input type="checkbox" className="mt-1 size-5 accent-primary" checked={checked.includes(r.id)}
                    onChange={(e) => setChecked((c) => (e.target.checked ? [...c, r.id] : c.filter((x) => x !== r.id)))} />
                )}
                <span>
                  <span className="block font-bold">{r.name.en}</span>
                  <span className="block text-sm text-muted-foreground">{r.authority}</span>
                  <span className="mt-1 block text-sm">{r.fields.map((f) => f.label).join(" · ")}</span>
                </span>
              </label>
            </li>
          ))}
        </ul>
        <p className="mt-4 flex items-start gap-2 text-sm text-muted-foreground"><ShieldCheck className="size-5 shrink-0 text-success" aria-hidden />Only these fields. Nothing is stored outside your vault.</p>
        <div className="mt-4 space-y-2">
          <Button loading={busy} disabled={req?.selectable && checked.length === 0} onClick={() => finish("once")}>Allow once</Button>
          <Button variant="secondary" disabled={busy} onClick={() => finish("always")}>Always for this purpose</Button>
          <Button variant="ghost" disabled={busy} onClick={() => finish(null)}>Decline</Button>
        </div>
      </Sheet>
    </Ctx.Provider>
  );
}
