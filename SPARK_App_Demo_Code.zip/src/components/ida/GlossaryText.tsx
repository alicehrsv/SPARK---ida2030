import * as React from "react";
import { glossary } from "@/data/knowledge";
import { Sheet } from "./extras";

const terms = [...glossary].sort((a, b) => b.term.length - a.term.length);
const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const RE = new RegExp(`(${terms.map((t) => escape(t.term)).join("|")})`, "g");

/** Renders text as plain data; German legal terms are underlined and open a plain-language sheet. */
export function GlossaryText({ text, className }: { text: string; className?: string }) {
  const [open, setOpen] = React.useState<string | null>(null);
  const parts = text.split(RE);
  const entry = open ? glossary.find((g) => g.term === open) : null;
  return (
    <span className={className}>
      {parts.map((p, i) =>
        i % 2 === 1 ? (
          <button key={i} type="button" lang="de" onClick={() => setOpen(p)} className="font-semibold underline decoration-primary decoration-2 underline-offset-2">
            {p}
          </button>
        ) : (
          <React.Fragment key={i}>{p}</React.Fragment>
        ),
      )}
      <Sheet open={!!entry} onOpenChange={(o) => !o && setOpen(null)} title={entry?.term ?? ""}>
        <p className="text-sm font-bold uppercase text-muted-foreground">German term</p>
        <p lang="de" className="text-xl font-bold">{entry?.term}</p>
        <p className="mt-3 text-lg">{entry?.plain}</p>
      </Sheet>
    </span>
  );
}
