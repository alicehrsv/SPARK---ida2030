import * as React from "react";
import { Volume2, VolumeX } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { speak, stopSpeaking, canSpeak } from "@/lib/speech";

/** Button that reads the current <main> content aloud using speechSynthesis. Toggles play/stop. */
export function ReadAloud() {
  const { state } = useApp();
  const [speaking, setSpeaking] = React.useState(false);

  React.useEffect(() => () => stopSpeaking(), []);

  const toggle = () => {
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
      return;
    }
    if (!canSpeak()) return;
    const main = document.querySelector("main");
    const text = (main as HTMLElement | null)?.innerText?.trim() ?? "";
    if (!text) return;
    setSpeaking(true);
    speak(text, state.language, state.accessibility.easyLanguage ? 0.8 : 1).then(() => setSpeaking(false));
  };

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={speaking ? "Stop reading aloud" : "Read aloud"}
      aria-pressed={speaking}
      className="flex size-11 shrink-0 items-center justify-center rounded-full hover:bg-surface"
    >
      {speaking ? <VolumeX className="size-6 text-primary" aria-hidden /> : <Volume2 className="size-6 text-primary" aria-hidden />}
    </button>
  );
}
