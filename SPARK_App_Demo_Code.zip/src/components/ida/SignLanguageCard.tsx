import { Hand } from "lucide-react";
import { Card } from "./core";

/** Placeholder sign-language (ÖGS) video card, shown when the sign-language accessibility setting is on. */
export function SignLanguageCard() {
  return (
    <Card variant="surface">
      <div className="flex aspect-video w-full items-center justify-center rounded-xl bg-foreground/90 text-background">
        <span className="flex flex-col items-center gap-2 text-center text-sm font-semibold">
          <Hand className="size-8" aria-hidden />
          Sign language video (ÖGS) – placeholder
        </span>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">A video interpretation in Austrian Sign Language (ÖGS) would appear here.</p>
    </Card>
  );
}
