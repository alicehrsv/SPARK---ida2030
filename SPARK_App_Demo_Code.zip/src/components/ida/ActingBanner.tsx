import { ArrowLeftRight } from "lucide-react";
import { useRouter } from "@tanstack/react-router";
import { useApp } from "@/context/AppContext";
import { toast } from "./extras";

/** Persistent bar shown on every screen while acting for someone else. */
export function ActingBanner() {
  const { state, dispatch } = useApp();
  const router = useRouter();
  if (!state.actingFor) return null;

  const stop = () => {
    const name = state.actingFor?.name;
    dispatch({ type: "STOP_ACTING" });
    toast.info(`Switched back from acting for ${name}`);
    router.history.push("/profile");
  };

  return (
    <div className="flex items-center justify-between gap-3 bg-ida-gradient px-4 py-2.5 text-primary-foreground">
      <span className="min-w-0 truncate text-sm font-bold">You are acting for {state.actingFor.name}</span>
      <button type="button" onClick={stop} className="flex min-h-9 shrink-0 items-center gap-1.5 rounded-full bg-background/20 px-3 text-sm font-bold hover:bg-background/30">
        <ArrowLeftRight className="size-4" aria-hidden />Switch back
      </button>
    </div>
  );
}
