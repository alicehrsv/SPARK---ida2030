import * as React from "react";
import { useLocation, useRouter } from "@tanstack/react-router";
import { RotateCcw, Play, Wifi, BellRing } from "lucide-react";
import { useApp, type AppNotification } from "@/context/AppContext";
import { DEMO_TODAY } from "@/data/config";
import { setSlowNetwork } from "@/services/delay";
import { ConsentProvider } from "./ConsentSheet";
import { users } from "@/data/users";
import { activeTab, DEMO_JUMP_PATHS, hidesBottomNav, isPublicPath } from "@/lib/routes-meta";
import { PhoneFrame, BottomNav, Sheet, Toggle, toast, PrototypeChip } from "./extras";
import { Button, Chip, SectionTitle } from "./core";
import { ActingBanner } from "./ActingBanner";

export function AppShell({ children }: { children: React.ReactNode }) {
  const { state, dispatch, hydrated } = useApp();
  const { pathname } = useLocation();
  const router = useRouter();

  React.useEffect(() => {
    document.documentElement.lang = state.language === "bcs" ? "bs" : state.language;
    document.documentElement.dir = state.language === "ar" ? "rtl" : "ltr";
  }, [state.language]);

  React.useEffect(() => { setSlowNetwork(state.slowNetwork); }, [state.slowNetwork]);

  // Apply accessibility settings app-wide, immediately.
  React.useEffect(() => {
    const a = state.accessibility;
    const scale = a.textScale ?? (a.largeText ? 1.25 : 1);
    document.documentElement.style.fontSize = `${100 * scale}%`;
    document.documentElement.classList.toggle("a11y-contrast", !!a.highContrast);
    document.documentElement.classList.toggle("a11y-bold", !!a.boldText);
    document.documentElement.classList.toggle("a11y-reduce-motion", !!a.reducedMotion);
  }, [state.accessibility]);

  // A critical approval is valid for one action only: it expires as soon as the user leaves that screen.
  React.useEffect(() => {
    const a = state.criticalApproval;
    if (a && pathname !== a.path && pathname !== "/facematch") dispatch({ type: "CONSUME_CRITICAL" });
  }, [pathname]); // eslint-disable-line react-hooks/exhaustive-deps

  const blocked = hydrated && !state.isLoggedIn && !isPublicPath(pathname);
  React.useEffect(() => {
    if (blocked) router.navigate({ to: "/login", replace: true });
  }, [blocked, router]);

  return (
    <PhoneFrame>
      <ConsentProvider>
      {!blocked && <ActingBanner />}
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">{blocked ? null : children}</div>
      {!hidesBottomNav(pathname) && <BottomNav active={activeTab(pathname)} />}
      <PushBanner />
      <DemoMenu />
      </ConsentProvider>
    </PhoneFrame>
  );
}

function PushBanner() {
  const { state } = useApp();
  const router = useRouter();
  const seen = React.useRef<Set<string> | null>(null);
  const [shown, setShown] = React.useState<AppNotification | null>(null);
  React.useEffect(() => {
    const ids = new Set(state.notifications.map((n) => n.id));
    if (seen.current) {
      const fresh = state.notifications.find((n) => !seen.current!.has(n.id));
      if (fresh) setShown(fresh);
    }
    seen.current = ids;
  }, [state.notifications]);
  React.useEffect(() => {
    if (!shown) return;
    const t = setTimeout(() => setShown(null), 5000);
    return () => clearTimeout(t);
  }, [shown]);
  if (!shown) return null;
  return (
    <button type="button" role="status" onClick={() => { setShown(null); router.history.push(shown.link ?? "/notifications"); }}
      className="absolute inset-x-3 top-3 z-40 flex items-center gap-3 rounded-2xl border border-border bg-background p-3 text-start shadow-lift animate-in slide-in-from-top">
      <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-ida-gradient text-primary-foreground" aria-hidden><BellRing className="size-5" /></span>
      <span className="min-w-0"><span className="block text-sm text-muted-foreground">ida 2030 · now</span><span className="block font-bold">{shown.title}</span><span className="block truncate text-sm">{shown.body}</span></span>
    </button>
  );
}

function DemoMenu() {
  const { state, dispatch, demoOpen, setDemoOpen } = useApp();
  const router = useRouter();
  const go = (path: string) => { setDemoOpen(false); router.history.push(path); };

  return (
    <Sheet open={demoOpen} onOpenChange={setDemoOpen} title="Demo menu" description="Hidden tools for the jury demo.">
      <PrototypeChip />
      <Button className="mt-4" icon={<Play className="size-5" aria-hidden />} onClick={() => { setDemoOpen(false); toast.info("Jury demo – coming soon"); }}>
        Start jury demo
      </Button>

      <SectionTitle>Demo user</SectionTitle>
      <div className="flex flex-wrap gap-2">
        {users.map((u) => (
          <Chip key={u.id} selected={state.currentUserId === u.id} onClick={() => { dispatch({ type: "SWITCH_USER", userId: u.id }); toast.success(`Switched to ${u.firstName} ${u.lastName}`); }}>
            {u.firstName} {u.lastName}
          </Chip>
        ))}
      </div>

      <Button className="mt-3" variant="secondary" icon={<BellRing className="size-5" aria-hidden />} onClick={() => {
        setDemoOpen(false);
        setTimeout(() => dispatch({ type: "ADD_NOTIFICATION", item: { id: `n-test-${Date.now()}`, kind: "status", title: "Status update", body: "Your application is now in review (test)", date: DEMO_TODAY.toISOString(), read: false, link: "/notifications" } }), 300);
      }}>Send test notification</Button>

      <SectionTitle>Network</SectionTitle>
      <Toggle checked={state.slowNetwork} onChange={(v) => dispatch({ type: "SET_SLOW_NETWORK", value: v })} label="Slow network" description="Adds extra delay to all simulated services" />
      <span className="sr-only"><Wifi aria-hidden /></span>
      <Toggle checked={state.demoFaceFail} onChange={(v) => dispatch({ type: "SET_FACE_FAIL", value: v })} label="Simulate face match failure" description="The next face scans fail until you switch this off" />

      <SectionTitle>Jump to screen</SectionTitle>
      <div className="grid max-h-64 grid-cols-1 gap-1 overflow-y-auto rounded-2xl bg-surface p-2">
        {DEMO_JUMP_PATHS.map((p) => (
          <button key={p} type="button" onClick={() => go(p)} className="min-h-11 rounded-xl px-3 text-left text-sm font-semibold hover:bg-background">{p}</button>
        ))}
      </div>

      <Button className="mt-5" variant="danger" icon={<RotateCcw className="size-5" aria-hidden />} onClick={() => { dispatch({ type: "RESET" }); setDemoOpen(false); router.history.push("/welcome"); toast.success("All demo data reset"); }}>
        Reset all data
      </Button>
    </Sheet>
  );
}
