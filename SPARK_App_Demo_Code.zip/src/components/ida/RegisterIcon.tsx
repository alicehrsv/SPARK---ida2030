import { icons, FileText } from "lucide-react";

export function RegisterIcon({ name, className }: { name: string; className?: string }) {
  const Icon = (icons as Record<string, typeof FileText>)[name] ?? FileText;
  return <Icon className={className ?? "size-5"} aria-hidden />;
}
