import { AlertTriangle } from "lucide-react";
import { useT } from "@/i18n";

export function SimBanner() {
  const t = useT();
  return (
    <div role="note" className="flex items-start gap-2 bg-warning-bg px-4 py-3 text-sm font-bold text-warning">
      <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
      {t("login.banner")}
    </div>
  );
}
