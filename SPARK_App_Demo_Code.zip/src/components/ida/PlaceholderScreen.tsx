import { Construction } from "lucide-react";
import { useApp } from "@/context/AppContext";
import { ScreenHeader, EmptyState } from "./extras";

export function PlaceholderScreen({ title, back = true, detail }: { title: string; back?: boolean; detail?: string }) {
  const { setDemoOpen } = useApp();
  return (
    <>
      <ScreenHeader title={title} back={back} onLogoTripleTap={() => setDemoOpen(true)} />
      <main className="flex-1 p-5">
        <EmptyState icon={<Construction className="size-7" />} title={title} text={detail ?? "This screen is coming soon."} />
      </main>
    </>
  );
}
