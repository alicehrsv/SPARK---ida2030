import * as React from "react";
import type { ActivityEntry, LanguageCode } from "@/types";
import { defaultUser, users } from "@/data/users";
import { DEMO_TODAY } from "@/data/config";
import { seedFor } from "@/data/seed";

export interface Accessibility { largeText: boolean; readAloud: boolean; easyLanguage: boolean; highContrast: boolean; reducedMotion: boolean; textScale?: number; boldText?: boolean; signLanguage?: boolean }
export interface Consent { id: string; register: string; purpose: string; scope: "once" | "always"; grantedAt: string }
export type DocCategory = "identity" | "residence" | "family" | "money" | "work" | "mobility" | "education" | "sensitive" | "other";
export interface VaultDocument { id: string; title: string; kind: "register" | "uploaded" | "letter" | "call"; status: "verified" | "uploaded"; addedAt: string; category?: DocCategory; expiry?: string; origin?: string; fileName?: string; note?: string }
export interface ChatAction { kind: "start_application" | "fetch_data" | "book_appointment" | "talk_to_person" | "scan_letter"; serviceId?: string }
export interface ChatMessage { id: string; from: "user" | "ida"; text: string; language: LanguageCode; at: string; spec?: import("@/services/ai").AnswerSpec }
export type ApplicationStatus = "draft" | "submitted" | "received" | "in_review" | "request" | "approved" | "rejected" | "withdrawn";
export interface AuthorityRequest { text: string; document: string; due: string; fetchRegister?: string; answeredAt?: string; via?: "register" | "upload" }
export interface Application {
  id: string; procedureId: string; title: string; stepsLeft?: number; status: ApplicationStatus; createdAt: string;
  /** Saved runner position for "Save and continue later". */
  stepIndex?: number;
  submittedAt?: string; receivedAt?: string; reviewAt?: string; decidedAt?: string;
  reference?: string; authority?: string; appointmentId?: string;
  request?: AuthorityRequest;
  decisionText?: string;
  data?: Record<string, string>;
}
export interface Appointment { id: string; officeId: string; slot: string; purpose: string; checklist?: string[]; applicationId?: string }
export type ReminderKind = "deadline" | "document" | "appointment";
export interface Reminder { id: string; title: string; due: string; done: boolean; relatedId?: string; link?: string; kind?: ReminderKind; source?: string; enabled?: boolean; repeat?: "none" | "monthly" | "yearly"; procedureId?: string }
export type EntitlementStatus = "new" | "started" | "submitted" | "approved" | "not_eligible" | "hidden";
export interface Entitlement { id: string; title: string; status: EntitlementStatus; reason: string }
export type PoaArea = "residence" | "documents" | "family" | "money" | "health" | "applications";
export type PoaRight = "view" | "prepare" | "submit";
export interface PowerOfAttorney {
  id: string; name: string; relationship: string; areas: { area: PoaArea; right: PoaRight }[]; validUntil: string;
  status: "active" | "pending" | "revoked"; direction: "granted" | "received";
  /** Demo user id of the other person, if they are a demo user (enables "Switch to …"). */
  personUserId?: string;
}
/** Set while the logged-in user acts for someone else; the proxy's own state is parked in `ownState`. */
export interface ActingFor { userId: string; name: string; proxyName: string; areas: PoaArea[]; ownState: Omit<AppState, "actingFor"> }
export type NotificationKind = "deadline" | "entitlement" | "status" | "request" | "appointment" | "security";
export interface AppNotification { id: string; kind: NotificationKind; title: string; body: string; date: string; read: boolean; link?: string }
export interface Settings {
  entitlementChecks: boolean; notifications: boolean;
  /** Notification types the user wants (missing = on). */
  notifyTypes?: Partial<Record<"deadline" | "entitlement" | "status" | "appointment", boolean>>;
  /** Automation per area – never fully automatic submit. */
  automation?: Partial<Record<PoaArea, "ask" | "prepare">>;
  /** Device ids logged out or locked remotely in the Data Cockpit. */
  deviceStatus?: Record<string, "logged_out" | "locked">;
}

export interface AppState {
  currentUserId: string;
  isLoggedIn: boolean;
  language: LanguageCode;
  accessibility: Accessibility;
  consents: Consent[];
  vaultDocuments: VaultDocument[];
  applications: Application[];
  appointments: Appointment[];
  reminders: Reminder[];
  entitlements: Entitlement[];
  powersOfAttorney: PowerOfAttorney[];
  activityLog: ActivityEntry[];
  notifications: AppNotification[];
  deviceVerified: boolean;
  slowNetwork: boolean;
  settings: Settings;
  chat: ChatMessage[];
  fetchedRegisters: Record<string, string>;
  criticalApproval: { action: string; at: string; path: string } | null;
  actingFor: ActingFor | null;
  /** Demo menu: next face match fails. */
  demoFaceFail: boolean;
}

export function initialState(userId: string = defaultUser.id): AppState {
  const u = users.find((x) => x.id === userId) ?? defaultUser;
  return {
    currentUserId: u.id,
    isLoggedIn: false,
    language: u.preferredLanguage,
    accessibility: { largeText: u.preferences.largeText, readAloud: u.preferences.readAloud, easyLanguage: u.preferences.easyLanguage, highContrast: false, reducedMotion: false },
    consents: [], vaultDocuments: [], deviceVerified: false, slowNetwork: false,
    chat: [], fetchedRegisters: {}, criticalApproval: null, actingFor: null, demoFaceFail: false,
    ...seedFor(u.id),
  };
}

type Upsert<K extends string, T> = { type: K; item: T };
export type Action =
  | { type: "HYDRATE"; state: AppState }
  | { type: "RESET" }
  | { type: "SWITCH_USER"; userId: string }
  | { type: "LOGIN" }
  | { type: "LOGOUT" }
  | { type: "SET_LANGUAGE"; language: LanguageCode }
  | { type: "SET_ACCESSIBILITY"; patch: Partial<Accessibility> }
  | Upsert<"GRANT_CONSENT", Consent>
  | { type: "REVOKE_CONSENT"; id: string }
  | Upsert<"ADD_DOCUMENT", VaultDocument>
  | Upsert<"UPSERT_APPLICATION", Application>
  | Upsert<"ADD_APPOINTMENT", Appointment>
  | { type: "CANCEL_APPOINTMENT"; id: string }
  | Upsert<"UPSERT_REMINDER", Reminder>
  | Upsert<"UPSERT_ENTITLEMENT", Entitlement>
  | Upsert<"ADD_POWER_OF_ATTORNEY", PowerOfAttorney>
  | { type: "REVOKE_POWER_OF_ATTORNEY"; id: string }
  | { type: "LOG"; entry: Omit<ActivityEntry, "id" | "timestamp"> & Partial<Pick<ActivityEntry, "id" | "timestamp">> }
  | Upsert<"ADD_NOTIFICATION", AppNotification>
  | { type: "READ_NOTIFICATION"; id: string }
  | { type: "SET_DEVICE_VERIFIED"; value: boolean }
  | { type: "SET_SLOW_NETWORK"; value: boolean }
  | { type: "SET_SETTINGS"; patch: Partial<Settings> }
  | { type: "READ_ALL_NOTIFICATIONS" }
  | { type: "ADD_CHAT"; message: ChatMessage }
  | { type: "CLEAR_CHAT" }
  | { type: "MARK_FETCHED"; registerIds: string[]; at: string }
  | { type: "APPROVE_CRITICAL"; action: string; path: string }
  | { type: "CONSUME_CRITICAL" }
  | { type: "DELETE_DOCUMENT"; id: string }
  | { type: "DELETE_REMINDER"; id: string }
  | { type: "ACT_FOR"; userId: string; name: string; areas: PoaArea[] }
  | { type: "STOP_ACTING" }
  | { type: "SET_FACE_FAIL"; value: boolean };

const upsert = <T extends { id: string }>(list: T[], item: T) =>
  list.some((x) => x.id === item.id) ? list.map((x) => (x.id === item.id ? item : x)) : [item, ...list];

let seq = 0;
export const newId = () => `${Date.now().toString(36)}-${(seq++).toString(36)}`;

export function reducer(state: AppState, a: Action): AppState {
  switch (a.type) {
    case "HYDRATE": return a.state;
    case "RESET": return initialState();
    case "SWITCH_USER": return { ...initialState(a.userId), slowNetwork: state.slowNetwork };
    case "LOGIN": return { ...state, isLoggedIn: true };
    case "LOGOUT": return { ...state, isLoggedIn: false };
    case "SET_LANGUAGE": return { ...state, language: a.language };
    case "SET_ACCESSIBILITY": return { ...state, accessibility: { ...state.accessibility, ...a.patch } };
    case "GRANT_CONSENT": return { ...state, consents: upsert(state.consents, a.item) };
    case "REVOKE_CONSENT": return { ...state, consents: state.consents.filter((c) => c.id !== a.id) };
    case "ADD_DOCUMENT": return { ...state, vaultDocuments: upsert(state.vaultDocuments, a.item) };
    case "UPSERT_APPLICATION": return { ...state, applications: upsert(state.applications, a.item) };
    case "ADD_APPOINTMENT": return { ...state, appointments: upsert(state.appointments, a.item) };
    case "CANCEL_APPOINTMENT": return { ...state, appointments: state.appointments.filter((x) => x.id !== a.id) };
    case "UPSERT_REMINDER": return { ...state, reminders: upsert(state.reminders, a.item) };
    case "UPSERT_ENTITLEMENT": return { ...state, entitlements: upsert(state.entitlements, a.item) };
    case "ADD_POWER_OF_ATTORNEY": return { ...state, powersOfAttorney: upsert(state.powersOfAttorney, a.item) };
    case "REVOKE_POWER_OF_ATTORNEY": return { ...state, powersOfAttorney: state.powersOfAttorney.map((x) => (x.id === a.id ? { ...x, status: "revoked" as const } : x)) };
    case "LOG": return { ...state, activityLog: [{ id: a.entry.id ?? newId(), timestamp: a.entry.timestamp ?? DEMO_TODAY.toISOString(), ...a.entry, ...(state.actingFor ? { actor: state.actingFor.proxyName } : {}) } as ActivityEntry, ...state.activityLog] };
    case "ADD_NOTIFICATION": return { ...state, notifications: upsert(state.notifications, a.item) };
    case "READ_NOTIFICATION": return { ...state, notifications: state.notifications.map((n) => (n.id === a.id ? { ...n, read: true } : n)) };
    case "SET_DEVICE_VERIFIED": return { ...state, deviceVerified: a.value };
    case "SET_SLOW_NETWORK": return { ...state, slowNetwork: a.value };
    case "SET_SETTINGS": return { ...state, settings: { ...state.settings, ...a.patch } };
    case "ADD_CHAT": return { ...state, chat: [...state.chat, a.message] };
    case "CLEAR_CHAT": return { ...state, chat: [] };
    case "MARK_FETCHED": return { ...state, fetchedRegisters: { ...state.fetchedRegisters, ...Object.fromEntries(a.registerIds.map((id) => [id, a.at])) } };
    case "APPROVE_CRITICAL": return { ...state, criticalApproval: { action: a.action, at: new Date().toISOString(), path: a.path } };
    case "CONSUME_CRITICAL": return { ...state, criticalApproval: null };
    case "DELETE_DOCUMENT": return { ...state, vaultDocuments: state.vaultDocuments.filter((d) => d.id !== a.id) };
    case "DELETE_REMINDER": return { ...state, reminders: state.reminders.filter((r) => r.id !== a.id) };
    case "ACT_FOR": {
      if (state.actingFor) return state;
      const { actingFor: _ignored, ...ownState } = state;
      const proxy = currentUser(state);
      const other = initialState(a.userId);
      return { ...other, isLoggedIn: true, deviceVerified: true, language: state.language, accessibility: state.accessibility, slowNetwork: state.slowNetwork,
        actingFor: { userId: a.userId, name: a.name, proxyName: `${proxy.firstName} ${proxy.lastName}`, areas: a.areas, ownState } };
    }
    case "STOP_ACTING": return state.actingFor ? { ...state.actingFor.ownState, actingFor: null } : state;
    case "SET_FACE_FAIL": return { ...state, demoFaceFail: a.value };
    case "READ_ALL_NOTIFICATIONS": return { ...state, notifications: state.notifications.map((n) => ({ ...n, read: true })) };
  }
}

const STORAGE_KEY = "ida2030-state-v4";

interface Ctx { state: AppState; dispatch: React.Dispatch<Action>; hydrated: boolean; demoOpen: boolean; setDemoOpen: (o: boolean) => void }
const AppContext = React.createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = React.useReducer(reducer, undefined, () => initialState());
  const [hydrated, setHydrated] = React.useState(false);
  const [demoOpen, setDemoOpen] = React.useState(false);

  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) dispatch({ type: "HYDRATE", state: { ...initialState(), ...JSON.parse(raw) } });
    } catch { /* ignore corrupt storage */ }
    setHydrated(true);
  }, []);

  React.useEffect(() => {
    if (hydrated) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state, hydrated]);

  const value = React.useMemo(() => ({ state, dispatch, hydrated, demoOpen, setDemoOpen }), [state, hydrated, demoOpen]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = React.useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

export const currentUser = (s: AppState) => users.find((u) => u.id === s.currentUserId) ?? defaultUser;
