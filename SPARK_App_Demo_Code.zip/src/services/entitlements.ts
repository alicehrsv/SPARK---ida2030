import type { AppState } from "@/context/AppContext";
import { registersByUser } from "@/data/registers";
import { DEMO_TODAY } from "@/data/config";

export interface EntitlementReason { text: string; source: string }
export interface EntitlementQuestion { q: string; expectYes: boolean; failReason: string }
export interface EntitlementHint {
  id: string;
  title: string;
  titleDe: string;
  icon: string; // lucide icon name
  procedureId?: string;
  estimate: string;
  deadline?: string;
  reasons: EntitlementReason[];
  missing: string[];
  fieldsUsed: string[];
  questions: EntitlementQuestion[];
  automatic?: boolean;
  easy: string;
}

const DAY = 86_400_000;
const daysBetween = (a: Date, b: Date) => Math.round((Date.UTC(a.getFullYear(), a.getMonth(), a.getDate()) - Date.UTC(b.getFullYear(), b.getMonth(), b.getDate())) / DAY);

function parseDate(s: string): Date | null {
  const m = s.match(/(\d{1,2}) (\w{3,}) (\d{4})/);
  if (!m) return null;
  const d = new Date(`${m[1]} ${m[2]} ${m[3]}`);
  return Number.isNaN(d.getTime()) ? null : d;
}

function findField(fields: { label: string; value: string }[] | undefined, label: string): string | undefined {
  return fields?.find((f) => f.label === label)?.value;
}

function parseChildren(value: string | undefined): { name: string; birth: Date }[] {
  if (!value) return [];
  const out: { name: string; birth: Date }[] = [];
  const re = /([A-Za-zÀ-ÿ'’.\- ]+?)\s*\((\d{1,2} \w{3,} \d{4})\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(value))) {
    const d = parseDate(m[2]!);
    if (d) out.push({ name: m[1]!.trim(), birth: d });
  }
  return out;
}

function parseMoney(value: string | undefined): number | null {
  if (!value) return null;
  const m = value.replace(/\./g, "").match(/([\d,]+)/);
  if (!m) return null;
  const n = Number(m[1]!.replace(",", "."));
  return Number.isNaN(n) ? null : n;
}

const at = (days: number) => {
  const d = new Date(DEMO_TODAY);
  d.setDate(d.getDate() + days);
  return d.toISOString();
};

/**
 * Pure rules engine: ida only gives hints, the authority always decides.
 * Only runs when the user has opted in (state.settings.entitlementChecks).
 */
export function runEntitlementRules(userId: string, state: AppState): EntitlementHint[] {
  if (!state.settings.entitlementChecks) return [];
  const regs = registersByUser[userId] ?? [];
  const byId = (id: string) => regs.find((r) => r.id === id);
  const hints: EntitlementHint[] = [];

  const zpr = byId("zpr");
  const zmr = byId("zmr");
  const social = byId("social");
  const transparency = byId("transparency");
  const pension = byId("pension");
  const tax = byId("tax");
  const education = byId("education");
  const vehicle = byId("vehicle");

  // --- New child in ZPR, no childcare benefit yet for that child ---
  const children = parseChildren(findField(zpr?.fields, "Children"));
  const newChild = children.find((c) => daysBetween(DEMO_TODAY, c.birth) < 365);
  if (newChild) {
    const benefitsText = findField(transparency?.fields, "Benefits received") ?? "";
    const alreadyHasChildcare = benefitsText.toLowerCase().includes("childcare benefit") && benefitsText.includes(newChild.name.split(" ")[0]!);
    if (!alreadyHasChildcare) {
      hints.push({
        id: "childcare-benefit",
        title: `Childcare benefit for ${newChild.name.split(" ")[0]}`,
        titleDe: `Kinderbetreuungsgeld für ${newChild.name.split(" ")[0]}`,
        icon: "Baby",
        procedureId: "childcare-benefit",
        estimate: "approx. € 440–1,000 / month – estimate",
        deadline: at(180),
        reasons: [
          { text: `New child (${newChild.name}) born ${newChild.birth.toLocaleDateString("en-GB")}`, source: "Central Civil Status Register (ZPR)" },
          { text: "No childcare benefit on record yet for this child", source: "Transparency Database" },
        ],
        missing: ["Bank account (IBAN) for payment", "Chosen benefit variant"],
        fieldsUsed: ["Children", "Benefits received"],
        questions: [
          { q: "Are you the parent or legal guardian caring for this child?", expectYes: true, failReason: "Only the caring parent or guardian can apply." },
          { q: "Is the child mainly living in your household?", expectYes: true, failReason: "The child must live mainly in your household." },
        ],
        easy: "A new baby was born in your family. Parents can often get money to help with childcare. ida thinks you may not have applied yet.",
      });
    }

    // --- family allowance, automatic if parent employed ---
    const employer = findField(social?.fields, "Employer");
    const employed = !!employer && employer !== "None (co-insured)" && employer !== "Retired" && employer !== "None";
    if (employed) {
      hints.push({
        id: "family-allowance",
        title: `Family allowance for ${newChild.name.split(" ")[0]}`,
        titleDe: `Familienbeihilfe für ${newChild.name.split(" ")[0]}`,
        icon: "HandCoins",
        procedureId: "family-allowance",
        estimate: "approx. € 165–220 / month – estimate",
        deadline: at(150),
        automatic: true,
        reasons: [
          { text: `New child (${newChild.name}) in your household`, source: "Central Civil Status Register (ZPR)" },
          { text: `Employed at ${employer}`, source: "Social Insurance" },
        ],
        missing: [],
        fieldsUsed: ["Children", "Employer"],
        questions: [
          { q: "Is the child registered at your address?", expectYes: true, failReason: "The child must be registered at your address." },
        ],
        easy: "This is usually paid automatically once the birth is registered – ida just lets you know about it.",
      });
    }
  }

  // --- Pension income below demo threshold ---
  const pensionAmount = parseMoney(findField(pension?.fields, "Pension amount"));
  if (pensionAmount != null && pensionAmount < 1600) {
    hints.push({
      id: "prescription-fee-exemption",
      title: "Prescription fee exemption",
      titleDe: "Rezeptgebührenbefreiung",
      icon: "Pill",
      procedureId: "prescription-fee-exemption",
      estimate: "saves approx. € 6–13 per prescription – estimate",
      reasons: [{ text: `Pension income (€ ${pensionAmount.toLocaleString("en-GB")} gross/month) below the demo threshold`, source: "Pension Insurance" }],
      missing: ["Confirmation of total household income"],
      fieldsUsed: ["Pension amount"],
      questions: [{ q: "Is your monthly gross pension below approx. € 1,600?", expectYes: true, failReason: "The income limit is not met." }],
      easy: "If your income is low, you may not have to pay the fee for prescriptions.",
    });
    hints.push({
      id: "heating-allowance",
      title: "Heating allowance",
      titleDe: "Heizkostenzuschuss",
      icon: "Flame",
      procedureId: "heating-allowance",
      estimate: "approx. € 100–250 per heating season – estimate",
      deadline: at(60),
      reasons: [{ text: `Pension income (€ ${pensionAmount.toLocaleString("en-GB")} gross/month) below the demo threshold`, source: "Pension Insurance" }],
      missing: ["Proof of heating costs"],
      fieldsUsed: ["Pension amount"],
      questions: [{ q: "Is your monthly gross pension below approx. € 1,600?", expectYes: true, failReason: "The income limit is not met." }],
      easy: "People with a low income can get help paying for heating in winter.",
    });
  }

  // --- Student with low income ---
  if (education) {
    const income = parseMoney(findField(tax?.fields, "Last annual income"));
    if (income != null && income < 12000) {
      hints.push({
        id: "study-grant",
        title: "Study grant",
        titleDe: "Studienbeihilfe",
        icon: "GraduationCap",
        procedureId: "study-grant",
        estimate: "approx. € 100–800 / month – estimate",
        deadline: at(45),
        reasons: [
          { text: `Enrolled at ${findField(education.fields, "University")}`, source: "Education Register" },
          { text: `Low own income (€ ${income.toLocaleString("en-GB")} / year)`, source: "Tax Office (FinanzOnline)" },
        ],
        missing: ["Proof of study progress (ECTS)", "Parents' income (if applicable)"],
        fieldsUsed: ["University", "Last annual income"],
        questions: [
          { q: "Are you enrolled as a regular student this semester?", expectYes: true, failReason: "You must be enrolled as a regular student." },
          { q: "Is your income below the demo limit?", expectYes: true, failReason: "The income limit is not met." },
        ],
        easy: "Students with low income can get money from the state to help pay for studying.",
      });
    }
  }

  // --- Moved to Vienna recently + vehicle registered (parking permit) ---
  const registeredSince = findField(zmr?.fields, "Registered since");
  const mainResidence = findField(zmr?.fields, "Main residence") ?? "";
  const viennaPostcodeMatch = mainResidence.match(/\b1\d{3}\b/);
  const sinceDate = parseDate(registeredSince ?? "");
  if (viennaPostcodeMatch && sinceDate && daysBetween(DEMO_TODAY, sinceDate) < 365 && vehicle) {
    hints.push({
      id: "parking-permit",
      title: "Parking permit (Parkpickerl)",
      titleDe: "Parkpickerl",
      icon: "ParkingSquare",
      procedureId: "parking-permit",
      estimate: "approx. € 120 / year – estimate",
      reasons: [
        { text: `Recently registered in Vienna (${registeredSince})`, source: "Central Residence Register (ZMR)" },
        { text: "Vehicle registered to you", source: "Vehicle Register" },
      ],
      missing: ["Vehicle registration certificate"],
      fieldsUsed: ["Registered since", "Main residence", "Plate"],
      questions: [{ q: "Is the vehicle registered at your Vienna address?", expectYes: true, failReason: "The vehicle must be registered at your Vienna address." }],
      easy: "If you just moved to Vienna and have a car, you may need a parking permit for your district.",
    });
  }

  return hints;
}
