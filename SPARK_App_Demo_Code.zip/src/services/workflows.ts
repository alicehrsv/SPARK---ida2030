import { registersByUser } from "@/data/registers";

export type StepType = "info" | "checklist" | "fetch" | "form" | "upload" | "choice" | "appointment" | "review" | "facematch" | "submit";

export interface WorkflowStep {
  type: StepType;
  name: string;
  registers?: string[];
}

export interface FormFieldSource { register: string; field: string }
export interface WorkflowFormField {
  key: string;
  label: string;
  source: FormFieldSource | "user";
  required: boolean;
  uncertain?: boolean;
}

export interface WorkflowDocument {
  name: string;
  fromRegister?: string;
  uploadAllowed: boolean;
}

export interface PaymentModel { id: string; title: string; text: string }

export interface WorkflowTemplate {
  id: string;
  title: string;
  titleDe: string;
  category: string;
  authority: string;
  icon: string;
  knowledgeId?: string;
  levelForSubmit: "critical";
  processingTime: string;
  deadline: string;
  whoCanApply: string;
  description: string;
  whatHappensNext: string;
  inPersonPart: string | null;
  officeId: string | null;
  paymentModels: PaymentModel[] | null;
  steps: WorkflowStep[];
  formFields: WorkflowFormField[];
  documents: WorkflowDocument[];
}

const modules = import.meta.glob("../data/workflows/*.json", { eager: true }) as Record<string, { default: WorkflowTemplate }>;

/** All workflow templates, loaded eagerly from JSON so a new procedure only needs a new file. */
export const allTemplates: WorkflowTemplate[] = Object.values(modules)
  .map((m) => m.default)
  .sort((a, b) => a.title.localeCompare(b.title));

const byId = new Map(allTemplates.map((t) => [t.id, t]));

export const getTemplate = (id: string): WorkflowTemplate | undefined => byId.get(id);

/** Categories in catalog order, derived from the templates present. */
export const categories: string[] = [
  "Residence", "Documents", "Residence & citizenship", "Family", "Money & work", "Health & age", "Mobility", "Education", "Elections",
].filter((c) => allTemplates.some((t) => t.category === c));

/** Life-event bundles: procedure ids to run one after another ("prepare everything"). */
export const lifeEvents: { id: string; label: string; procedureIds: string[] }[] = [
  { id: "moving", label: "Moving", procedureIds: ["change-address", "registration-confirmation", "housing-allowance", "parking-permit"] },
  { id: "baby", label: "Having a baby", procedureIds: ["birth-registration", "family-allowance", "childcare-benefit"] },
  { id: "retiring", label: "Retiring", procedureIds: ["pension-application", "care-allowance", "disability-pass"] },
  { id: "studies", label: "Starting studies", procedureIds: ["study-grant", "registration-confirmation"] },
  { id: "job-loss", label: "Losing my job", procedureIds: ["unemployment-benefit", "social-assistance", "heating-allowance"] },
];

/** How many of the template's form fields ida can pre-fill from registers for this user (X of Y). */
export function prefillCount(template: WorkflowTemplate, userId: string): { filled: number; total: number } {
  const regs = registersByUser[userId] ?? [];
  const total = template.formFields.length;
  const filled = template.formFields.filter((f) => {
    const src = f.source;
    if (src === "user") return false;
    const reg = regs.find((r) => r.id === src.register);
    return !!reg?.fields.some((rf) => rf.label === src.field);
  }).length;
  return { filled, total };
}
