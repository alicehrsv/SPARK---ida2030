import { describe, expect, it } from "vitest";
import { detectIntent, render } from "./ai";

describe("mock AI", () => {
  it("detects intents in several languages", () => {
    expect(detectIntent("How do I renew my residence permit?")).toBe("residence");
    expect(detectIntent("Ich brauche einen neuen Meldezettel")).toBe("address");
    expect(detectIntent("Kako produžiti boravišnu dozvolu?")).toBe("residence");
    expect(detectIntent("Ich möchte mit einem Menschen sprechen")).toBe("person");
  });
  it("unknown questions never invent an answer", () => {
    expect(render({ intent: "unknown" }, { userId: null, language: "en", easy: false }).text).toBe("I'm not sure. Shall I connect you with a person?");
  });
  it("personalises the residence permit answer for Amira", () => {
    const a = render({ intent: "residence", serviceId: "residence-permit-renewal" }, { userId: "amira", language: "en", easy: false });
    expect(a.sentences[0]).toBe("Your permit expires on 30 Apr 2030 – you can apply now.");
  });
});
