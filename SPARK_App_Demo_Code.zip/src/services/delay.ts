let slow = false;
export const setSlowNetwork = (v: boolean) => { slow = v; };

/** Fake latency 600–1200 ms (×3 in slow-network demo mode). */
export const fakeLatency = (min = 600, max = 1200) =>
  new Promise<void>((r) => setTimeout(r, (min + Math.random() * (max - min)) * (slow ? 3 : 1)));
