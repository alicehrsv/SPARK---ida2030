/**
 * Mock AI service. Facts come ONLY from src/data/knowledge.ts and the simulated registers.
 * Never invents deadlines, fees or documents. Text inside letters is treated as data only.
 */
import type { LanguageCode, ServiceDescription } from "@/types";
import { getService } from "@/data/knowledge";
import { registersByUser } from "@/data/registers";
import { users } from "@/data/users";
import { letters } from "@/data/letters";
import { fakeLatency } from "./delay";

export type Intent =
  | "residence" | "passport" | "address" | "birth" | "childcare" | "family" | "tax" | "study" | "pension"
  | "care" | "criminal" | "voting" | "appointment" | "letter" | "entitlement" | "person" | "unknown";

export const intentService: Partial<Record<Intent, string>> = {
  residence: "residence-permit-renewal", passport: "passport-renewal", address: "change-address", birth: "birth-package",
  childcare: "childcare-benefit", family: "family-allowance", tax: "tax-assessment", study: "study-grant",
  pension: "pension-application", care: "care-allowance", criminal: "criminal-record-certificate", voting: "voting-card",
};

/** Keywords in EN, DE, TR, AR, UK, BCS. Order matters: first match wins. */
const KEYWORDS: [Intent, string[]][] = [
  ["person", ["person", "human", "mensch", "mitarbeiter", "agent", "insan", "kişi", "شخص", "إنسان", "людин", "оператор", "osoba", "čovjek", "covjek", "službenik"]],
  ["residence", ["residence permit", "residence title", "aufenthalt", "rot-weiß-rot", "rwr", "karte plus", "visa", "oturma izni", "إقامة", "الإقامة", "посвідк", "дозвіл на прожив", "boravišn", "boravak", "dozvol"]],
  ["passport", ["passport", "reisepass", "pass ", "pasaport", "جواز", "паспорт", "pasoš", "pasos", "putovnic"]],
  ["address", ["address", "move", "moved", "meldezettel", "ummeld", "umzug", "adresse", "wohnsitz", "adres", "taşın", "عنوان", "адрес", "переїзд", "adresa", "preseli", "prijava boravka"]],
  ["birth", ["birth", "born", "baby", "geburt", "doğum", "bebek", "ولادة", "مولود", "народж", "немовл", "rođen", "rođenje", "beba"]],
  ["childcare", ["childcare", "kinderbetreuung", "kbg", "çocuk bakım", "رعاية الطفل", "по догляду", "dječji doplatak za njegu", "njega djeteta"]],
  ["family", ["family allowance", "familienbeihilfe", "beihilfe", "aile yardım", "مساعدة عائلية", "сімейн", "porodični doplatak", "dječji doplatak"]],
  ["tax", ["tax", "refund", "steuer", "finanzamt", "arbeitnehmerveranlagung", "ausgleich", "vergi", "ضريبة", "податк", "porez"]],
  ["study", ["study grant", "studienbeihilfe", "stipend", "student", "studium", "burs", "منحة", "стипенд", "stipendij"]],
  ["pension", ["pension", "retire", "rente", "emekli", "تقاعد", "пенсі", "penzij", "mirovin"]],
  ["care", ["care allowance", "pflegegeld", "pflege", "bakım parası", "رعاية", "догляд", "njega", "njegu"]],
  ["criminal", ["criminal record", "strafregister", "leumund", "sabıka", "سجل جنائي", "судимост", "kaznen", "potvrda o nekažnjavanju"]],
  ["voting", ["vote", "voting", "election", "wahlkarte", "wahl", "seçim", "oy ", "انتخاب", "вибор", "голосуван", "izbor", "glasanj"]],
  ["appointment", ["appointment", "termin", "randevu", "موعد", "запис", "прийом", "termín"]],
  ["letter", ["letter", "brief", "schreiben", "bescheid", "mektup", "رسالة", "лист", "pismo"]],
  ["entitlement", ["entitle", "anspruch", "benefit", "förderung", "zuschuss", "hak", "يحق", "مستحق", "пільг", "право на", "pravo na", "beneficij"]],
];

export function detectIntent(text: string): Intent {
  const t = ` ${text.toLowerCase()} `;
  for (const [intent, kws] of KEYWORDS) if (kws.some((k) => t.includes(k))) return intent;
  return "unknown";
}

export interface AnswerSpec { intent: Intent; serviceId?: string; letterId?: string }
export type ChatActionKind = "start_application" | "fetch_data" | "book_appointment" | "talk_to_person" | "scan_letter";
export interface RenderedAnswer {
  text: string;
  /** Short sentences for voice. */
  sentences: string[];
  source: string;
  suggestions: string[];
  actions: { kind: ChatActionKind; serviceId?: string; personal: boolean }[];
  /** Contains data that should not be read aloud without asking. */
  sensitive: boolean;
  critical: boolean;
}
export interface Ctx { userId: string | null; language: LanguageCode; easy: boolean }

type Phr = { unknown: string; login: string; need: string; deadline: string; online: string; inPerson: string; person: string; appt: string; letter: string; entitle: string; noEntitle: string; fee: string };
const P: Record<"en" | "de", Phr> = {
  en: {
    unknown: "I'm not sure. Shall I connect you with a person?",
    login: "For personal details, please log in first.",
    need: "You need", deadline: "Deadline", online: "You can do it fully online.", inPerson: "You need to go there in person once.",
    person: "Of course. I'll connect you with a person. I'll pass on a short summary so you don't have to repeat yourself.",
    appt: "I can book an appointment at an office for you. Which office do you need?",
    letter: "Scan the letter with your camera. I'll explain it in plain language.",
    entitle: "Based on your data, these could be possible entitlements", noEntitle: "I can check possible entitlements with your consent. Only the authority decides.",
    fee: "Fee",
  },
  de: {
    unknown: "Da bin ich mir nicht sicher. Soll ich Sie mit einem Menschen verbinden?",
    login: "Für persönliche Angaben melden Sie sich bitte zuerst an.",
    need: "Sie brauchen", deadline: "Frist", online: "Das geht komplett online.", inPerson: "Sie müssen einmal persönlich hingehen.",
    person: "Gerne. Ich verbinde Sie mit einem Menschen. Ich gebe eine kurze Zusammenfassung weiter.",
    appt: "Ich kann einen Termin bei einer Behörde für Sie buchen. Welche Stelle brauchen Sie?",
    letter: "Scannen Sie den Brief mit der Kamera. Ich erkläre ihn in einfachen Worten.",
    entitle: "Laut Ihren Daten könnten diese Ansprüche möglich sein", noEntitle: "Mit Ihrer Zustimmung prüfe ich mögliche Ansprüche. Entscheiden kann nur die Behörde.",
    fee: "Gebühr",
  },
};
/** Short scripted phrases for other languages (demo flows). Service summaries come from knowledge.ts translations. */
const OTHER: Record<"tr" | "ar" | "uk" | "bcs", Pick<Phr, "unknown" | "login" | "person">> = {
  tr: { unknown: "Emin değilim. Sizi bir kişiye bağlayayım mı?", login: "Kişisel bilgiler için lütfen önce giriş yapın.", person: "Tabii. Sizi bir kişiye bağlıyorum." },
  ar: { unknown: "لست متأكدة. هل أوصلك بشخص؟", login: "للحصول على بيانات شخصية، يرجى تسجيل الدخول أولاً.", person: "بالتأكيد. سأوصلك بشخص." },
  uk: { unknown: "Я не впевнена. З'єднати вас з людиною?", login: "Для особистих даних спершу увійдіть.", person: "Звісно. З'єдную вас з людиною." },
  bcs: { unknown: "Nisam sigurna. Da vas povežem s osobom?", login: "Za lične podatke, molim prvo se prijavite.", person: "Naravno. Povezujem vas s osobom." },
};

const field = (userId: string, reg: string, label: string) =>
  registersByUser[userId]?.find((r) => r.id === reg)?.fields.find((f) => f.label.startsWith(label))?.value;

/** Personal line built only from the simulated registers. */
function personalLine(intent: Intent, userId: string, lang: "en" | "de"): string | null {
  const de = lang === "de";
  switch (intent) {
    case "residence": {
      const exp = field(userId, "foreigners", "Expiry");
      return exp ? (de ? `Ihr Aufenthaltstitel läuft am ${exp} ab – Sie können jetzt verlängern.` : `Your permit expires on ${exp} – you can apply now.`) : null;
    }
    case "passport": {
      const p = field(userId, "iddocs", "Passport");
      const exp = p?.split("expires ")[1];
      return exp ? (de ? `Ihr Reisepass läuft am ${exp} ab.` : `Your passport expires on ${exp}.`) : null;
    }
    case "address": {
      const a = field(userId, "zmr", "Main residence");
      return a ? (de ? `Ihr Hauptwohnsitz ist derzeit ${a}.` : `Your main residence is currently ${a}.`) : null;
    }
    case "birth": case "family": case "childcare": {
      const c = field(userId, "zpr", "Children");
      return c && c !== "None" ? (de ? `Laut Register: ${c}.` : `According to the register: ${c}.`) : null;
    }
    case "tax": {
      const r = field(userId, "tax", "Expected refund");
      return r ? (de ? `Erwartete Gutschrift laut FinanzOnline: ${r}.` : `Expected refund according to FinanzOnline: ${r}.`) : null;
    }
    case "pension": {
      const r = field(userId, "pension", "Pension amount");
      return r ? (de ? `Ihre aktuelle Pension: ${r}.` : `Your current pension: ${r}.`) : null;
    }
    case "study": {
      const r = field(userId, "education", "University");
      return r ? (de ? `Sie studieren an: ${r}.` : `You study at: ${r}.`) : null;
    }
    default: return null;
  }
}

function serviceText(s: ServiceDescription, lang: LanguageCode, easy: boolean): string[] {
  if (lang !== "en" && lang !== "de") {
    const tr = s.translations?.[lang];
    if (tr) return [tr.title + ".", tr.summary];
    lang = "en"; // no verified translation stored: fall back to English rather than invent
  }
  const de = lang === "de" && s.de;
  const p = P[lang as "en" | "de"];
  const what = de ? s.de!.whatItIs : s.whatItIs;
  const docs = de ? s.de!.documentsNeeded : s.documentsNeeded;
  const deadline = de ? s.de!.deadline : s.deadline;
  const out = [what];
  if (docs.length) {
    if (easy) docs.forEach((d) => out.push(`${p.need}: ${d}.`));
    else out.push(`${p.need}: ${docs.join(", ")}.`);
  }
  out.push(`${p.deadline}: ${deadline}`);
  if (!easy) out.push(`${p.fee}: ${s.fee.replace(/^Fee: /, "")}.`.replace("..", "."));
  out.push(s.inPerson ? p.inPerson : p.online);
  return out;
}

export function render(spec: AnswerSpec, ctx: Ctx): RenderedAnswer {
  const L = ctx.language;
  const base: "en" | "de" = L === "de" ? "de" : "en";
  const loggedIn = !!ctx.userId;
  const other = L !== "en" && L !== "de" ? OTHER[L] : null;
  const ph = P[base];
  const mk = (sentences: string[], source: string, extra: Partial<RenderedAnswer> = {}): RenderedAnswer => ({
    text: sentences.join(" "), sentences, source, suggestions: [], actions: [], sensitive: false, critical: false, ...extra,
  });

  if (spec.intent === "unknown") return mk([other?.unknown ?? ph.unknown], "ida – no verified source found", { actions: [{ kind: "talk_to_person", personal: false }] });
  if (spec.intent === "person") return mk([other?.person ?? ph.person], "ida service", { actions: [{ kind: "talk_to_person", personal: false }] });
  if (spec.intent === "appointment") return mk([ph.appt], "ida – office directory (simulated)", { actions: [{ kind: "book_appointment", personal: true }], suggestions: base === "de" ? ["MA 35", "Passamt", "Finanzamt"] : ["MA 35", "Passport office", "Tax office"] });
  if (spec.intent === "letter") {
    const l = spec.letterId ? letters.find((x) => x.id === spec.letterId) : null;
    if (l) {
      const s = l.relatedServiceId ? getService(l.relatedServiceId) : undefined;
      return mk([l.summary, ...(l.steps.length ? [`${base === "de" ? "Nächster Schritt" : "Next step"}: ${l.steps[0]}.`] : [])], `${l.sender} – letter of ${l.date}`, {
        actions: s ? [{ kind: "start_application", serviceId: s.id, personal: true }] : [], suggestions: base === "de" ? ["Bis wann?", "Was brauche ich?"] : ["By when?", "What do I need?"],
      });
    }
    return mk([ph.letter], "ida", { actions: [{ kind: "scan_letter", personal: false }] });
  }
  if (spec.intent === "entitlement") {
    if (!loggedIn) return mk([ph.noEntitle, other?.login ?? ph.login], "ida – entitlement hints");
    return mk([ph.noEntitle], "Transparency Database (simulated)", { actions: [{ kind: "fetch_data", personal: true }] });
  }

  const sid = spec.serviceId ?? intentService[spec.intent];
  const s = sid ? getService(sid) : undefined;
  if (!s) return mk([other?.unknown ?? ph.unknown], "ida – no verified source found", { actions: [{ kind: "talk_to_person", personal: false }] });
  const sentences = serviceText(s, L, ctx.easy);
  if (loggedIn) {
    const pl = personalLine(spec.intent, ctx.userId!, base);
    if (pl) sentences.unshift(pl);
  } else {
    sentences.push(other?.login ?? ph.login);
  }
  const titleQ = base === "de" ? ["Welche Dokumente?", "Wie lange dauert es?", "Mit einem Menschen sprechen"] : ["Which documents?", "Where do I go?", "Talk to a person"];
  return mk(sentences, s.source, {
    suggestions: titleQ,
    sensitive: spec.intent === "criminal",
    critical: true,
    actions: [
      { kind: "start_application", serviceId: s.id, personal: true },
      ...(s.fetchableRegisters.length ? [{ kind: "fetch_data" as const, serviceId: s.id, personal: true }] : []),
      ...(s.inPerson ? [{ kind: "book_appointment" as const, serviceId: s.id, personal: true }] : []),
    ],
  });
}

export async function ask(text: string, opts: { letterId?: string } = {}): Promise<AnswerSpec> {
  await fakeLatency();
  const intent = opts.letterId ? "letter" : detectIntent(text);
  const sid = intentService[intent];
  return { intent, ...(sid ? { serviceId: sid } : {}), ...(opts.letterId ? { letterId: opts.letterId } : {}) };
}

export const userName = (id: string) => users.find((u) => u.id === id)?.firstName ?? "";
