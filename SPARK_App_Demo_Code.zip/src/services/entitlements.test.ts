import { describe, it, expect } from "vitest";
import { runEntitlementRules } from "./entitlements";
import { initialState } from "@/context/AppContext";

function stateFor(userId: string, entitlementChecks = true) {
  const s = initialState(userId);
  return { ...s, settings: { ...s.settings, entitlementChecks } };
}

describe("runEntitlementRules", () => {
  it("gives Marcus childcare-benefit and family-allowance", () => {
    const ids = runEntitlementRules("marcus", stateFor("marcus")).map((h) => h.id);
    expect(ids).toContain("childcare-benefit");
    expect(ids).toContain("family-allowance");
  });

  it("gives Martha prescription-fee-exemption and heating-allowance", () => {
    const ids = runEntitlementRules("martha", stateFor("martha")).map((h) => h.id);
    expect(ids).toContain("prescription-fee-exemption");
    expect(ids).toContain("heating-allowance");
  });

  it("gives Patrick study-grant", () => {
    const ids = runEntitlementRules("patrick", stateFor("patrick")).map((h) => h.id);
    expect(ids).toContain("study-grant");
  });

  it("gives Amira no hints", () => {
    const ids = runEntitlementRules("amira", stateFor("amira")).map((h) => h.id);
    expect(ids).toEqual([]);
  });

  it("returns nothing when opted out", () => {
    const ids = runEntitlementRules("marcus", stateFor("marcus", false));
    expect(ids).toEqual([]);
  });
});
